module.exports = {
  applyNotEnough: {
    code: "40001",
    message: "豆豆余额不足",
    result: "",
  },
};
