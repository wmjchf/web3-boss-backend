"use strict";
(self["webpackChunkweb3_design_style"] = self["webpackChunkweb3_design_style"] || []).push([[608],{

/***/ 46132:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  c: () => (/* binding */ layout_Basic)
});

// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.js
var es_symbol = __webpack_require__(42856);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.description.js
var es_symbol_description = __webpack_require__(63397);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.iterator.js
var es_symbol_iterator = __webpack_require__(54000);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.from.js
var es_array_from = __webpack_require__(67972);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.is-array.js
var es_array_is_array = __webpack_require__(29448);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.iterator.js
var es_array_iterator = __webpack_require__(44272);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.slice.js
var es_array_slice = __webpack_require__(72344);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.date.to-string.js
var es_date_to_string = __webpack_require__(28612);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__(26572);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__(88012);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__(23784);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.regexp.to-string.js
var es_regexp_to_string = __webpack_require__(81852);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.string.iterator.js
var es_string_iterator = __webpack_require__(13755);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/web.dom-collections.iterator.js
var web_dom_collections_iterator = __webpack_require__(22248);
// EXTERNAL MODULE: ./node_modules/.pnpm/react@18.2.0/node_modules/react/index.js
var react = __webpack_require__(96651);
// EXTERNAL MODULE: ./node_modules/.pnpm/react-router@6.22.3_react@18.2.0/node_modules/react-router/dist/index.js
var dist = __webpack_require__(66336);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.includes.js
var es_array_includes = __webpack_require__(76376);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.string.includes.js
var es_string_includes = __webpack_require__(35024);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/Button/Button.js + 3 modules
var Button = __webpack_require__(80180);
// EXTERNAL MODULE: ./src/image/common/logo.png
var logo = __webpack_require__(99452);
// EXTERNAL MODULE: ./src/components/EllipsisMiddle/index.tsx
var EllipsisMiddle = __webpack_require__(39108);
;// CONCATENATED MODULE: ./src/layout/Basic/components/Header/index.less
// extracted by mini-css-extract-plugin
/* harmony default export */ const components_Header = ({"header":"src-layout-Basic-components-Header-__index__header","left":"src-layout-Basic-components-Header-__index__left","right":"src-layout-Basic-components-Header-__index__right","seek":"src-layout-Basic-components-Header-__index__seek","address":"src-layout-Basic-components-Header-__index__address","user__window":"src-layout-Basic-components-Header-__index__user__window","user__window__item":"src-layout-Basic-components-Header-__index__user__window__item"});
// EXTERNAL MODULE: ./src/store/index.ts + 4 modules
var store = __webpack_require__(75899);
// EXTERNAL MODULE: ./node_modules/.pnpm/wagmi@2.5.5_@tanstack+react-query@5.18.1_immer@10.0.4_react-dom@18.2.0_react-native@0.73.4_re_v25ef47o4x2uzzylvfiqdsf7ny/node_modules/wagmi/dist/esm/hooks/useAccount.js + 3 modules
var useAccount = __webpack_require__(79576);
// EXTERNAL MODULE: ./src/utils/platform.ts
var platform = __webpack_require__(4371);
// EXTERNAL MODULE: ./node_modules/.pnpm/react-hot-toast@2.4.1_csstype@3.1.3_react-dom@18.2.0_react@18.2.0/node_modules/react-hot-toast/dist/index.mjs
var react_hot_toast_dist = __webpack_require__(98448);
;// CONCATENATED MODULE: ./src/layout/Basic/components/Header/index.tsx












var Header = function Header(props) {
  var onClick = props.onClick;
  var _useLocation = (0,dist/* useLocation */.IT)(),
    pathname = _useLocation.pathname;
  var navigate = (0,dist/* useNavigate */.i6)();
  var _userUserStore = (0,store/* userUserStore */.Wu)(),
    userInfo = _userUserStore.userInfo;
  var address = userInfo.address;
  var _useAccount = (0,useAccount/* useAccount */.g)(),
    isConnected = _useAccount.isConnected;
  var renderBtn = (0,react.useMemo)(function () {
    return pathname.includes("company") ? /*#__PURE__*/react.createElement(react.Fragment, null, /*#__PURE__*/react.createElement(Button/* default */.c, {
      variant: "contained",
      size: "large",
      onClick: function onClick() {
        navigate("/jobs");
      }
    }, "\u6211\u8981\u5E94\u8058"), address && isConnected && /*#__PURE__*/react.createElement(EllipsisMiddle/* EllipsisMiddle */.I, {
      value: address,
      suffixCount: 6,
      className: components_Header.address,
      onClick: onClick
    })) : /*#__PURE__*/react.createElement(react.Fragment, null, /*#__PURE__*/react.createElement(Button/* default */.c, {
      variant: "contained",
      size: "large",
      onClick: function onClick() {
        if ((0,platform/* isMobile */.y)()) {
          (0,react_hot_toast_dist/* default */.cp)("需要去pc端打开填写哦", {
            icon: "😬",
            duration: 5000
          });
          return;
        } else {
          navigate("/company");
        }
      }
    }, "\u6211\u8981\u62DB\u4EBA"), address && isConnected && /*#__PURE__*/react.createElement(EllipsisMiddle/* EllipsisMiddle */.I, {
      value: address,
      suffixCount: 6,
      className: components_Header.address,
      onClick: onClick
    }));
    // if (!isConnected) {
    //   return (
    //     <AuthBtn>
    //       <Button variant={"contained"} size="large">
    //         Connect Wallet
    //       </Button>
    //     </AuthBtn>
    //   );
    // } else {
    //   if (localStorage.getItem("token")) {
    //     return pathname === "/company" ? (
    //       <>
    //         <Button
    //           variant="contained"
    //           size="large"
    //           onClick={() => {
    //             navigate("/jobs");
    //           }}
    //         >
    //           我要应聘
    //         </Button>

    //         <EllipsisMiddle
    //           value={address}
    //           suffixCount={6}
    //           className={styles.address}
    //         >
    //           <div className={styles.user__window}>
    //             <span
    //               className={styles.user__window__item}
    //               onClick={() => {
    //                 // disconnect();
    //                 localStorage.removeItem("token");
    //                 disconnect(
    //                   {},
    //                   {
    //                     onSuccess() {
    //                       location.reload();
    //                     },
    //                   }
    //                 );
    //               }}
    //             >
    //               退出登录
    //             </span>
    //           </div>
    //         </EllipsisMiddle>
    //       </>
    //     ) : (
    //       <>
    //         <Button
    //           variant="contained"
    //           size="large"
    //           onClick={() => {
    //             navigate("/company");
    //           }}
    //         >
    //           我要招人
    //         </Button>
    //         <EllipsisMiddle
    //           value={address}
    //           suffixCount={6}
    //           className={styles.address}
    //         ></EllipsisMiddle>
    //       </>
    //     );
    //   } else {
    //     return (
    //       <AuthBtn>
    //         <Button variant={"contained"} size="large">
    //           Login In
    //         </Button>
    //       </AuthBtn>
    //     );
    //   }
    // }
  }, [pathname, address]);
  return /*#__PURE__*/react.createElement("div", {
    className: components_Header.header
  }, /*#__PURE__*/react.createElement("div", {
    className: components_Header.left,
    onClick: function onClick() {
      navigate("/jobs", {
        replace: true
      });
    }
  }, /*#__PURE__*/react.createElement("img", {
    src: logo,
    alt: ""
  }), /*#__PURE__*/react.createElement("span", null, "FlowIn3")), /*#__PURE__*/react.createElement("div", {
    className: components_Header.right
  }, renderBtn));
};
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/Drawer/Drawer.js + 2 modules
var Drawer = __webpack_require__(4100);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/Popover/Popover.js + 1 modules
var Popover = __webpack_require__(51480);
// EXTERNAL MODULE: ./node_modules/.pnpm/antd-mobile@5.35.0_react-dom@18.2.0_react@18.2.0/node_modules/antd-mobile/es/index.js + 43 modules
var es = __webpack_require__(78576);
;// CONCATENATED MODULE: ./src/layout/Basic/components/DrawList/index.less
// extracted by mini-css-extract-plugin
/* harmony default export */ const components_DrawList = ({"draw__list":"src-layout-Basic-components-DrawList-__index__draw__list","bottom":"src-layout-Basic-components-DrawList-__index__bottom","top":"src-layout-Basic-components-DrawList-__index__top","score":"src-layout-Basic-components-DrawList-__index__score","main":"src-layout-Basic-components-DrawList-__index__main","label":"src-layout-Basic-components-DrawList-__index__label","count":"src-layout-Basic-components-DrawList-__index__count","copy":"src-layout-Basic-components-DrawList-__index__copy","rule":"src-layout-Basic-components-DrawList-__index__rule","item":"src-layout-Basic-components-DrawList-__index__item"});
// EXTERNAL MODULE: ./src/image/my/score.svg
var score = __webpack_require__(65324);
// EXTERNAL MODULE: ./node_modules/.pnpm/wagmi@2.5.5_@tanstack+react-query@5.18.1_immer@10.0.4_react-dom@18.2.0_react-native@0.73.4_re_v25ef47o4x2uzzylvfiqdsf7ny/node_modules/wagmi/dist/esm/hooks/useDisconnect.js + 5 modules
var useDisconnect = __webpack_require__(31456);
// EXTERNAL MODULE: ./src/components/ResumeModal/index.tsx + 1 modules
var ResumeModal = __webpack_require__(98792);
// EXTERNAL MODULE: ./src/components/PdfPreview/index.tsx + 1 modules
var PdfPreview = __webpack_require__(26756);
// EXTERNAL MODULE: ./src/components/ApplyModal/index.tsx + 3 modules
var ApplyModal = __webpack_require__(60712);
// EXTERNAL MODULE: ./src/constant/index.ts
var constant = __webpack_require__(39784);
;// CONCATENATED MODULE: ./src/layout/Basic/components/DrawList/index.tsx










var DrawList = function DrawList(props) {
  var _onClose = props.onClose;
  var _useDisconnect = (0,useDisconnect/* useDisconnect */.W)(),
    disconnect = _useDisconnect.disconnect;
  var _userUserStore = (0,store/* userUserStore */.Wu)(),
    userInfo = _userUserStore.userInfo;
  var resumeModalRef = (0,react.useRef)(0);
  var applyModalRef = (0,react.useRef)(0);
  var pdfPreviewRef = (0,react.useRef)();
  return /*#__PURE__*/react.createElement("div", {
    className: components_DrawList.draw__list
  }, /*#__PURE__*/react.createElement("div", {
    className: components_DrawList.top
  }, /*#__PURE__*/react.createElement("div", {
    className: components_DrawList.score
  }, /*#__PURE__*/react.createElement("div", {
    className: components_DrawList.main
  }, /*#__PURE__*/react.createElement("span", {
    className: components_DrawList.lable
  }, "\u8C46\u8C46\u4F59\u989D\uFF1A"), /*#__PURE__*/react.createElement("span", {
    className: components_DrawList.count
  }, userInfo.integral), /*#__PURE__*/react.createElement("img", {
    src: score,
    alt: ""
  }), /*#__PURE__*/react.createElement(Button/* default */.c, {
    className: components_DrawList.copy,
    onClick: function onClick() {
      var _navigator;
      (_navigator = navigator) === null || _navigator === void 0 || (_navigator = _navigator.clipboard) === null || _navigator === void 0 || _navigator.writeText("https://www.flowin3.com/jobs?address=".concat(userInfo.address)).then(function () {
        console.log("复制成功");
      })["catch"](function () {
        console.log("复制失败");
      });
    }
  }, "\u590D\u5236")), /*#__PURE__*/react.createElement("div", {
    className: components_DrawList.rule
  }, constant/* SHARE_TIP */.Kk)), /*#__PURE__*/react.createElement("div", {
    className: components_DrawList.item,
    style: {
      marginTop: "12px"
    },
    onClick: function onClick() {
      var _resumeModalRef$curre;
      (_resumeModalRef$curre = resumeModalRef.current) === null || _resumeModalRef$curre === void 0 || _resumeModalRef$curre.handleOpen();
    }
  }, /*#__PURE__*/react.createElement("i", {
    className: "iconfont icon-resume-line"
  }), /*#__PURE__*/react.createElement("span", null, "\u6211\u7684\u7B80\u5386")), /*#__PURE__*/react.createElement("div", {
    className: components_DrawList.item,
    onClick: function onClick() {
      var _applyModalRef$curren;
      (_applyModalRef$curren = applyModalRef.current) === null || _applyModalRef$curren === void 0 || _applyModalRef$curren.handleOpen();
    }
  }, /*#__PURE__*/react.createElement("i", {
    className: "iconfont icon-wodetoudi"
  }), /*#__PURE__*/react.createElement("span", null, "\u6211\u7684\u6295\u9012"))), /*#__PURE__*/react.createElement("div", {
    className: components_DrawList.bottom
  }, /*#__PURE__*/react.createElement(Button/* default */.c, {
    onClick: function onClick() {
      localStorage.removeItem("token");
      disconnect({}, {
        onSuccess: function onSuccess() {
          location.reload();
        }
      });
    }
  }, "\u9000\u51FA\u767B\u5F55")), /*#__PURE__*/react.createElement(ResumeModal/* ResumeModal */.E, {
    ref: resumeModalRef,
    openResume: function openResume(item) {
      var _pdfPreviewRef$curren;
      (_pdfPreviewRef$curren = pdfPreviewRef.current) === null || _pdfPreviewRef$curren === void 0 || _pdfPreviewRef$curren.handleOpen(item.resumeUrl, item.id);
    }
  }), /*#__PURE__*/react.createElement(ApplyModal/* ApplyModal */.O, {
    ref: applyModalRef,
    onClose: function onClose() {
      _onClose && _onClose();
    }
  }), /*#__PURE__*/react.createElement(PdfPreview["default"], {
    ref: pdfPreviewRef,
    showMark: false
  }));
};
;// CONCATENATED MODULE: ./src/layout/Basic/image/qrcode.jpg
const qrcode_namespaceObject = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wgARCAFYAVgDASIAAhEBAxEB/8QAHQABAQEAAQUBAAAAAAAAAAAAAAkBBQIDBgcIBP/EABsBAQACAwEBAAAAAAAAAAAAAAAEBQEGBwMC/9oADAMBAAIQAxAAAAH6pAAAAAAAAAAAAAAAAAAAAAABmpVlVEqxVRKsVUSrFU9SrKqJViqepVlVMlZVQzUqyqgM2VlUwAAlWKp7KuqgzZVlVEqxVRKsVUSrFVAAAJV1UlWVUJWFU0rBVOVdVJVlVJV1TErKqMNlXtUyVdVMGslaZVRKwqmlYKpmErFVBKuqjCVtU5WCqcq6qSrKqMlaVTSsFU5V1UlWVUAAAlXVSVZVSVdVJVgFVJV1UlWVTlZVSVZVRKsbVOVY2qWysKpNlWVUyVlVDJW1TCVlUwSrFVMlZVQlWCqkq6qSrKqSrqpKsAqpKuqkqyqgAAEq6qSrKqJWCqaVgqnKwKpyrqnKwVUSsFU+mVxlVMlcZVPJWmKpytMVTlaYqnK0qmyVpiqcrTFU5WlU5WVTlYVTSsFU0rBVOVe4VUAAAABmysqmM2VhVLQSsqmJWYCqcrKqErFUxKvcG1TlXVQlZVKVg1VMMlYKp7KuqgzQSrFU0rKqBKsVUAAAZK0wqmSsbhVRKwVTZK0wqmayVpVOVlU8JWVUlZVMGErFU5WmVUYbKuqYlZVTBrJWlU5WVTlYVTSsFU5V1UlYYqnKwqoAABKuqkqxuCqeysqmSrqnKwbgKpysFU2yrKqSt6aqGbKsVUlZVMY2VZVSVlU5VgCqcrKqErKpyrqoM2VhtUdlWVUzZWFU5V1UlWVUAAAlXVSVZVQEq21SJWVUSsKppWCqcrAyqmStM9sfff5D5BfX/E4fK731w31E9PfZHp7zh9+VPy9jEiXue2PvslZVSVelU2aJWAqnmkq6qJWnSqnK0qmAADJW1TBKsVTlbgqpkrBVNsqzVU5WFUpW1THT+fv8JhxXhW+PTNI6O/08ZY6F395ngde2z2N7G+dfcM7ZPLpYfRXzrG2TVUxkraphkrBqqYZKwbVMAAAAJV1USsKpyrqnKwqoSsKppWCqaVgVTzTo9b+yPVuPLiOA5fiNh4Z3vy9zv+1fx36/wcrBt/z814lzcXZ/fssqm96D0qVjapGyrqnKwNqkbKuqYlYaVTlXuFVAAAJV1UlWVUlZVMStqjK3CqmbKsqnKwNqlozZWVTOj1r6C+qcfPrPg+c4i64v2e6S6PNdv3h9HL+P+3anonzb87VN71V05KyqcqyqeyrFVM2VgwKqSsqmOmVyqYAAAZK0qmlZVI1KyqZKuqkq9KpyrqnpKuqjDUrKpnR2O9+I8V8A94cB7U/qTo5virXnH5vx+SefeFn4z7QdNZ0XvSxqVLbHvlVJV6VTZK0yqiVhVNKwVTlXoyqkrBVMAAGStqmJWVS0SsVTErKpbKsqolWKqA6ZXKpkrKe8tKw+inzrVE8f+WPnSqR4+mdVE4D4k9TipvflWNqloyVqqYzZVlU5WBVQEqwVUAAAZK0xVQSrVUBKwKp5K0yqkq6qEq1U5WCqkrBVOVdU5WBVTDUrBlVErDFU5WFVCVhVOVdU5WFVJV7VIlZVTJWlUyVhVOVdU5WFVAAAY2VYqnKyqhKxVMSsqlsrAqmJV1UlXVQyVgVUlZVMStqjsqxuDqqjsqyqmbKsqnKwNVTErMqpKsA2qUrBVTJWCqcrcqoAAAGStKppWCqaVgqmlYKpyrqnoSsFU5V1TErKqSrqmalYKpysCqaVlUyVaqmGyrqpKsqpKuqmErFU5WFVCVhVOVdU5WFVCVhjcKqAAASrqpKsqpmyrKqJViqkrKpyrKqAyV3TVQlYVTMSsqoJV1UlWVTlbgqnsqxqqYyVlVJVlVJW9NVDJWVUlWVUyVgqnKwKqSsyqhmysqmAAAJV1UlWVUlXVSVhgKqSrqpKsqpKuqeiVdVJWCqeaAGStMVUEq1VBKuqjCVtU80lXVSVdVCVdVJWVTJV1UYSsVTlaVTlXVSVhiqcrSqYAAEq6qSrKqJViqiVYqpKzBVQEq9wVTlbVMSsVTGStVTJV7lVCVlU0qyqcrcFU5W4NqlolYqnKsqolWNqnKuqhKyqWjNlWKqAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//EAC8QAAAFAQUGBAcAAAAAAAAAAAECAwQFAAYSExdQBxARFDNBNTZDkBUgISMxNEL/2gAIAQEAAQUC9sGB2aTM+hknKVknKVknKVknKVkpKaMAYw4BakHzKKSUtAutRpiXAUrVLo1GSzCWrAJQgLYdpcClA2m0Duh05ubMzPgJMVJKYwhojsh1l2xVTWctKdZVbp/3oHd4/TjI1Ixo5oDgXBhKA0448y4YNU2LG+KblHFLByoy8Tts8f0DvaE2MpN/fOkkCW5ykZVNQjw5Ek8FI5gA1l3At5j1NA7yXmaQ/bVWIiCSxFgpo/K6UpZMuDEeYR6mgd7QkwXEoS65A52ry+dd1X43D9RsygLib22eP6BsT8ffx5ZSLTOd8z+Qw0usCCdn4o0VE+poHdDpzkGostfI7UrjQmpZcqIWcs4qZdbp+poAjwoBFsOOWpOKYy4OrJu0h+BzIU3stILjFwMfFGxi0I4olNfPoJhVSrOyUrOyUrnHVZ2Slc46rnHVc26qe2lzU83TJcDQ7obrobroe0z/AP/EACwRAAEDAgQEBAcAAAAAAAAAAAECAwQABRESITEGIkBREzNw0RUyQWFxgZH/2gAIAQMBAT8B9OnJUdnzHAP3TUhl/wApYP46S/XN9poiOOXbGojAuz7cYKyrO5Jq/WA8OhEmM9741ZLr8SZ5/nTv79E6rK2pQ7VKfkyHVx0EkE7U2p6E+FDRaTV1uNwlEMz1Y4a/2rLHahymSy7m8RJxHboiAoFJ+tSy/Zrl4yN6mS3Jr6pDu5rVR1rhWGouqlK2Gg6O5Wxm5IyuaHvTnCk5KuTAiofCjmbGUrAfamWUMIDTQwA9UP/EACQRAAIBAwQBBQEAAAAAAAAAAAECAwAEERIhMUAFExRRYXBS/9oACAECAQE/AfzoKzcCipXkdS2jR3wx3qeX2kTSkZA+K8N5tfNa0KcVPD6TfXTRI0USH45pgkyaTuDVnZ2ttlrZcZqWV5g4dMaTt99MIl5bmJ+DUECW8YiTgVsKvH20dOKVoTkUL1Ke8/miSxyf1D//xABAEAABAgMDBA8FBwUAAAAAAAABAgMABBESITETQVBREBQiMjM0QlJhcYGSorHRBSAkQ8JTcnSQkaHhI0SCwdL/2gAIAQEABj8C/LBS+ltEqwq9K5g0tdkcek/F6Rx6T8XpHHpTxekcelPF6Rx6U8XpoY3kJwujld4xlJl7JA4ArNT1R8H7NdUn7SZdyY/TGP7AdGUcMfFyFoc+VfKv2MES7xLgxbUohQ7I5XeMJIUSgmhBvhxLCQhh9IeSgcmuP7jQXafOEykqkOz7gqlJwQOcqNsPq257QPzV5urUIRliTbNwGxkxXPQ0uNMYS4KtvJ3riLlCBIz5G2PlvZnf5jtHnoN6Zc3rdo0134Q5OzQtTsyQVAX35kjqhZUFJWDRSVYgxfDWUUsSx3JyZpQ5oCVVQ0zuwQbxBUq1ZJqi3vqdMXGwsG0hY5J1whxdz6FBDoHOBiR/DfUdBezZPM4+pxQ6EX+dIS2SaJvuOeDeVFRqVKNSdgWCApKgoVwuhfxVorFFJUjcwhFa2RSsAVvOaJmW+W+hLo+8lVD5iOzQUjXDa71O+IcgFRxuAGJiqDXMejYcQEkWNibbVKB190/05i7cRI/cX9Og/Zc5mQ8tpR6F/wAgQTrEMTKG8rk6gorr1RMTC0ZLKkbgZrvdff5Eu2lH+SlD0iR/DfUdAz34b6hD0ss0t1odRrcYLbwpPSpsOp/371oipzJGJOqEpd4w6oOO9ddB9p84E/IkInkChB3rqeaYWEpLMynhJZe+HuC1vjclIvKuqEz8+mypPAy/M6T0x2jz0GQUkoJqCL45XdMDbDRK071xKSFJ6jFZOeyqeZMtGveEUyMsem2r/mPiZtuXRqYaUpX6mMo2hTj/ANs6CVRyu6YFxCRffBIw0FubxqMcRk/F6xxGU8XrHBojiMn4vWODRHBojg0QphTiJVhQopEuKWu3QuGxhsYflM//xAAsEAACAQIDBQkBAQEAAAAAAAABEQAQMSAhMEFRYZHwQFBgcYGhscHR8eFw/9oACAEBAAE/IfDD0HgdXHgeg6vxWKKOhghodFRx1XZ1UUEMENDhfjF4zoHuRx41Djffb7jIwHGodIwVMEPanQQ4DUeEB3jbVIEEACUXdYW+331/rMWqu0nA44qkJIEoCTmb0veDLSTg7gbMd7uF+fd7BHsjqxw6i7f4BH3gf3gc8i4CdL5gy3TeR2IMW3e1MIADYGIVeM6JOg6KKOrJ17o5VovynzCbJBzu8Ae0Jl/kWI9PWecy8SwKhbAPCFJzk70JjrzaCF9cMz9OyEpOHcP1jC7auTIOJMKAGlZuWs5xRA+rcDEKAosMWMHiTcFIY8NkEuLJMEgsvnCJj8BsNmMqOGuAbBFh2BQEfO/rS81XbfrM8nv3GPySQGhAlRFwIO+AFzUwN5oACsYtiecEZA2JZSFkLjnM5SrrlCGwItEczPZg4BzByIbO0jiVPrDJDY9Tm/UN+dEMmQEk3AC8I0AKCES3EbKEeu0S9pGe45W4iiVHE5yUFncIs5XjBRZzPJ/4ljy7UIcDr2AbqmRAXZgjBhM+EJAXLeF8xApFAzQJmd9ANgKhx3sK8QPsPPuO88vwVhu4jyKgbChbSNjgbjCnKEZjkIyrBxMAQMqthhl6BD0ht8uzPT+s6PijtEiXSUdkO7Hc8cbxxEOV8oREyMo3BJUbW4Nsumt1M/GZenZDb5YHrkVWFVVXQTa0Oe4LyO4I843pfE+Iys4Dh2DwHdO6PehAiBnfwhcgDkZlO9H0rKy9IvpfEIICJiCfpB54DIHAqHDeWjxE1eAaGy+4YP8AAn/Pn/BP7P40/wCCf2fwT+wG/E/se+s1SzBIkovMOLRgdRDrLW4DlTgOUc4Dl4BOotI6IhoaDGYNN9kFV4eI0FqjRNB2kwVOIUNBVYF4mWsdFdoOB4RDhfda/wCH/wD/2gAMAwEAAgADAAAAEPPPPPPPPPPPPPPPPPPPPPPPJDDDJDJGJKIPPDKFDDDPPPFAMPFJGLAJMJMJAPCMFPPPFPPPNDLAFGAEDGPPFPFPPPFMMBHJCKAPMPAPMIEMHPPPDCAAJEHOLLDDJHCGDKDPPPCONNAPAAMJMJHLAIGMNPPPFLALHPFCLEFDPODAFAFPPPFKPJMBIPPw2wHLGBAIMPPPIDDHFAIPxxLDXDAHBHIPPPMJHBMJAO+Omr/MHMFOHPPPFEFBHAAGQePdJHLAHEIPPPCACLEICIBHWh0LAJMEIPPPIALBDKIGBKNDDAABHCPPPPAMMJAKPJHNGJNBHEIBHPPPNODAJKPEFLFBPHNPPHKPPPCMMNGNFLOBCNFEPBHBNPPPFFDDFKIOFPLDNCNHPGAPPPFMPPGMAMCMMIAKMJMNMPPPFDDDFLACAOJPDAJDLALPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP/EACQRAQABBAEEAQUAAAAAAAAAAAERACExQWFAUXBxoYGRsdHw/9oACAEDAQE/EPHILinIa5FASSdw9GC2KZGBkcT7/BU0gosj2g12jdQbJgiYWycUDYQQNmv26JM8FWEoXLKWLUJ6QklxOGm0q0MWhOtUA1wLaJv/AGuixkBPvSI4KpJIzmokJ5YsfSpmKWjSt+xcx6OjwscDXvuUyOSGPhpwOGrl4nB81g8oDyh//8QAHhEBAQABBAMBAAAAAAAAAAAAAREAITFAQVFhcHH/2gAIAQIBAT8Q+dbxONRjhrM6UlDty9o7BrDf9y4Zbr1Oi+Z1iSN23ClQwkwTc8fuKYCnpMKDMWaWYkwgJ6eThOavYRmbT/C4wwYG7rw+guJNRMKQ1944ar9Q/8QAKhABAAICAQQCAgEFAAMAAAAAAQARITFBECBRYXGBkaGxMMHR8PFgcOH/2gAIAQEAAT8Q/wDGGjBUGu5uNIKg10bjSCoNRUFqFmNGCoNdFqWGq+4NneoaqDZFoglqv6iXFt7jcq4tvQ3KuLbBpgVEuLb0dS4Fd4wKiXF/qc9Fotg32eJdVEpgWyzfEuagWwbihuDZNznsdR30C2XdyruDZ08SwMwbOu67+eiWS8al+pfrp4iavxNDP5iKJcwgC8QENzRz+IM4gzfrUd6mm4tmoZ4l+otRbhfRFEuFLhS4hddPEbJniWeJfqCXqB389eOzxKuoq9G6nJgqXVQ3uJuL5JoY/M0cXMmKmv3EzuaSscZhroqC1C1x318Q46m4cd/PXjs8Q47LfMW2bniVcW2DTAqIO4FESymVRHfQaZVXHfXxDjqbhx389y0SqqHHTcvc8zc3L3PM3AtlPiVEpgWykZYGYNkC2U+JUSnp4hrsWoldy1ESfU+p9T6g06i39S4iRFNxDx+YnziLnUdbjmsRIudTTf4l8fuc+yOXX4jk3+I5o9xLz61FzqaOa+JeK48xvf6iZ1+ItTUfifU+p9S8VUcuu5LgBKjiXTVfcMmo4NS7ar7gXuAEWiAVcWnpcSpedyvcuWZpKhl3+ZzpnO5XuOejaq3AxqJcqofBK9EcC1C3EPglej+i6lwKiXLhrollMqiO+u77eOg0y7Ya7BgV0dR30GmVUd96huDZAtlTXZTzBsgWyqZYEGyLUSavq6lWxKYFsG4tRKYFsG4obg2dPENdd1KiU91jviWeIb/zC8v6m0qX6lZ1E5/UXOoNMtd3Bn+0d6jrxA2/qO4Nxai3G7v9RM6/E0c1MGJbuGALmjn8TBxMnmO9RahKvRc+otQxKWmLb3c9Rtl1ivuGTUN/5heT9xaegWy11UXyTQx+ZpqJXMqyGJpKK+eJfmaGPzEuLLly0lS6lR15g55xAuGtR15huv3Dv566gwKg0y5voNMu2VcW2albjvollMolGuItvTjseZ56JcuVqbiXLhx389XUpWJTNznqtER1Km4bJkr7EqGULGB+Mt3B8sP+hD/uwyf3YCP3wABealnmLRFXrcSmBcEm+i0RHUCDc3L3KtiU93PV1DXGYYN/mabi2an1PqAHUyqWazxFPETi49cdmVaVTO7xK8nOJodhD4hS+gYP6YTeGUfMFwI4q+KNfqBAZoV+cN+UKFt/HngPevfQKcDA9XUgrtBFSniVZ9oVOgBeCCfAYN/mDTKa9waMwRg06l3RKvN/UMG5puLfE52xy6/HdQ64lHnq4Y4d/iOZVRpxDINQC7jSo0THEo8y9fVxWUWz3LvRZVNWQujaweZiJj9g54XgofMRSVqMVXkl6UFrnEopwuUoa/1AaNbZ+/cYaOf/AMjn6cPJDOAaIs0nAZdEyeJUfF0qX5f2x34le4Be4vGfmO9yvRH4jvc+45iUThbIZNfnuQdwKOo1Ft6G5VxbYlku6lCZgUS/r/8AEV9Eg3S/YAHtmaaVR6N4Gh5teYm8lCYGj4RK4SXHKyD7DwzmIhUsTSrzhpRzLcaxSFPKo23dsopEYmGQ5aWtl1xFDBgHPfEfyWcwcNd8mj0KHoRV8SKtVy9aeIFHQ3DXU3KsgUUf0Ny5uui0Wwb7HUqDc/vf2nw6MawfX6UvrCpfgTIKEYJqxUmBY7aA+AI2YYuRkLFIBFFOGPlhqvkGiU8q+YYRCuEC321Mc6CT4CWYoSuhDH2nxmPxv5YlOYFsqmHHQLZVMuolPQ3LqJXctQRiKbljBplTSLiquGeJfqX6muCZZgUR/m/kmyCQ+YV+iEUt4n6I4pXpVwCr0EuemgN2ilHhOYGaiO1LAOMDkbbNJzHbZxGWHjwgCtcBctmcbFZi8l/JAu04/wAsMG7hh1+ZzLqIkDOvzC7v9SrhgC5UBJ6jvuS4qxaIBVzjiGTX5jrzNqqbV/Ed/wCIGdwc8/MsNfuDZMp+My6DgmHIV8U/llZKE/On+I/3BITFjBUq+EcwDCzLGKWF1bWNFsfCQkoWy0bl/UL0GJTizPFOj2XPjKfQv/X5j8ypdwLM5gVxExqHgKjiXExqcXjMX5zEzvu56JZTKoloxbYlxYNRbYlkoCXAqG7M5x4vRTLewC+ojkGyF8lYN7l0ob/ctqujUoIcxxEFyNROUQCFCrrsw28hD8vMz/27euq6pcWb6JZTKonma7lDcGyLRKeZZBssgXBJZviJTAtlm+JZBssj/N/Mo4S8Tpsgb9D+U+GBW26zfD/bIVpkOHE2T9EVTgepUptijouU+CXwTZROPjQwBg3tcGiH/u+3oFwSU8wbJuc9VoiVAuDZ3WO+JZ4lniYN39S+Pe4ONw3NYmUBALiKJcwnEMG/zDxx5MYYE+1WBkyUaSniocKkWf8AG0N5EHxqIg7j8YBf394/9gLKbTKisHHgH5ErAfeOHYlT6BDjQg1lWKrYCzun6jlGBOaiZhuaxMm7+pZ4mm4tmoZ4l+oNOotINIhdd1DriUeZR5mTVfc04an3AzuWXsY4Ymdw2ZllfjIQ+ymU5BBqIaYLfII+X30SJKkIsidVtQt5UwGtVcIEwFSq4gZ3Bzz8yw6iHmOvM2qptX8R3/iVEjvvQdwKIlkp467j2Op5mul1Lcz/AIqXPp/SWzmf8VBpuW3d56pZKAnmaiXFg1Ft6Oo771DcGzudTzN9HmVbEpgXBJuupuGum5e5VsSmLRbLJuumowm4tFssm67xm/Wo71FrmXcuX7Jfqc6iRc66Jctd3Fthh1PSQaZUv2R/2pvifU03FGVncW2Ljc9eOYNeYlQc6gpmTuLnU0llfHP9As5mhj8y0iVH5qfcDO4M53K99FqWuqiUxManF+YZIa1LhuAMNajrzDLUVGolM+5d8w83HfRVmlwya/Mc9Co6uIee5Li29N313PENdXmXTFtiWUwKnM30NytTcS4sGotvVLi31FItvUmu5Q3Bs77N8RKetm+IlPTV9VolS6INlnQ3DjotRIFxKYtFssm66LRbLsjvvsd8SzxPqfU+p9T6mnJUygIBc+pVbKlXDAFyli3N6l+oOdRvmY1+5pL9kWHR14hhuIrcW2aSyvjnqSyCVUdyu7no4NQbaqV6JXolDLhro61ECVcSnc0cfiZOJXzFuaa/Ern9QLMwxPuHzfVpqIHU56FRqJTFQ1EHP5l51vzDJru56JcXs8Q101K3LgUQaYFTnoNMt89uq6alTVdg1FtmpW5cCu7nrx2eJdVEp6bqBBvqobg2doWy7lQb6PM89Atl3KtiU9N1KiU93PRaiSpXTxG1QEAuWE1E0rxBxuXLiWyzxL9kv2RahmaOagRM2sHG+jzKljEUS5hOY5dfiXKqN7/UTOvx3c9HMCpXoleiKhdXEqn3DXS5auYtHrcd7n3K9zDiIeYZdysXcCzc01NHF/ErF8eI3r9xc7/Eo8zJqvuGLR5jh30bqLUqG9wc8yr3Arju57hplqw11NyhMwKOjqeZqDUCpzNwaZb5lxbYlkp4iEW+u76JZKAjv/0N/9k=";
;// CONCATENATED MODULE: ./src/layout/Basic/index.less
// extracted by mini-css-extract-plugin
/* harmony default export */ const Basic = ({"basic__layout":"src-layout-Basic-__index__basic__layout","content":"src-layout-Basic-__index__content","notice":"src-layout-Basic-__index__notice","notice__bar":"src-layout-Basic-__index__notice__bar","platform":"src-layout-Basic-__index__platform","public":"src-layout-Basic-__index__public","popover":"src-layout-Basic-__index__popover","qrcode":"src-layout-Basic-__index__qrcode"});
;// CONCATENATED MODULE: ./src/layout/Basic/index.tsx














function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }









var BasicLayout = function BasicLayout() {
  var _useState = (0,react.useState)(false),
    _useState2 = _slicedToArray(_useState, 2),
    open = _useState2[0],
    setOpen = _useState2[1];
  var _useState3 = (0,react.useState)(null),
    _useState4 = _slicedToArray(_useState3, 2),
    anchorEl = _useState4[0],
    setAnchorEl = _useState4[1];
  var handleClick = function handleClick(event) {
    setAnchorEl(event.currentTarget);
  };
  var handleClose = function handleClose() {
    setAnchorEl(null);
  };
  var show = Boolean(anchorEl);
  return /*#__PURE__*/react.createElement("div", {
    className: Basic.basic__layout
  }, /*#__PURE__*/react.createElement("div", {
    className: Basic.notice
  }, /*#__PURE__*/react.createElement(es/* NoticeBar */.Qf, {
    content: /*#__PURE__*/react.createElement("span", null, /*#__PURE__*/react.createElement("i", {
      className: Basic.platform
    }, "FlowIn3"), "\u76EE\u7684\u662F\u4E3Aweb3\u8D44\u6E90\u63D0\u4F9B\u6D41\u52A8\u6027\uFF01\u76EE\u524D\u5E73\u53F0\u6B63\u5904\u4E8E\u8BD5\u8FD0\u884C\u9636\u6BB5\uFF0C\u5982\u9047\u5230\u4EFB\u4F55\u95EE\u9898\u6216\u8005\u6709\u4EFB\u4F55\u6539\u8FDB\u5EFA\u8BAE\uFF0C\u90FD\u53EF\u4EE5\u5728\u6211\u4EEC", /*#__PURE__*/react.createElement("i", {
      className: Basic["public"],
      onMouseEnter: handleClick
    }, "\u516C\u4F17\u53F7"), "\u7559\u8A00\u3002"),
    className: Basic.notice__bar
    // color="alert"
  })), /*#__PURE__*/react.createElement(Popover/* default */.cp
  // id={id}
  , {
    open: show,
    anchorEl: anchorEl,
    onClose: handleClose,
    anchorOrigin: {
      vertical: "bottom",
      horizontal: "left"
    },
    className: Basic.popover
  }, /*#__PURE__*/react.createElement("div", {
    className: Basic.qrcode
  }, /*#__PURE__*/react.createElement("img", {
    src: qrcode_namespaceObject
  }))), /*#__PURE__*/react.createElement(Header, {
    onClick: function onClick() {
      setOpen(true);
    }
  }), /*#__PURE__*/react.createElement("div", {
    className: Basic.content
  }, /*#__PURE__*/react.createElement(dist/* Outlet */.yY, null)), /*#__PURE__*/react.createElement(Drawer/* default */.cp, {
    open: open,
    onClose: function onClose() {
      setOpen(false);
    }
  }, /*#__PURE__*/react.createElement(DrawList, {
    onClose: function onClose() {
      setOpen(false);
    }
  })));
};
/* harmony default export */ const layout_Basic = (BasicLayout);

/***/ })

}]);