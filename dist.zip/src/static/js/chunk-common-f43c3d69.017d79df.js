"use strict";
(self["webpackChunkweb3_design_style"] = self["webpackChunkweb3_design_style"] || []).push([[36],{

/***/ 58772:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Aj: () => (/* binding */ put),
/* harmony export */   _M: () => (/* binding */ get),
/* harmony export */   s$: () => (/* binding */ post)
/* harmony export */ });
/* unused harmony export patch */
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(88012);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_promise_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(75908);
/* harmony import */ var core_js_modules_es_promise_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_promise_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constant__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(39784);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(47124);




axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .c.defaults.timeout = 100000;
axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .c.defaults.baseURL = _constant__WEBPACK_IMPORTED_MODULE_3__/* .BASE_URL */ .yk;

// axios.defaults.baseURL = "http://116.62.121.151";
// 请求拦截器  1，可以在这里添加token

axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .c.interceptors.request.use(function (config) {
  config.headers.Authorization = "Bearer ".concat(localStorage.getItem("token"));
  // config.headers["webwea-agent"] = isMobile() ? "h5" : "pc";
  return config;
}, function (error) {
  // 对请求错误做些什么

  return Promise.reject(error);
});

// 添加响应拦截器

axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .c.interceptors.response.use(function (response) {
  // toast.success(response.data.message);
  return response;
}, function (error) {
  //   // 超出 2xx 范围的状态码都会触发该函数。
  //   // 对响应错误做点什么

  return Promise.reject(error.response.data);
});
function get(url) {
  var params = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  return new Promise(function (resolve, reject) {
    axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .c.get(url, {
      params: params
    }).then(function (response) {
      resolve(response.data);
    })["catch"](function (error) {
      reject(error);
    });
  });
}
function post(url) {
  var data = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var config = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  return new Promise(function (resolve, reject) {
    axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .c.post(url, data, config).then(function (response) {
      //关闭进度条
      resolve(response.data);
    }, function (err) {
      reject(err);
    });
  });
}
function patch(url) {
  var data = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  return new Promise(function (resolve, reject) {
    axios.patch(url, data).then(function (response) {
      resolve(response.data);
    }, function (err) {
      msag(err);
      reject(err);
    });
  });
}
function put(url) {
  var data = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  return new Promise(function (resolve, reject) {
    axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .c.put(url, data).then(function (response) {
      resolve(response.data);
    }, function (err) {
      msag(err);
      reject(err);
    });
  });
}

//失败提示
function msag(err) {
  if (err && err.response) {
    switch (err.response.status) {
      case 400:
        alert(err.response.data.error.details);
        break;
      case 401:
        alert("未授权，请登录");
        break;
      case 403:
        alert("拒绝访问");
        break;
      case 404:
        alert("请求地址出错");
        break;
      case 408:
        alert("请求超时");
        break;
      case 500:
        alert("服务器内部错误");
        break;
      case 501:
        alert("服务未实现");
        break;
      case 502:
        alert("网关错误");
        break;
      case 503:
        alert("服务不可用");
        break;
      case 504:
        alert("网关超时");
        break;
      case 505:
        alert("HTTP版本不受支持");
        break;
      default:
    }
  }
}

/***/ }),

/***/ 40076:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   c: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(44272);
/* harmony import */ var core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(88012);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_promise_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(75908);
/* harmony import */ var core_js_modules_es_promise_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_promise_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(13755);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(22248);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(96651);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5135);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(66336);
/* harmony import */ var react_activation__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(10196);
/* harmony import */ var react_activation__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_activation__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _layout_Basic__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(46132);
/* harmony import */ var _page_Jobs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(86479);
/* harmony import */ var _page_Company__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(20432);











// import Job from "@/page/Job";
var Job = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_5__.lazy)(function () {
  return __webpack_require__.e(/* import() */ 828).then(__webpack_require__.bind(__webpack_require__, 1828));
});
var AddJob = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_5__.lazy)(function () {
  return Promise.all(/* import() */[__webpack_require__.e(760), __webpack_require__.e(676), __webpack_require__.e(296)]).then(__webpack_require__.bind(__webpack_require__, 48296));
});
var UpdateJob = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_5__.lazy)(function () {
  return Promise.all(/* import() */[__webpack_require__.e(760), __webpack_require__.e(676), __webpack_require__.e(300)]).then(__webpack_require__.bind(__webpack_require__, 98300));
});
var router = (0,react_router_dom__WEBPACK_IMPORTED_MODULE_9__/* .createBrowserRouter */ .Wq)([{
  path: "/",
  element: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_5__.createElement(_layout_Basic__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .c, null),
  children: [{
    path: "",
    element: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_5__.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_10__/* .Navigate */ .YX, {
      to: "/jobs"
    })
  }, {
    path: "jobs",
    element: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_5__.createElement((react_activation__WEBPACK_IMPORTED_MODULE_11___default()), {
      key: "jobs"
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_5__.createElement(_page_Jobs__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .c, null))
  }, {
    path: "company",
    element: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_5__.createElement((react_activation__WEBPACK_IMPORTED_MODULE_11___default()), {
      key: "company"
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_5__.createElement(_page_Company__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .c, null)),
    children: [{
      path: ":id",
      element: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_5__.createElement(_page_Company__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .c, null)
    }]
  }, {
    path: "addJob/:companyId",
    element: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_5__.createElement(AddJob, null)
  }, {
    path: "updateJob/:id",
    element: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_5__.createElement(UpdateJob, null)
  }, {
    path: "job/:id",
    element: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_5__.createElement(Job, null)
  }]
}]);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (router);

/***/ })

}]);