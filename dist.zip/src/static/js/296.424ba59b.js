"use strict";
(self["webpackChunkweb3_design_style"] = self["webpackChunkweb3_design_style"] || []).push([[296],{

/***/ 50448:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  u: () => (/* binding */ Comfirm)
});

// EXTERNAL MODULE: ./node_modules/.pnpm/react@18.2.0/node_modules/react/index.js
var react = __webpack_require__(96651);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/Button/Button.js + 3 modules
var Button = __webpack_require__(80180);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/Modal/Modal.js + 4 modules
var Modal = __webpack_require__(87492);
;// CONCATENATED MODULE: ./src/components/ComfirmDelete/index.less
// extracted by mini-css-extract-plugin
/* harmony default export */ const ComfirmDelete = ({"container":"src-components-ComfirmDelete-__index__container","tip":"src-components-ComfirmDelete-__index__tip","bottom":"src-components-ComfirmDelete-__index__bottom","cancel":"src-components-ComfirmDelete-__index__cancel"});
;// CONCATENATED MODULE: ./src/components/ComfirmDelete/index.tsx




var Comfirm = function Comfirm(props) {
  var open = props.open,
    onClose = props.onClose,
    onConfirm = props.onConfirm,
    tip = props.tip,
    _props$confirmText = props.confirmText,
    confirmText = _props$confirmText === void 0 ? "确定" : _props$confirmText;
  return /*#__PURE__*/react.createElement(Modal/* default */.c, {
    open: open,
    onClose: onClose,
    "aria-labelledby": "modal-modal-title",
    "aria-describedby": "modal-modal-description"
  }, /*#__PURE__*/react.createElement("div", {
    className: ComfirmDelete.container
  }, /*#__PURE__*/react.createElement("div", {
    className: ComfirmDelete.tip
  }, tip), /*#__PURE__*/react.createElement("div", {
    className: ComfirmDelete.bottom
  }, /*#__PURE__*/react.createElement(Button/* default */.c, {
    variant: "outlined",
    className: ComfirmDelete.cancel,
    onClick: onClose
  }, "\u53D6\u6D88"), /*#__PURE__*/react.createElement(Button/* default */.c, {
    variant: "contained",
    onClick: onConfirm
  }, confirmText))));
};

/***/ }),

/***/ 48296:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ src_page_AddJob)
});

// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.js
var es_symbol = __webpack_require__(42856);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.description.js
var es_symbol_description = __webpack_require__(63397);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.async-iterator.js
var es_symbol_async_iterator = __webpack_require__(44024);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.iterator.js
var es_symbol_iterator = __webpack_require__(54000);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.to-string-tag.js
var es_symbol_to_string_tag = __webpack_require__(78264);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.concat.js
var es_array_concat = __webpack_require__(70516);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__(36160);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.for-each.js
var es_array_for_each = __webpack_require__(93552);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.from.js
var es_array_from = __webpack_require__(67972);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.is-array.js
var es_array_is_array = __webpack_require__(29448);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.iterator.js
var es_array_iterator = __webpack_require__(44272);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.join.js
var es_array_join = __webpack_require__(70400);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__(18440);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.reverse.js
var es_array_reverse = __webpack_require__(51136);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.slice.js
var es_array_slice = __webpack_require__(72344);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.date.to-string.js
var es_date_to_string = __webpack_require__(28612);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__(26572);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.json.to-string-tag.js
var es_json_to_string_tag = __webpack_require__(70048);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.math.to-string-tag.js
var es_math_to_string_tag = __webpack_require__(97304);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.object.create.js
var es_object_create = __webpack_require__(66056);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.object.define-property.js
var es_object_define_property = __webpack_require__(55888);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.object.get-prototype-of.js
var es_object_get_prototype_of = __webpack_require__(98232);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.object.set-prototype-of.js
var es_object_set_prototype_of = __webpack_require__(37456);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__(88012);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.promise.js
var es_promise = __webpack_require__(75908);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__(23784);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.regexp.to-string.js
var es_regexp_to_string = __webpack_require__(81852);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.string.iterator.js
var es_string_iterator = __webpack_require__(13755);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/web.dom-collections.for-each.js
var web_dom_collections_for_each = __webpack_require__(23408);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/web.dom-collections.iterator.js
var web_dom_collections_iterator = __webpack_require__(22248);
// EXTERNAL MODULE: ./node_modules/.pnpm/react@18.2.0/node_modules/react/index.js
var react = __webpack_require__(96651);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/TextField/TextField.js + 34 modules
var TextField = __webpack_require__(53324);
// EXTERNAL MODULE: ./node_modules/.pnpm/react-hot-toast@2.4.1_csstype@3.1.3_react-dom@18.2.0_react@18.2.0/node_modules/react-hot-toast/dist/index.mjs
var dist = __webpack_require__(98448);
;// CONCATENATED MODULE: ./src/page/AddJob/index.less
// extracted by mini-css-extract-plugin
/* harmony default export */ const page_AddJob = ({"add__job":"src-page-AddJob-__index__add__job","container":"src-page-AddJob-__index__container","form":"src-page-AddJob-__index__form","title":"src-page-AddJob-__index__title","one":"src-page-AddJob-__index__one","name":"src-page-AddJob-__index__name","tag":"src-page-AddJob-__index__tag","label":"src-page-AddJob-__index__label","tag__list":"src-page-AddJob-__index__tag__list","chip":"src-page-AddJob-__index__chip","two":"src-page-AddJob-__index__two","is__face":"src-page-AddJob-__index__is__face","salary":"src-page-AddJob-__index__salary","range":"src-page-AddJob-__index__range","three":"src-page-AddJob-__index__three","remote":"src-page-AddJob-__index__remote","location":"src-page-AddJob-__index__location","description":"src-page-AddJob-__index__description"});
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/Button/Button.js + 3 modules
var Button = __webpack_require__(80180);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/Chip/Chip.js + 2 modules
var Chip = __webpack_require__(34336);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/FormControlLabel/FormControlLabel.js + 2 modules
var FormControlLabel = __webpack_require__(88440);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/Radio/Radio.js + 3 modules
var Radio = __webpack_require__(50380);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/RadioGroup/RadioGroup.js + 2 modules
var RadioGroup = __webpack_require__(27739);
// EXTERNAL MODULE: ./src/components/AuthBtn/index.tsx
var AuthBtn = __webpack_require__(27444);
// EXTERNAL MODULE: ./src/api/job.ts
var job = __webpack_require__(70348);
// EXTERNAL MODULE: ./node_modules/.pnpm/react-router@6.22.3_react@18.2.0/node_modules/react-router/dist/index.js
var react_router_dist = __webpack_require__(66336);
// EXTERNAL MODULE: ./src/components/ComfirmDelete/index.tsx + 1 modules
var ComfirmDelete = __webpack_require__(50448);
// EXTERNAL MODULE: ./src/constant/index.ts
var constant = __webpack_require__(39784);
// EXTERNAL MODULE: ./src/store/index.ts + 4 modules
var store = __webpack_require__(75899);
;// CONCATENATED MODULE: ./src/page/AddJob/index.tsx
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }
function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter); }
function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == _typeof(h) && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator["return"] && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(_typeof(e) + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, "catch": function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }






























function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }















var AddJob = function AddJob() {
  var _useState = (0,react.useState)([]),
    _useState2 = _slicedToArray(_useState, 2),
    tagList = _useState2[0],
    setTagList = _useState2[1];
  var _useParams = (0,react_router_dist/* useParams */.W4)(),
    companyId = _useParams.companyId;
  var _useState3 = (0,react.useState)(false),
    _useState4 = _slicedToArray(_useState3, 2),
    shareOpen = _useState4[0],
    setShareOpen = _useState4[1];
  var _useState5 = (0,react.useState)(""),
    _useState6 = _slicedToArray(_useState5, 2),
    tag = _useState6[0],
    setTag = _useState6[1];
  var _useState7 = (0,react.useState)(""),
    _useState8 = _slicedToArray(_useState7, 2),
    name = _useState8[0],
    setName = _useState8[1];
  var navigate = (0,react_router_dist/* useNavigate */.i6)();
  var _useState9 = (0,react.useState)("0"),
    _useState10 = _slicedToArray(_useState9, 2),
    isRemote = _useState10[0],
    setIsRemote = _useState10[1];
  var _userUserStore = (0,store/* userUserStore */.Wu)(),
    userInfo = _userUserStore.userInfo;
  var _useState11 = (0,react.useState)(true),
    _useState12 = _slicedToArray(_useState11, 2),
    showLocation = _useState12[0],
    setShowLocation = _useState12[1];
  var _useState13 = (0,react.useState)(""),
    _useState14 = _slicedToArray(_useState13, 2),
    location = _useState14[0],
    setLocation = _useState14[1];
  var _useState15 = (0,react.useState)("0"),
    _useState16 = _slicedToArray(_useState15, 2),
    isFace = _useState16[0],
    setIsFace = _useState16[1];
  var _useState17 = (0,react.useState)(true),
    _useState18 = _slicedToArray(_useState17, 2),
    showSalary = _useState18[0],
    setShowSalary = _useState18[1];
  var _useState19 = (0,react.useState)(""),
    _useState20 = _slicedToArray(_useState19, 2),
    minSalary = _useState20[0],
    setMinSalary = _useState20[1];
  var _useState21 = (0,react.useState)(""),
    _useState22 = _slicedToArray(_useState21, 2),
    maxSalary = _useState22[0],
    setMaxSalary = _useState22[1];
  var _useState23 = (0,react.useState)(""),
    _useState24 = _slicedToArray(_useState23, 2),
    description = _useState24[0],
    setDescription = _useState24[1];
  (0,react.useEffect)(function () {
    setShowLocation(isRemote === "0");
  }, [isRemote]);
  (0,react.useEffect)(function () {
    setShowSalary(isFace === "0");
  }, [isFace]);
  var handlePublish = /*#__PURE__*/function () {
    var _ref = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
      var result;
      return _regeneratorRuntime().wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0,job/* addJob */.Ab)({
              name: name,
              isRemote: isRemote,
              minSalary: minSalary,
              maxSalary: maxSalary,
              description: description,
              companyId: companyId,
              isFace: isFace,
              location: location,
              tag: tagList.join(",")
            }).then(function (result) {
              var _result$result;
              dist/* toast */.m4.success("".concat(result.message, ",\u8FD8\u5269").concat((_result$result = result.result) === null || _result$result === void 0 ? void 0 : _result$result.resetIntegral, "\u8C46\u8C46"));
              navigate(-1);
            })["catch"](function (error) {
              dist/* toast */.m4.error(error.message);
              setShareOpen(true);
              // closeApply();
              setOpen(false);
            });
          case 2:
            result = _context.sent;
          case 3:
          case "end":
            return _context.stop();
        }
      }, _callee);
    }));
    return function handlePublish() {
      return _ref.apply(this, arguments);
    };
  }();
  var _useState25 = (0,react.useState)(false),
    _useState26 = _slicedToArray(_useState25, 2),
    open = _useState26[0],
    setOpen = _useState26[1];
  return /*#__PURE__*/react.createElement("div", {
    className: page_AddJob.add__job
  }, /*#__PURE__*/react.createElement("div", {
    className: page_AddJob.container
  }, /*#__PURE__*/react.createElement("div", {
    className: page_AddJob.form
  }, /*#__PURE__*/react.createElement("div", {
    className: page_AddJob.title
  }, /*#__PURE__*/react.createElement("span", {
    className: page_AddJob.span
  }, "\u53D1\u5E03\u804C\u4F4D"), /*#__PURE__*/react.createElement(AuthBtn/* AuthBtn */.k, {
    onClick: function onClick() {
      if (!name) {
        dist/* toast */.m4.error("岗位名称必填");
        return;
      }
      if (isFace === "0" && (!minSalary || !maxSalary)) {
        dist/* toast */.m4.error("薪资范围必填");
        return;
      }
      if (isRemote === "0" && !location) {
        dist/* toast */.m4.error("工作地点必填");
        return;
      }
      if (!description) {
        dist/* toast */.m4.error("岗位描述必填");
        return;
      }
      if (tagList.length === 0) {
        dist/* toast */.m4.error("标签至少有一个");
        return;
      }
      setOpen(true);
    }
  }, /*#__PURE__*/react.createElement(Button/* default */.c, {
    variant: "contained"
  }, "\u53D1\u5E03"))), /*#__PURE__*/react.createElement("div", {
    className: page_AddJob.one
  }, /*#__PURE__*/react.createElement("div", {
    className: page_AddJob.name
  }, /*#__PURE__*/react.createElement(TextField/* default */.c, {
    id: "name",
    label: "\u5C97\u4F4D\u540D\u79F0",
    fullWidth: true,
    onChange: function onChange(event) {
      setName(event.target.value);
    }
  })), /*#__PURE__*/react.createElement("div", {
    className: page_AddJob.tag
  }, /*#__PURE__*/react.createElement("span", {
    className: page_AddJob.label
  }, "\u6807\u7B7E"), /*#__PURE__*/react.createElement(TextField/* default */.c, {
    id: "tag",
    label: "Enter\u952E\u5D4C\u5165",
    fullWidth: true,
    value: tag,
    onChange: function onChange(event) {
      setTag(event.target.value);
    },
    onKeyDown: function onKeyDown(event) {
      if (event.key === "Enter") {
        var newTagList = tagList.filter(function (item) {
          return item !== tag;
        });
        setTagList([].concat(_toConsumableArray(newTagList), [tag]));
        setTag("");
      }
    }
  }), /*#__PURE__*/react.createElement("div", {
    className: page_AddJob.tag__list
  }, tagList.map(function (item) {
    return /*#__PURE__*/react.createElement(Chip/* default */.c, {
      key: item,
      label: item,
      onDelete: function onDelete() {},
      className: page_AddJob.chip,
      size: "medium"
    });
  })))), /*#__PURE__*/react.createElement("div", {
    className: page_AddJob.two
  }, /*#__PURE__*/react.createElement("div", {
    className: page_AddJob.is__face
  }, /*#__PURE__*/react.createElement("span", {
    className: page_AddJob.label
  }, "\u662F\u5426\u85AA\u8D44\u9762\u8BAE"), /*#__PURE__*/react.createElement(RadioGroup/* default */.c, {
    "aria-labelledby": "demo-radio-buttons-group-label",
    defaultValue: "0",
    name: "radio-buttons-group",
    row: true,
    onChange: function onChange(event) {
      setIsFace(event.target.value);
    }
  }, /*#__PURE__*/react.createElement(FormControlLabel/* default */.c, {
    value: "0",
    control: /*#__PURE__*/react.createElement(Radio/* default */.c, null),
    label: "\u5426"
  }), /*#__PURE__*/react.createElement(FormControlLabel/* default */.c, {
    value: "1",
    control: /*#__PURE__*/react.createElement(Radio/* default */.c, null),
    label: "\u662F"
  }))), showSalary && /*#__PURE__*/react.createElement("div", {
    className: page_AddJob.salary
  }, /*#__PURE__*/react.createElement("span", {
    className: page_AddJob.label
  }, "\u85AA\u8D44\u8303\u56F4"), /*#__PURE__*/react.createElement(TextField/* default */.c, {
    id: "name",
    label: "\u6700\u4F4E\u85AA\u8D44",
    onChange: function onChange(event) {
      setMinSalary(event.target.value);
    }
  }), " ", /*#__PURE__*/react.createElement("span", {
    className: page_AddJob.range
  }, "-"), /*#__PURE__*/react.createElement(TextField/* default */.c, {
    id: "name",
    label: "\u6700\u9AD8\u85AA\u8D44",
    onChange: function onChange(event) {
      setMaxSalary(event.target.value);
    }
  }))), /*#__PURE__*/react.createElement("div", {
    className: page_AddJob.three
  }, /*#__PURE__*/react.createElement("div", {
    className: page_AddJob.remote
  }, /*#__PURE__*/react.createElement("span", {
    className: page_AddJob.label
  }, "\u662F\u5426\u652F\u6301\u8FDC\u7A0B"), /*#__PURE__*/react.createElement(RadioGroup/* default */.c, {
    "aria-labelledby": "demo-radio-buttons-group-label",
    defaultValue: "0",
    name: "radio-buttons-group",
    row: true,
    onChange: function onChange(event) {
      setIsRemote(event.target.value);
    }
  }, /*#__PURE__*/react.createElement(FormControlLabel/* default */.c, {
    value: "0",
    control: /*#__PURE__*/react.createElement(Radio/* default */.c, null),
    label: "\u5426"
  }), /*#__PURE__*/react.createElement(FormControlLabel/* default */.c, {
    value: "1",
    control: /*#__PURE__*/react.createElement(Radio/* default */.c, null),
    label: "\u662F"
  }))), showLocation && /*#__PURE__*/react.createElement("div", {
    className: page_AddJob.location
  }, /*#__PURE__*/react.createElement("span", {
    className: page_AddJob.label
  }, "\u5DE5\u4F5C\u5730\u70B9"), /*#__PURE__*/react.createElement(TextField/* default */.c, {
    id: "location",
    label: "\u5730\u5740",
    value: location,
    onChange: function onChange(event) {
      setLocation(event.target.value);
    },
    fullWidth: true
  }))), /*#__PURE__*/react.createElement("div", {
    className: page_AddJob.description
  }, /*#__PURE__*/react.createElement(TextField/* default */.c, {
    id: "name",
    label: "\u5C97\u4F4D\u63CF\u8FF0",
    fullWidth: true,
    multiline: true,
    minRows: 20,
    onChange: function onChange(event) {
      setDescription(event.target.value);
    }
  })))), /*#__PURE__*/react.createElement(ComfirmDelete/* Comfirm */.u, {
    open: open,
    tip: "\u53D1\u5E03\u5C06\u6D88\u80175\u9897\u8C46\u8C46\uFF0C\u662F\u5426\u7EE7\u7EED\u53D1\u5E03\uFF1F",
    onClose: function onClose() {
      setOpen(false);
    },
    onConfirm: handlePublish
  }), /*#__PURE__*/react.createElement(ComfirmDelete/* Comfirm */.u, {
    open: shareOpen,
    tip: constant/* SHARE_TIP */.Kk,
    onClose: function onClose() {
      setShareOpen(false);
    },
    onConfirm: function onConfirm() {
      console.log("复制");
      navigator.clipboard.writeText("https://www.flowin3/company".concat(companyId, "?address=").concat(userInfo.address)).then(function () {
        console.log("复制成功");
      })["catch"](function () {
        console.log("复制失败");
      });
      setShareOpen(false);
    }
  }));
};
/* harmony default export */ const src_page_AddJob = (AddJob);

/***/ })

}]);