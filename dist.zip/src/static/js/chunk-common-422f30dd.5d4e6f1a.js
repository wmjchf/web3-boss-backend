"use strict";
(self["webpackChunkweb3_design_style"] = self["webpackChunkweb3_design_style"] || []).push([[232],{

/***/ 75088:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  c: () => (/* binding */ ApplyItem)
});

// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.date.to-string.js
var es_date_to_string = __webpack_require__(28612);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__(26572);
// EXTERNAL MODULE: ./node_modules/.pnpm/react@18.2.0/node_modules/react/index.js
var react = __webpack_require__(96651);
;// CONCATENATED MODULE: ./src/components/ApplyItem/index.less
// extracted by mini-css-extract-plugin
/* harmony default export */ const components_ApplyItem = ({"apply__item":"src-components-ApplyItem-__index__apply__item","left":"src-components-ApplyItem-__index__left","icon":"src-components-ApplyItem-__index__icon","right__container":"src-components-ApplyItem-__index__right__container","right":"src-components-ApplyItem-__index__right","name":"src-components-ApplyItem-__index__name","no__margin":"src-components-ApplyItem-__index__no__margin","time":"src-components-ApplyItem-__index__time","end":"src-components-ApplyItem-__index__end","outer":"src-components-ApplyItem-__index__outer","inner":"src-components-ApplyItem-__index__inner"});
// EXTERNAL MODULE: ./src/utils/time.ts
var time = __webpack_require__(56480);
// EXTERNAL MODULE: ./src/components/EllipsisMiddle/index.tsx
var EllipsisMiddle = __webpack_require__(39108);
// EXTERNAL MODULE: ./node_modules/.pnpm/classnames@2.5.1/node_modules/classnames/index.js
var classnames = __webpack_require__(10124);
var classnames_default = /*#__PURE__*/__webpack_require__.n(classnames);
;// CONCATENATED MODULE: ./src/components/ApplyItem/index.tsx







var ApplyItem = function ApplyItem(props) {
  var _data$resume, _data$resume2;
  var data = props.data,
    onClick = props.onClick,
    onDelete = props.onDelete,
    _props$showTime = props.showTime,
    showTime = _props$showTime === void 0 ? true : _props$showTime,
    style = props.style,
    className = props.className,
    _props$showDelete = props.showDelete,
    showDelete = _props$showDelete === void 0 ? false : _props$showDelete,
    _props$isChoice = props.isChoice,
    isChoice = _props$isChoice === void 0 ? false : _props$isChoice,
    _props$checked = props.checked,
    checked = _props$checked === void 0 ? false : _props$checked,
    onSelect = props.onSelect;
  return /*#__PURE__*/react.createElement("div", {
    className: classnames_default()(components_ApplyItem.apply__item, className),
    onClick: onClick,
    style: style
  }, /*#__PURE__*/react.createElement("div", {
    className: components_ApplyItem.left
  }, /*#__PURE__*/react.createElement("div", {
    className: components_ApplyItem.icon
  }, /*#__PURE__*/react.createElement("i", {
    className: "iconfont icon-resume-line"
  }))), /*#__PURE__*/react.createElement("div", {
    className: components_ApplyItem.right__container
  }, /*#__PURE__*/react.createElement("div", {
    className: components_ApplyItem.right
  }, /*#__PURE__*/react.createElement("div", {
    className: classnames_default()(components_ApplyItem.name, !showTime && components_ApplyItem.no__margin)
  }, ((_data$resume = data.resume) === null || _data$resume === void 0 ? void 0 : _data$resume.name) && /*#__PURE__*/react.createElement(EllipsisMiddle/* EllipsisMiddle */.I, {
    value: (_data$resume2 = data.resume) === null || _data$resume2 === void 0 ? void 0 : _data$resume2.name,
    suffixCount: 7
  })), showTime && /*#__PURE__*/react.createElement("div", {
    className: components_ApplyItem.time
  }, (0,time/* timeAgo */.c)(new Date(data === null || data === void 0 ? void 0 : data.updatedAt)))), showDelete && /*#__PURE__*/react.createElement("div", {
    className: components_ApplyItem.end,
    onClick: function onClick(event) {
      event.stopPropagation();
      onDelete && onDelete();
    }
  }, /*#__PURE__*/react.createElement("i", {
    className: "iconfont icon-shanchu"
  })), isChoice && /*#__PURE__*/react.createElement("div", {
    className: components_ApplyItem.end,
    onClick: function onClick(event) {
      event.stopPropagation();
      onSelect && onSelect();
    }
  }, /*#__PURE__*/react.createElement("div", {
    className: components_ApplyItem.outer
  }, checked && /*#__PURE__*/react.createElement("div", {
    className: components_ApplyItem.inner
  })))));
};

/***/ }),

/***/ 60712:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  O: () => (/* binding */ ApplyModal_ApplyModal)
});

// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.js
var es_symbol = __webpack_require__(42856);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.description.js
var es_symbol_description = __webpack_require__(63397);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.iterator.js
var es_symbol_iterator = __webpack_require__(54000);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.from.js
var es_array_from = __webpack_require__(67972);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.is-array.js
var es_array_is_array = __webpack_require__(29448);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.iterator.js
var es_array_iterator = __webpack_require__(44272);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__(18440);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.slice.js
var es_array_slice = __webpack_require__(72344);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.date.to-string.js
var es_date_to_string = __webpack_require__(28612);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__(26572);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__(88012);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__(23784);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.regexp.to-string.js
var es_regexp_to_string = __webpack_require__(81852);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.string.iterator.js
var es_string_iterator = __webpack_require__(13755);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/web.dom-collections.iterator.js
var web_dom_collections_iterator = __webpack_require__(22248);
// EXTERNAL MODULE: ./node_modules/.pnpm/react@18.2.0/node_modules/react/index.js
var react = __webpack_require__(96651);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/Modal/Modal.js + 4 modules
var Modal = __webpack_require__(87492);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.concat.js
var es_array_concat = __webpack_require__(70516);
;// CONCATENATED MODULE: ./src/components/ApplyModal/item/index.less
// extracted by mini-css-extract-plugin
/* harmony default export */ const ApplyModal_item = ({"item":"src-components-ApplyModal-item-__index__item","top":"src-components-ApplyModal-item-__index__top","tag":"src-components-ApplyModal-item-__index__tag","chip":"src-components-ApplyModal-item-__index__chip","company__name":"src-components-ApplyModal-item-__index__company__name","position":"src-components-ApplyModal-item-__index__position","address":"src-components-ApplyModal-item-__index__address","bottom":"src-components-ApplyModal-item-__index__bottom","no__read":"src-components-ApplyModal-item-__index__no__read","have__read":"src-components-ApplyModal-item-__index__have__read","download":"src-components-ApplyModal-item-__index__download","mark":"src-components-ApplyModal-item-__index__mark"});
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/Chip/Chip.js + 2 modules
var Chip = __webpack_require__(34336);
// EXTERNAL MODULE: ./node_modules/.pnpm/react-router@6.22.3_react@18.2.0/node_modules/react-router/dist/index.js
var dist = __webpack_require__(66336);
;// CONCATENATED MODULE: ./src/components/ApplyModal/item/index.tsx







var Item = function Item(props) {
  var _data$company, _data$tag;
  var data = props.data,
    apply = props.apply,
    onClose = props.onClose;
  var navigate = (0,dist/* useNavigate */.i6)();
  var salary = (0,react.useMemo)(function () {
    return data !== null && data !== void 0 && data.isFace ? "面议" : "".concat(data.minSalary, "~").concat(data.maxSalary);
  }, [data]);
  var status = (0,react.useMemo)(function () {
    if (!apply.haveRead) {
      return /*#__PURE__*/react.createElement("div", {
        className: ApplyModal_item.no__read
      }, /*#__PURE__*/react.createElement("i", null), /*#__PURE__*/react.createElement("span", null, "\u672A\u8BFB"));
    }
    if (apply.isDownload) {
      return /*#__PURE__*/react.createElement("div", {
        className: ApplyModal_item.download
      }, /*#__PURE__*/react.createElement("i", {
        className: "iconfont icon-xiazai"
      }), /*#__PURE__*/react.createElement("span", null, "\u5DF2\u88AB\u4E0B\u8F7D"));
    }
    if (!apply.mark && apply.haveRead) {
      return /*#__PURE__*/react.createElement("div", {
        className: ApplyModal_item.have__read
      }, /*#__PURE__*/react.createElement("i", {
        className: "iconfont icon-yidu"
      }), /*#__PURE__*/react.createElement("span", null, "\u5DF2\u8BFB"));
    }
    if (apply.mark) {
      return /*#__PURE__*/react.createElement("div", {
        className: ApplyModal_item.mark
      }, /*#__PURE__*/react.createElement("i", {
        className: "iconfont icon-yishoucang"
      }), /*#__PURE__*/react.createElement("span", null, "\u5DF2\u88AB\u6807\u8BB0"));
    }
  }, [apply]);
  return /*#__PURE__*/react.createElement("div", {
    className: ApplyModal_item.item,
    onClick: function onClick() {
      navigate("job/".concat(apply.jobId));
      onClose && onClose();
    }
  }, /*#__PURE__*/react.createElement("div", {
    className: ApplyModal_item.top
  }, /*#__PURE__*/react.createElement("div", {
    className: ApplyModal_item.company__name
  }, /*#__PURE__*/react.createElement("span", null, (_data$company = data.company) === null || _data$company === void 0 ? void 0 : _data$company.name)), /*#__PURE__*/react.createElement("div", {
    className: ApplyModal_item.position
  }, /*#__PURE__*/react.createElement("span", null, data.name), /*#__PURE__*/react.createElement("span", null, salary)), /*#__PURE__*/react.createElement("div", {
    className: ApplyModal_item.address
  }, /*#__PURE__*/react.createElement("span", null, "\u5730\u5740\uFF1A"), /*#__PURE__*/react.createElement("span", null, data.location)), /*#__PURE__*/react.createElement("div", {
    className: ApplyModal_item.tag
  }, data === null || data === void 0 || (_data$tag = data.tag) === null || _data$tag === void 0 ? void 0 : _data$tag.split(",").map(function (item) {
    return /*#__PURE__*/react.createElement(Chip/* default */.c, {
      key: item,
      label: item,
      className: ApplyModal_item.chip,
      size: "small"
    });
  }), /*#__PURE__*/react.createElement(Chip/* default */.c, {
    key: data !== null && data !== void 0 && data.isRemote ? "支持远程" : "不支持远程",
    label: data !== null && data !== void 0 && data.isRemote ? "支持远程" : "不支持远程",
    className: ApplyModal_item.chip,
    size: "small"
  }))), /*#__PURE__*/react.createElement("div", {
    className: ApplyModal_item.bottom
  }, status));
};
;// CONCATENATED MODULE: ./src/components/ApplyModal/index.less
// extracted by mini-css-extract-plugin
/* harmony default export */ const ApplyModal = ({"container":"src-components-ApplyModal-__index__container","title":"src-components-ApplyModal-__index__title","list":"src-components-ApplyModal-__index__list","no__data":"src-components-ApplyModal-__index__no__data"});
// EXTERNAL MODULE: ./src/image/common/no-list.png
var no_list = __webpack_require__(37428);
// EXTERNAL MODULE: ./node_modules/.pnpm/antd-mobile@5.35.0_react-dom@18.2.0_react@18.2.0/node_modules/antd-mobile/es/index.js + 43 modules
var es = __webpack_require__(78576);
// EXTERNAL MODULE: ./src/store/index.ts + 4 modules
var store = __webpack_require__(75899);
// EXTERNAL MODULE: ./node_modules/.pnpm/classnames@2.5.1/node_modules/classnames/index.js
var classnames = __webpack_require__(10124);
var classnames_default = /*#__PURE__*/__webpack_require__.n(classnames);
;// CONCATENATED MODULE: ./src/components/ApplyModal/index.tsx















function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }








var ApplyModal_ApplyModal = /*#__PURE__*/(0,react.forwardRef)(function (props, ref) {
  var _onClose = props.onClose;
  var _useState = (0,react.useState)(false),
    _useState2 = _slicedToArray(_useState, 2),
    open = _useState2[0],
    setOpen = _useState2[1];
  // const [list, setList] = useState<IApply>([]);
  var pageRef = (0,react.useRef)(1);
  var sizeRef = (0,react.useRef)(100);
  var _useApplyStore = (0,store/* useApplyStore */.Mn)(),
    getApplyList = _useApplyStore.getApplyList,
    hasMore = _useApplyStore.hasMore,
    refresh = _useApplyStore.refresh,
    refreshing = _useApplyStore.refreshing,
    first = _useApplyStore.first,
    applyList = _useApplyStore.applyList;
  var handleOpen = function handleOpen() {
    setOpen(true);
  };
  var handleClose = function handleClose() {
    setOpen(false);
  };
  // const handleGetApply = async () => {
  //   const { result } = await getApplySelf({
  //     pageNum: pageRef.current,
  //     pageSize: sizeRef.current,
  //   });
  //   setList(result.list);
  // };
  // useEffect(() => {
  //   handleGetApply();
  // }, []);
  (0,react.useImperativeHandle)(ref, function () {
    return {
      handleClose: handleClose,
      handleOpen: handleOpen
    };
  });
  return /*#__PURE__*/react.createElement(Modal/* default */.c, {
    open: open,
    "aria-labelledby": "modal-modal-title",
    "aria-describedby": "modal-modal-description",
    onClose: function onClose() {
      setOpen(false);
    }
  }, /*#__PURE__*/react.createElement("div", {
    className: ApplyModal.container
  }, /*#__PURE__*/react.createElement("div", {
    className: ApplyModal.title
  }, /*#__PURE__*/react.createElement("span", null, "\u6295\u9012\u5217\u8868")), /*#__PURE__*/react.createElement("div", {
    className: ApplyModal.list
  }, /*#__PURE__*/react.createElement(es/* PullToRefresh */.cd, {
    onRefresh: function onRefresh() {
      refresh();
      return getApplyList();
    }
  }, applyList.map(function (item) {
    return /*#__PURE__*/react.createElement(Item, {
      key: item.id,
      data: item.job,
      apply: item,
      onClose: function onClose() {
        setOpen(false);
        _onClose && _onClose();
      }
    });
  }), applyList.length === 0 && /*#__PURE__*/react.createElement("div", {
    className: ApplyModal.no__data
  }, /*#__PURE__*/react.createElement("img", {
    src: no_list
  }), /*#__PURE__*/react.createElement("span", null, "\u6682\u65F6\u8FD8\u6CA1\u6709\u6295\u9012")), !refreshing && (first || applyList.length > 0) && /*#__PURE__*/react.createElement(es/* InfiniteScroll */.kl, {
    hasMore: hasMore,
    loadMore: getApplyList,
    className: classnames_default()(ApplyModal.footer)
  })))));
});

/***/ }),

/***/ 27444:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   k: () => (/* binding */ AuthBtn)
/* harmony export */ });
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(42856);
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(63397);
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_symbol_async_iterator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(44024);
/* harmony import */ var core_js_modules_es_symbol_async_iterator_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_async_iterator_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_symbol_iterator_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(54000);
/* harmony import */ var core_js_modules_es_symbol_iterator_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_iterator_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_symbol_to_string_tag_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(78264);
/* harmony import */ var core_js_modules_es_symbol_to_string_tag_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_to_string_tag_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(36160);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(37180);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_for_each_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(93552);
/* harmony import */ var core_js_modules_es_array_for_each_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_for_each_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(67972);
/* harmony import */ var core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_array_is_array_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(29448);
/* harmony import */ var core_js_modules_es_array_is_array_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_is_array_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(44272);
/* harmony import */ var core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_array_reverse_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(51136);
/* harmony import */ var core_js_modules_es_array_reverse_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reverse_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(72344);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_date_to_string_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(28612);
/* harmony import */ var core_js_modules_es_date_to_string_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_date_to_string_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(26572);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_json_to_string_tag_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(70048);
/* harmony import */ var core_js_modules_es_json_to_string_tag_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_to_string_tag_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_math_to_string_tag_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(97304);
/* harmony import */ var core_js_modules_es_math_to_string_tag_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_math_to_string_tag_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_object_create_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(66056);
/* harmony import */ var core_js_modules_es_object_create_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_create_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_object_define_property_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(55888);
/* harmony import */ var core_js_modules_es_object_define_property_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_define_property_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_object_get_prototype_of_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(98232);
/* harmony import */ var core_js_modules_es_object_get_prototype_of_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_get_prototype_of_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_object_set_prototype_of_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(37456);
/* harmony import */ var core_js_modules_es_object_set_prototype_of_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_set_prototype_of_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(88012);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_es_promise_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(75908);
/* harmony import */ var core_js_modules_es_promise_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_promise_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(23784);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(81852);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(13755);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(23408);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(22248);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(96651);
/* harmony import */ var wagmi__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(12984);
/* harmony import */ var wagmi__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(13480);
/* harmony import */ var wagmi__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(79576);
/* harmony import */ var siwe__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(73436);
/* harmony import */ var siwe__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(siwe__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var _api_user__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(85488);
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(75899);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(80180);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(98448);
/* harmony import */ var _utils_platform__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(4371);
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == _typeof(h) && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator["return"] && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(_typeof(e) + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, "catch": function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }




























function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }








var AuthBtn = function AuthBtn(props) {
  var _onClick = props.onClick,
    children = props.children,
    className = props.className,
    share = props.share;
  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_28__.useState)(false),
    _useState2 = _slicedToArray(_useState, 2),
    ready = _useState2[0],
    setReady = _useState2[1];
  var _userUserStore = (0,_store__WEBPACK_IMPORTED_MODULE_31__/* .userUserStore */ .Wu)(),
    updateToken = _userUserStore.updateToken,
    getCurrentUser = _userUserStore.getCurrentUser;
  var _useSignMessage = (0,wagmi__WEBPACK_IMPORTED_MODULE_34__/* .useSignMessage */ .S)(),
    signMessageAsync = _useSignMessage.signMessageAsync;
  var _useConnect = (0,wagmi__WEBPACK_IMPORTED_MODULE_35__/* .useConnect */ .i)(),
    connectors = _useConnect.connectors,
    connect = _useConnect.connect;
  var _useAccount = (0,wagmi__WEBPACK_IMPORTED_MODULE_36__/* .useAccount */ .g)(),
    isConnected = _useAccount.isConnected,
    address = _useAccount.address;
  var _userUserStore2 = (0,_store__WEBPACK_IMPORTED_MODULE_31__/* .userUserStore */ .Wu)(),
    userInfo = _userUserStore2.userInfo;
  var connector = (0,react__WEBPACK_IMPORTED_MODULE_28__.useMemo)(function () {
    var item = connectors.find(function (item) {
      return item.id === "io.metamask";
    });
    return item;
  }, [connectors]);
  var handleConnect = function handleConnect() {
    if ((0,_utils_platform__WEBPACK_IMPORTED_MODULE_33__/* .isMobile */ .y)()) {
      (0,react_hot_toast__WEBPACK_IMPORTED_MODULE_32__/* ["default"] */ .cp)("需要去pc端打开申请哦", {
        icon: "😬",
        duration: 5000
      });
      return;
    }
    if (!connector) {
      (0,react_hot_toast__WEBPACK_IMPORTED_MODULE_32__/* ["default"] */ .cp)("这里需要先下载metaMask钱包", {
        icon: "😬",
        duration: 5000
      });
      return;
    }
    connect({
      connector: connector
    });
  };
  function createSiweMessage(_x, _x2) {
    return _createSiweMessage.apply(this, arguments);
  }
  function _createSiweMessage() {
    _createSiweMessage = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee(address, statement) {
      var domain, origin, _yield$getNonce, result, message;
      return _regeneratorRuntime().wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            domain = window.location.host;
            origin = window.location.origin;
            _context.next = 4;
            return (0,_api_user__WEBPACK_IMPORTED_MODULE_30__/* .getNonce */ .es)();
          case 4:
            _yield$getNonce = _context.sent;
            result = _yield$getNonce.result;
            message = new siwe__WEBPACK_IMPORTED_MODULE_29__.SiweMessage({
              domain: domain,
              address: address,
              statement: statement,
              uri: origin,
              version: "1",
              chainId: 1,
              nonce: result.nonce
            });
            return _context.abrupt("return", message.prepareMessage());
          case 8:
          case "end":
            return _context.stop();
        }
      }, _callee);
    }));
    return _createSiweMessage.apply(this, arguments);
  }
  function signInWithEthereum() {
    return _signInWithEthereum.apply(this, arguments);
  }
  function _signInWithEthereum() {
    _signInWithEthereum = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
      var message, signature, shareList, _yield$login, result;
      return _regeneratorRuntime().wrap(function _callee2$(_context2) {
        while (1) switch (_context2.prev = _context2.next) {
          case 0:
            if (!(0,_utils_platform__WEBPACK_IMPORTED_MODULE_33__/* .isMobile */ .y)()) {
              _context2.next = 3;
              break;
            }
            (0,react_hot_toast__WEBPACK_IMPORTED_MODULE_32__/* ["default"] */ .cp)("需要去pc端打开申请哦", {
              icon: "😬",
              duration: 5000
            });
            return _context2.abrupt("return");
          case 3:
            _context2.prev = 3;
            _context2.next = 6;
            return createSiweMessage(address, "Sign in with Ethereum to the app.");
          case 6:
            message = _context2.sent;
            _context2.next = 9;
            return signMessageAsync({
              message: message,
              account: address
            });
          case 9:
            signature = _context2.sent;
            shareList = [share, localStorage.getItem("address")].filter(function (item) {
              return item;
            });
            _context2.next = 13;
            return (0,_api_user__WEBPACK_IMPORTED_MODULE_30__/* .login */ .Mp)({
              signature: signature,
              message: message,
              share: shareList
            });
          case 13:
            _yield$login = _context2.sent;
            result = _yield$login.result;
            updateToken(result.token);
            localStorage.setItem("token", result.token);
            getCurrentUser();
            _context2.next = 23;
            break;
          case 20:
            _context2.prev = 20;
            _context2.t0 = _context2["catch"](3);
            console.log(_context2.t0, "fsdfs");
          case 23:
          case "end":
            return _context2.stop();
        }
      }, _callee2, null, [[3, 20]]);
    }));
    return _signInWithEthereum.apply(this, arguments);
  }
  var renderChildren = function renderChildren() {
    if (!isConnected) {
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_28__.createElement(_mui_material_Button__WEBPACK_IMPORTED_MODULE_37__/* ["default"] */ .c, null, "connect wallet");
    }
    if (!userInfo.address) {
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_28__.createElement(_mui_material_Button__WEBPACK_IMPORTED_MODULE_37__/* ["default"] */ .c, null, "login in");
    }
    return children;
  };
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_28__.createElement("div", {
    className: className,
    onClick: function onClick() {
      if (!isConnected) {
        handleConnect();
        return;
      }
      if (!userInfo.address) {
        signInWithEthereum();
        return;
      }
      _onClick && _onClick();
    }
  }, renderChildren());
};

/***/ }),

/***/ 11008:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  C: () => (/* binding */ Ellipsis)
});

// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.js
var es_symbol = __webpack_require__(42856);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.description.js
var es_symbol_description = __webpack_require__(63397);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.iterator.js
var es_symbol_iterator = __webpack_require__(54000);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.from.js
var es_array_from = __webpack_require__(67972);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.is-array.js
var es_array_is_array = __webpack_require__(29448);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.iterator.js
var es_array_iterator = __webpack_require__(44272);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.slice.js
var es_array_slice = __webpack_require__(72344);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.date.to-string.js
var es_date_to_string = __webpack_require__(28612);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__(26572);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__(88012);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__(23784);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.regexp.to-string.js
var es_regexp_to_string = __webpack_require__(81852);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.string.iterator.js
var es_string_iterator = __webpack_require__(13755);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/web.dom-collections.iterator.js
var web_dom_collections_iterator = __webpack_require__(22248);
// EXTERNAL MODULE: ./node_modules/.pnpm/react@18.2.0/node_modules/react/index.js
var react = __webpack_require__(96651);
// EXTERNAL MODULE: ./node_modules/.pnpm/classnames@2.5.1/node_modules/classnames/index.js
var classnames = __webpack_require__(10124);
var classnames_default = /*#__PURE__*/__webpack_require__.n(classnames);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/Tooltip/Tooltip.js + 2 modules
var Tooltip = __webpack_require__(95824);
;// CONCATENATED MODULE: ./src/components/Ellipsis/index.less
// extracted by mini-css-extract-plugin
/* harmony default export */ const components_Ellipsis = ({"ellipsis":"src-components-Ellipsis-__index__ellipsis","ellipsis--input":"src-components-Ellipsis-__index__ellipsis--input","ellipsis--text":"src-components-Ellipsis-__index__ellipsis--text","ellipsis--button":"src-components-Ellipsis-__index__ellipsis--button","ellipsis--slide":"src-components-Ellipsis-__index__ellipsis--slide"});
;// CONCATENATED MODULE: ./src/components/Ellipsis/index.tsx














function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }




var Ellipsis = function Ellipsis(props) {
  var className = props.className,
    content = props.content,
    contentClass = props.contentClass,
    style = props.style;
  var labelRef = (0,react.useRef)(null);
  var _useState = (0,react.useState)(0),
    _useState2 = _slicedToArray(_useState, 2),
    marginBottom = _useState2[0],
    setMarginBottom = _useState2[1];
  (0,react.useEffect)(function () {
    var _labelRef$current;
    setMarginBottom(labelRef === null || labelRef === void 0 || (_labelRef$current = labelRef.current) === null || _labelRef$current === void 0 ? void 0 : _labelRef$current.offsetHeight);
  }, []);
  return /*#__PURE__*/react.createElement("div", {
    className: classnames_default()(components_Ellipsis.ellipsis, className),
    style: style
  }, /*#__PURE__*/react.createElement("input", {
    type: "checkbox",
    id: "exp",
    className: components_Ellipsis["ellipsis--input"]
  }), /*#__PURE__*/react.createElement("div", {
    className: classnames_default()(components_Ellipsis["ellipsis--text"], contentClass)
  }, /*#__PURE__*/react.createElement("div", {
    className: components_Ellipsis["ellipsis--slide"],
    style: {
      marginBottom: -marginBottom
    }
  }), /*#__PURE__*/react.createElement(Tooltip/* default */.c, {
    title: content
  }, /*#__PURE__*/react.createElement("label", {
    className: components_Ellipsis["ellipsis--button"]
    // htmlFor="exp"
    ,
    ref: labelRef
  })), content));
};

/***/ }),

/***/ 39108:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   I: () => (/* binding */ EllipsisMiddle)
/* harmony export */ });
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(42856);
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(63397);
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_symbol_iterator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(54000);
/* harmony import */ var core_js_modules_es_symbol_iterator_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_iterator_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(70516);
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(67972);
/* harmony import */ var core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_from_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_is_array_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(29448);
/* harmony import */ var core_js_modules_es_array_is_array_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_is_array_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(44272);
/* harmony import */ var core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(72344);
/* harmony import */ var core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_slice_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_date_to_string_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(28612);
/* harmony import */ var core_js_modules_es_date_to_string_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_date_to_string_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(26572);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(88012);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(23784);
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(81852);
/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(13755);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(51883);
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(22248);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(10124);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(96651);
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }


















var EllipsisMiddle = function EllipsisMiddle(props) {
  var value = props.value,
    suffixCount = props.suffixCount,
    className = props.className,
    children = props.children,
    onClick = props.onClick;
  var start = value.slice(0, suffixCount).trim();
  var suffix = value.slice(-suffixCount).trim();
  var _React$useState = react__WEBPACK_IMPORTED_MODULE_17__.useState(null),
    _React$useState2 = _slicedToArray(_React$useState, 2),
    anchorEl = _React$useState2[0],
    setAnchorEl = _React$useState2[1];
  var handleClose = function handleClose() {
    setAnchorEl(null);
  };
  var open = Boolean(anchorEl);
  var renderText = function renderText() {
    if (value.length > 2 * suffixCount) {
      return "".concat(start, ".....").concat(suffix);
    }
    return value;
  };
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_17__.createElement(react__WEBPACK_IMPORTED_MODULE_17__.Fragment, null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_17__.createElement("span", {
    className: classnames__WEBPACK_IMPORTED_MODULE_16___default()(className),
    onClick: onClick
  }, renderText()))
  // </Tooltip>
  ;
};

/***/ }),

/***/ 97144:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  W: () => (/* binding */ Image)
});

// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.js
var es_symbol = __webpack_require__(42856);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.description.js
var es_symbol_description = __webpack_require__(63397);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.iterator.js
var es_symbol_iterator = __webpack_require__(54000);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.from.js
var es_array_from = __webpack_require__(67972);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.is-array.js
var es_array_is_array = __webpack_require__(29448);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.iterator.js
var es_array_iterator = __webpack_require__(44272);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.slice.js
var es_array_slice = __webpack_require__(72344);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.date.to-string.js
var es_date_to_string = __webpack_require__(28612);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__(26572);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__(88012);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__(23784);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.regexp.to-string.js
var es_regexp_to_string = __webpack_require__(81852);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.string.iterator.js
var es_string_iterator = __webpack_require__(13755);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/web.dom-collections.iterator.js
var web_dom_collections_iterator = __webpack_require__(22248);
// EXTERNAL MODULE: ./node_modules/.pnpm/react@18.2.0/node_modules/react/index.js
var react = __webpack_require__(96651);
// EXTERNAL MODULE: ./node_modules/.pnpm/classnames@2.5.1/node_modules/classnames/index.js
var classnames = __webpack_require__(10124);
var classnames_default = /*#__PURE__*/__webpack_require__.n(classnames);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/Skeleton/Skeleton.js + 3 modules
var Skeleton = __webpack_require__(17004);
;// CONCATENATED MODULE: ./src/components/Image/index.less
// extracted by mini-css-extract-plugin
/* harmony default export */ const components_Image = ({"image":"src-components-Image-__index__image","skeleton":"src-components-Image-__index__skeleton"});
;// CONCATENATED MODULE: ./src/components/Image/index.tsx














function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }




var Image = function Image(props) {
  var className = props.className,
    style = props.style,
    src = props.src;
  var _useState = (0,react.useState)(true),
    _useState2 = _slicedToArray(_useState, 2),
    load = _useState2[0],
    setLoad = _useState2[1];
  var _useState3 = (0,react.useState)(""),
    _useState4 = _slicedToArray(_useState3, 2),
    url = _useState4[0],
    setUrl = _useState4[1];
  return /*#__PURE__*/react.createElement("div", {
    className: classnames_default()(className, components_Image.image),
    style: style
  }, load ? /*#__PURE__*/react.createElement(Skeleton/* default */.c, {
    variant: "rounded",
    width: "100%",
    height: "100%",
    className: components_Image.skeleton
  }) : /*#__PURE__*/react.createElement(react.Fragment, null), /*#__PURE__*/react.createElement("img", {
    src: src,
    alt: "",
    onLoad: function onLoad() {
      setLoad(false);
    }
  }));
};

/***/ })

}]);