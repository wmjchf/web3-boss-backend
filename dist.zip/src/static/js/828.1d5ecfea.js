"use strict";
(self["webpackChunkweb3_design_style"] = self["webpackChunkweb3_design_style"] || []).push([[828],{

/***/ 50448:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  u: () => (/* binding */ Comfirm)
});

// EXTERNAL MODULE: ./node_modules/.pnpm/react@18.2.0/node_modules/react/index.js
var react = __webpack_require__(96651);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/Button/Button.js + 3 modules
var Button = __webpack_require__(80180);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/Modal/Modal.js + 4 modules
var Modal = __webpack_require__(87492);
;// CONCATENATED MODULE: ./src/components/ComfirmDelete/index.less
// extracted by mini-css-extract-plugin
/* harmony default export */ const ComfirmDelete = ({"container":"src-components-ComfirmDelete-__index__container","tip":"src-components-ComfirmDelete-__index__tip","bottom":"src-components-ComfirmDelete-__index__bottom","cancel":"src-components-ComfirmDelete-__index__cancel"});
;// CONCATENATED MODULE: ./src/components/ComfirmDelete/index.tsx




var Comfirm = function Comfirm(props) {
  var open = props.open,
    onClose = props.onClose,
    onConfirm = props.onConfirm,
    tip = props.tip,
    _props$confirmText = props.confirmText,
    confirmText = _props$confirmText === void 0 ? "确定" : _props$confirmText;
  return /*#__PURE__*/react.createElement(Modal/* default */.c, {
    open: open,
    onClose: onClose,
    "aria-labelledby": "modal-modal-title",
    "aria-describedby": "modal-modal-description"
  }, /*#__PURE__*/react.createElement("div", {
    className: ComfirmDelete.container
  }, /*#__PURE__*/react.createElement("div", {
    className: ComfirmDelete.tip
  }, tip), /*#__PURE__*/react.createElement("div", {
    className: ComfirmDelete.bottom
  }, /*#__PURE__*/react.createElement(Button/* default */.c, {
    variant: "outlined",
    className: ComfirmDelete.cancel,
    onClick: onClose
  }, "\u53D6\u6D88"), /*#__PURE__*/react.createElement(Button/* default */.c, {
    variant: "contained",
    onClick: onConfirm
  }, confirmText))));
};

/***/ }),

/***/ 1828:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ src_page_Job)
});

// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.js
var es_symbol = __webpack_require__(42856);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.description.js
var es_symbol_description = __webpack_require__(63397);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.async-iterator.js
var es_symbol_async_iterator = __webpack_require__(44024);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.iterator.js
var es_symbol_iterator = __webpack_require__(54000);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.to-string-tag.js
var es_symbol_to_string_tag = __webpack_require__(78264);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.concat.js
var es_array_concat = __webpack_require__(70516);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.for-each.js
var es_array_for_each = __webpack_require__(93552);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.from.js
var es_array_from = __webpack_require__(67972);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.is-array.js
var es_array_is_array = __webpack_require__(29448);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.iterator.js
var es_array_iterator = __webpack_require__(44272);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__(18440);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.reverse.js
var es_array_reverse = __webpack_require__(51136);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.slice.js
var es_array_slice = __webpack_require__(72344);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.date.to-string.js
var es_date_to_string = __webpack_require__(28612);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__(26572);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.json.to-string-tag.js
var es_json_to_string_tag = __webpack_require__(70048);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.math.to-string-tag.js
var es_math_to_string_tag = __webpack_require__(97304);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.object.create.js
var es_object_create = __webpack_require__(66056);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.object.define-property.js
var es_object_define_property = __webpack_require__(55888);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.object.get-prototype-of.js
var es_object_get_prototype_of = __webpack_require__(98232);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.object.set-prototype-of.js
var es_object_set_prototype_of = __webpack_require__(37456);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__(88012);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.parse-int.js
var es_parse_int = __webpack_require__(67936);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.promise.js
var es_promise = __webpack_require__(75908);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__(23784);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.regexp.to-string.js
var es_regexp_to_string = __webpack_require__(81852);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.string.iterator.js
var es_string_iterator = __webpack_require__(13755);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__(99812);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/web.dom-collections.for-each.js
var web_dom_collections_for_each = __webpack_require__(23408);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/web.dom-collections.iterator.js
var web_dom_collections_iterator = __webpack_require__(22248);
// EXTERNAL MODULE: ./node_modules/.pnpm/react@18.2.0/node_modules/react/index.js
var react = __webpack_require__(96651);
// EXTERNAL MODULE: ./node_modules/.pnpm/react-hot-toast@2.4.1_csstype@3.1.3_react-dom@18.2.0_react@18.2.0/node_modules/react-hot-toast/dist/index.mjs
var dist = __webpack_require__(98448);
;// CONCATENATED MODULE: ./src/page/Job/index.less
// extracted by mini-css-extract-plugin
/* harmony default export */ const page_Job = ({"job":"src-page-Job-__index__job","container":"src-page-Job-__index__container","operation":"src-page-Job-__index__operation","company":"src-page-Job-__index__company","content":"src-page-Job-__index__content","name":"src-page-Job-__index__name","salary":"src-page-Job-__index__salary","tag":"src-page-Job-__index__tag","chip":"src-page-Job-__index__chip","location":"src-page-Job-__index__location","description":"src-page-Job-__index__description","apply":"src-page-Job-__index__apply","resume__list":"src-page-Job-__index__resume__list","title":"src-page-Job-__index__title","top":"src-page-Job-__index__top","active":"src-page-Job-__index__active","bottom":"src-page-Job-__index__bottom","wrap":"src-page-Job-__index__wrap","pagination":"src-page-Job-__index__pagination","no__data":"src-page-Job-__index__no__data","none":"src-page-Job-__index__none"});
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/Pagination/Pagination.js + 8 modules
var Pagination = __webpack_require__(9616);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/Chip/Chip.js + 2 modules
var Chip = __webpack_require__(34336);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/Button/Button.js + 3 modules
var Button = __webpack_require__(80180);
// EXTERNAL MODULE: ./node_modules/.pnpm/react-router@6.22.3_react@18.2.0/node_modules/react-router/dist/index.js
var react_router_dist = __webpack_require__(66336);
// EXTERNAL MODULE: ./src/api/job.ts
var job = __webpack_require__(70348);
// EXTERNAL MODULE: ./src/store/index.ts + 4 modules
var store = __webpack_require__(75899);
// EXTERNAL MODULE: ./src/components/AuthBtn/index.tsx
var AuthBtn = __webpack_require__(27444);
// EXTERNAL MODULE: ./src/image/common/no-list.png
var no_list = __webpack_require__(37428);
// EXTERNAL MODULE: ./src/components/ApplyItem/index.tsx + 1 modules
var ApplyItem = __webpack_require__(75088);
// EXTERNAL MODULE: ./node_modules/.pnpm/antd@5.14.0_react-dom@18.2.0_react@18.2.0/node_modules/antd/es/upload/index.js + 34 modules
var upload = __webpack_require__(10700);
// EXTERNAL MODULE: ./src/page/Company/components/Introduce/index.tsx + 1 modules
var Introduce = __webpack_require__(56176);
// EXTERNAL MODULE: ./src/api/resume.ts
var resume = __webpack_require__(60704);
// EXTERNAL MODULE: ./src/api/apply.ts
var apply = __webpack_require__(85768);
// EXTERNAL MODULE: ./node_modules/.pnpm/classnames@2.5.1/node_modules/classnames/index.js
var classnames = __webpack_require__(10124);
var classnames_default = /*#__PURE__*/__webpack_require__.n(classnames);
// EXTERNAL MODULE: ./src/components/ComfirmDelete/index.tsx + 1 modules
var ComfirmDelete = __webpack_require__(50448);
// EXTERNAL MODULE: ./src/constant/index.ts
var constant = __webpack_require__(39784);
// EXTERNAL MODULE: ./src/components/ResumeModal/index.tsx + 1 modules
var ResumeModal = __webpack_require__(98792);
// EXTERNAL MODULE: ./src/request/index.ts
var request = __webpack_require__(58772);
;// CONCATENATED MODULE: ./src/api/common.ts

var download = function download(data) {
  return (0,request/* post */.s$)("/common/download", data);
};
;// CONCATENATED MODULE: ./src/utils/downloadOss.ts
var downloadOss = function downloadOss(url, filename) {
  var link = document.createElement("a");
  link.style.display = "none";
  link.href = url;
  link.setAttribute("download", filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};
;// CONCATENATED MODULE: ./src/page/Job/index.tsx
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == _typeof(h) && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator["return"] && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(_typeof(e) + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, "catch": function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }




















































var PdfPreview = /*#__PURE__*/(0,react.lazy)(function () {
  return Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 26756));
});
var Job = function Job() {
  var _detail$company5, _detail$company6, _detail$tag, _detail$company7;
  var _useParams = (0,react_router_dist/* useParams */.W4)(),
    id = _useParams.id;
  var navigate = (0,react_router_dist/* useNavigate */.i6)();
  var resumeModalRef = (0,react.useRef)(0);
  // hr查询申请的时候
  var _useState = (0,react.useState)(),
    _useState2 = _slicedToArray(_useState, 2),
    currentApply = _useState2[0],
    setCurrentApply = _useState2[1];
  var _useState3 = (0,react.useState)(),
    _useState4 = _slicedToArray(_useState3, 2),
    detail = _useState4[0],
    setDetail = _useState4[1];
  var _useState5 = (0,react.useState)(),
    _useState6 = _slicedToArray(_useState5, 2),
    applyInfo = _useState6[0],
    setApplyInfo = _useState6[1];
  var _useState7 = (0,react.useState)([]),
    _useState8 = _slicedToArray(_useState7, 2),
    noReadList = _useState8[0],
    setNoReadList = _useState8[1];
  var _useState9 = (0,react.useState)(1),
    _useState10 = _slicedToArray(_useState9, 2),
    noReadPage = _useState10[0],
    setNoReadPage = _useState10[1];
  var _useState11 = (0,react.useState)(0),
    _useState12 = _slicedToArray(_useState11, 2),
    noReadTotal = _useState12[0],
    setNoReadTotal = _useState12[1];
  var _useState13 = (0,react.useState)([]),
    _useState14 = _slicedToArray(_useState13, 2),
    haveReadList = _useState14[0],
    setHaveReadList = _useState14[1];
  var _useState15 = (0,react.useState)(1),
    _useState16 = _slicedToArray(_useState15, 2),
    haveReadPage = _useState16[0],
    setHaveReadPage = _useState16[1];
  var _useState17 = (0,react.useState)(0),
    _useState18 = _slicedToArray(_useState17, 2),
    haveReadTotal = _useState18[0],
    setHaveReadTotal = _useState18[1];
  var _useState19 = (0,react.useState)([]),
    _useState20 = _slicedToArray(_useState19, 2),
    markList = _useState20[0],
    setMarkList = _useState20[1];
  var _useState21 = (0,react.useState)(1),
    _useState22 = _slicedToArray(_useState21, 2),
    markPage = _useState22[0],
    setMarkPage = _useState22[1];
  var _useState23 = (0,react.useState)(0),
    _useState24 = _slicedToArray(_useState23, 2),
    markTotal = _useState24[0],
    setMarkTotal = _useState24[1];
  var _userUserStore = (0,store/* userUserStore */.Wu)(),
    userInfo = _userUserStore.userInfo,
    getCurrentUser = _userUserStore.getCurrentUser,
    token = _userUserStore.token;
  var _useState25 = (0,react.useState)("0"),
    _useState26 = _slicedToArray(_useState25, 2),
    current = _useState26[0],
    setCurrent = _useState26[1];
  var userId = userInfo.id;
  var pdfPreviewRef = (0,react.useRef)();
  var _useState27 = (0,react.useState)(false),
    _useState28 = _slicedToArray(_useState27, 2),
    shareOpen = _useState28[0],
    setShareOpen = _useState28[1];
  var pdfPreviewRef1 = (0,react.useRef)();
  var _useJobListStore = (0,store/* useJobListStore */.SC)(),
    closeConfirm = _useJobListStore.closeConfirm,
    deleteJob = _useJobListStore.deleteJob,
    openConfirm = _useJobListStore.openConfirm,
    confirmOpen = _useJobListStore.confirmOpen,
    applyOpen = _useJobListStore.applyOpen,
    downlaodOpen = _useJobListStore.downlaodOpen,
    openApply = _useJobListStore.openApply,
    closeApply = _useJobListStore.closeApply,
    closeDownlaod = _useJobListStore.closeDownlaod;
  var _useState29 = (0,react.useState)(0),
    _useState30 = _slicedToArray(_useState29, 2),
    select = _useState30[0],
    setSelect = _useState30[1];
  var handleGetJobInfo = /*#__PURE__*/function () {
    var _ref = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
      var _yield$getJobDetail, result;
      return _regeneratorRuntime().wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0,job/* getJobDetail */.It)(parseInt(id));
          case 2:
            _yield$getJobDetail = _context.sent;
            result = _yield$getJobDetail.result;
            setDetail(result);
          case 5:
          case "end":
            return _context.stop();
        }
      }, _callee);
    }));
    return function handleGetJobInfo() {
      return _ref.apply(this, arguments);
    };
  }();
  // 申请人的apply，看是否有申请过
  var handleGetApply = /*#__PURE__*/function () {
    var _ref2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
      var _yield$getApplySelf, result;
      return _regeneratorRuntime().wrap(function _callee2$(_context2) {
        while (1) switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;
            _context2.next = 3;
            return (0,apply/* getApplySelf */.a8)({
              jobId: detail === null || detail === void 0 ? void 0 : detail.id
            });
          case 3:
            _yield$getApplySelf = _context2.sent;
            result = _yield$getApplySelf.result;
            setApplyInfo(result.list[0]);
            _context2.next = 10;
            break;
          case 8:
            _context2.prev = 8;
            _context2.t0 = _context2["catch"](0);
          case 10:
          case "end":
            return _context2.stop();
        }
      }, _callee2, null, [[0, 8]]);
    }));
    return function handleGetApply() {
      return _ref2.apply(this, arguments);
    };
  }();
  var handleGetApplyList = /*#__PURE__*/function () {
    var _ref3 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee3(data) {
      var _yield$getApplyList, result;
      return _regeneratorRuntime().wrap(function _callee3$(_context3) {
        while (1) switch (_context3.prev = _context3.next) {
          case 0:
            _context3.prev = 0;
            _context3.next = 3;
            return (0,apply/* getApplyList */.O)(data);
          case 3:
            _yield$getApplyList = _context3.sent;
            result = _yield$getApplyList.result;
            return _context3.abrupt("return", result);
          case 8:
            _context3.prev = 8;
            _context3.t0 = _context3["catch"](0);
          case 10:
          case "end":
            return _context3.stop();
        }
      }, _callee3, null, [[0, 8]]);
    }));
    return function handleGetApplyList(_x) {
      return _ref3.apply(this, arguments);
    };
  }();

  // useEffect(() => {
  //   if (id && token) {
  //     handleGetApplyList({ jobId: id, haveRead: "0" })
  //       .then((res) => {
  //         setNoReadList(res.list);
  //         setNoReadTotal(res.total);
  //       })
  //       .catch((error) => {});
  //     handleGetApplyList({ jobId: id, haveRead: "1", mark: "0" })
  //       .then((res) => {
  //         setHaveReadList(res.list);
  //         setHaveReadTotal(res.total);
  //       })
  //       .catch((error) => {});
  //     handleGetApplyList({ jobId: id, haveRead: "1", mark: "1" })
  //       .then((res) => {
  //         setMarkList(res.list);
  //         setMarkTotal(res.total);
  //       })
  //       .catch((error) => {});
  //   }
  // }, [id, token]);

  (0,react.useEffect)(function () {
    var _detail$company;
    if (userId !== (detail === null || detail === void 0 || (_detail$company = detail.company) === null || _detail$company === void 0 ? void 0 : _detail$company.userId) && detail !== null && detail !== void 0 && detail.id) {
      handleGetApply();
    }
  }, [userId, detail]);
  (0,react.useEffect)(function () {
    if (id && token && noReadPage) {
      handleGetApplyList({
        jobId: id,
        haveRead: "0",
        pageNum: noReadPage,
        pageSize: 12
      }).then(function (res) {
        setNoReadList(res.list);
        setNoReadTotal(res.total);
      })["catch"](function (error) {});
    }
  }, [noReadPage, id, token]);
  (0,react.useEffect)(function () {
    if (id && token && haveReadPage) {
      handleGetApplyList({
        jobId: id,
        haveRead: "1",
        mark: "0",
        pageNum: haveReadPage,
        pageSize: 12
      }).then(function (res) {
        setHaveReadList(res.list);
        setHaveReadTotal(res.total);
      })["catch"](function (error) {});
    }
  }, [haveReadPage, id, token]);
  (0,react.useEffect)(function () {
    var _userInfo$resumes$;
    (userInfo === null || userInfo === void 0 ? void 0 : userInfo.resumes[0]) && setSelect(userInfo === null || userInfo === void 0 || (_userInfo$resumes$ = userInfo.resumes[0]) === null || _userInfo$resumes$ === void 0 ? void 0 : _userInfo$resumes$.id);
  }, [userInfo]);
  (0,react.useEffect)(function () {
    if (id && token && markPage) {
      handleGetApplyList({
        jobId: id,
        haveRead: "1",
        mark: "1",
        pageNum: markPage,
        pageSize: 12
      }).then(function (res) {
        setMarkList(res.list);
        setMarkTotal(res.total);
      })["catch"](function (error) {});
    }
  }, [markPage, id, token]);
  (0,react.useEffect)(function () {
    if (id) {
      handleGetJobInfo();
    }
  }, []);
  var salary = (0,react.useMemo)(function () {
    return detail !== null && detail !== void 0 && detail.isFace ? "面议" : "".concat(detail === null || detail === void 0 ? void 0 : detail.minSalary, "~").concat(detail === null || detail === void 0 ? void 0 : detail.maxSalary);
  }, [detail]);
  var renderBtn = function renderBtn() {
    var _detail$company2;
    if ((detail === null || detail === void 0 || (_detail$company2 = detail.company) === null || _detail$company2 === void 0 ? void 0 : _detail$company2.userId) !== userId) {
      var _userInfo$resumes;
      if ((userInfo === null || userInfo === void 0 || (_userInfo$resumes = userInfo.resumes) === null || _userInfo$resumes === void 0 ? void 0 : _userInfo$resumes.length) === 0) {
        var _detail$company3;
        return /*#__PURE__*/react.createElement(AuthBtn/* AuthBtn */.k, {
          share: detail === null || detail === void 0 || (_detail$company3 = detail.company) === null || _detail$company3 === void 0 || (_detail$company3 = _detail$company3.user) === null || _detail$company3 === void 0 ? void 0 : _detail$company3.address
        }, /*#__PURE__*/react.createElement(upload/* default */.c, {
          action: "".concat(constant/* BASE_URL */.yk, "/common/upload"),
          accept: ".pdf",
          showUploadList: false,
          headers: {
            Authorization: "Bearer ".concat(localStorage.getItem("token"))
          },
          onChange: function onChange(event) {
            var _event$file, _event$file2;
            var url = (_event$file = event.file) === null || _event$file === void 0 || (_event$file = _event$file.response) === null || _event$file === void 0 || (_event$file = _event$file.result) === null || _event$file === void 0 ? void 0 : _event$file.url;
            var name = (_event$file2 = event.file) === null || _event$file2 === void 0 ? void 0 : _event$file2.name;
            if (url) {
              (0,resume/* addResume */._2)({
                url: url,
                name: name
              }).then(function (res) {
                dist/* toast */.m4.success(res.message);
                getCurrentUser();
              });
            }
          }
        }, /*#__PURE__*/react.createElement(Button/* default */.c, {
          variant: "contained",
          size: "large"
        }, "\u4E0A\u4F20\u7B80\u5386")));
      } else {
        var _detail$company4;
        return /*#__PURE__*/react.createElement(react.Fragment, null, applyInfo ? applyInfo.haveRead ? applyInfo.isDownload ? /*#__PURE__*/react.createElement(Button/* default */.c, {
          variant: "contained",
          disabled: true
        }, "\u7B80\u5386\u5DF2\u88AB\u4E0B\u8F7D") : applyInfo.mark ? /*#__PURE__*/react.createElement(Button/* default */.c, {
          variant: "contained",
          disabled: true
        }, "\u7B80\u5386\u5DF2\u88AB\u6807\u8BB0") : /*#__PURE__*/react.createElement(Button/* default */.c, {
          variant: "contained",
          disabled: true
        }, "\u7B80\u5386\u5DF2\u88AB\u67E5\u770B") :
        /*#__PURE__*/
        // <AuthBtn
        //   onClick={() => {
        //     resumeModalRef?.current.handleOpen();
        //   }}
        // >
        //   <Button variant="contained" size="large">
        //     修改简历
        //   </Button>
        // </AuthBtn>
        react.createElement(Button/* default */.c, {
          variant: "contained",
          disabled: true
        }, "\u7B49\u5F85\u7B80\u5386\u88AB\u67E5\u770B") : /*#__PURE__*/react.createElement(AuthBtn/* AuthBtn */.k, {
          share: detail === null || detail === void 0 || (_detail$company4 = detail.company) === null || _detail$company4 === void 0 || (_detail$company4 = _detail$company4.user) === null || _detail$company4 === void 0 ? void 0 : _detail$company4.address,
          onClick: function onClick() {
            var _userInfo$resumes2;
            if ((userInfo === null || userInfo === void 0 || (_userInfo$resumes2 = userInfo.resumes) === null || _userInfo$resumes2 === void 0 ? void 0 : _userInfo$resumes2.length) === 0) {
              openApply();
            } else {
              var _resumeModalRef$curre;
              (_resumeModalRef$curre = resumeModalRef.current) === null || _resumeModalRef$curre === void 0 || _resumeModalRef$curre.handleOpen();
            }
          }
        }, /*#__PURE__*/react.createElement(Button/* default */.c, {
          variant: "contained",
          size: "large"
        }, "\u6295\u9012\u5C97\u4F4D")));
      }
    }
  };
  return /*#__PURE__*/react.createElement("div", {
    className: page_Job.job
  }, /*#__PURE__*/react.createElement(Introduce/* Introduce */.x, {
    companyId: detail === null || detail === void 0 || (_detail$company5 = detail.company) === null || _detail$company5 === void 0 ? void 0 : _detail$company5.id,
    className: page_Job.company,
    showMore: true
  }), /*#__PURE__*/react.createElement("div", {
    className: page_Job.container
  }, /*#__PURE__*/react.createElement("div", {
    className: page_Job.content
  }, /*#__PURE__*/react.createElement("div", {
    className: page_Job.name
  }, /*#__PURE__*/react.createElement("div", {
    className: page_Job.left
  }, detail === null || detail === void 0 ? void 0 : detail.name, " ", /*#__PURE__*/react.createElement("span", {
    className: page_Job.salary
  }, salary)), (detail === null || detail === void 0 || (_detail$company6 = detail.company) === null || _detail$company6 === void 0 ? void 0 : _detail$company6.userId) === userId && /*#__PURE__*/react.createElement("div", {
    className: page_Job.operation
  }, /*#__PURE__*/react.createElement(Button/* default */.c, {
    onClick: function onClick() {
      openConfirm(detail);
    }
  }, "\u5220\u9664"))), /*#__PURE__*/react.createElement("div", {
    className: page_Job.tag
  }, detail === null || detail === void 0 || (_detail$tag = detail.tag) === null || _detail$tag === void 0 ? void 0 : _detail$tag.split(",").map(function (item) {
    return /*#__PURE__*/react.createElement(Chip/* default */.c, {
      key: item,
      label: item,
      className: page_Job.chip,
      size: "small"
    });
  }), /*#__PURE__*/react.createElement(Chip/* default */.c, {
    key: detail !== null && detail !== void 0 && detail.isRemote ? "支持远程" : "不支持远程",
    label: detail !== null && detail !== void 0 && detail.isRemote ? "支持远程" : "不支持远程",
    className: page_Job.chip,
    size: "small"
  })), /*#__PURE__*/react.createElement("div", {
    className: page_Job.location
  }, /*#__PURE__*/react.createElement("span", null, "\u5730\u5740\uFF1A"), /*#__PURE__*/react.createElement("span", null, detail === null || detail === void 0 ? void 0 : detail.location)), /*#__PURE__*/react.createElement("div", {
    className: page_Job.description
  }, /*#__PURE__*/react.createElement("span", null, "\u5C97\u4F4D\u63CF\u8FF0"), /*#__PURE__*/react.createElement("span", null, detail === null || detail === void 0 ? void 0 : detail.description)), /*#__PURE__*/react.createElement("div", {
    className: page_Job.apply
  }, renderBtn()), (detail === null || detail === void 0 || (_detail$company7 = detail.company) === null || _detail$company7 === void 0 ? void 0 : _detail$company7.userId) === userId && /*#__PURE__*/react.createElement("div", {
    className: page_Job.resume__list
  }, /*#__PURE__*/react.createElement("div", {
    className: page_Job.title
  }, "\u6295\u9012\u5217\u8868"), /*#__PURE__*/react.createElement("div", {
    className: page_Job.top
  }, /*#__PURE__*/react.createElement("span", {
    className: classnames_default()(current === "0" && page_Job.active),
    onClick: function onClick() {
      setCurrent("0");
    }
  }, "\u672A\u8BFB"), /*#__PURE__*/react.createElement("span", {
    className: classnames_default()(current === "1" && page_Job.active),
    onClick: function onClick() {
      setCurrent("1");
    }
  }, "\u5DF2\u8BFB"), /*#__PURE__*/react.createElement("span", {
    className: classnames_default()(current === "2" && page_Job.active),
    onClick: function onClick() {
      setCurrent("2");
    }
  }, "\u6807\u8BB0")), /*#__PURE__*/react.createElement("div", {
    className: page_Job.bottom
  }, /*#__PURE__*/react.createElement("div", {
    className: classnames_default()(page_Job.content, current !== "0" && page_Job.none)
  }, (noReadList === null || noReadList === void 0 ? void 0 : noReadList.length) === 0 ? /*#__PURE__*/react.createElement("div", {
    className: page_Job.no__data
  }, /*#__PURE__*/react.createElement("img", {
    src: no_list
  }), /*#__PURE__*/react.createElement("span", null, "\u8FD8\u6CA1\u6709\u4EBA\u6295\u9012")) : /*#__PURE__*/react.createElement(react.Fragment, null, /*#__PURE__*/react.createElement("div", {
    className: page_Job.wrap,
    style: {
      height: 336
    }
  }, noReadList === null || noReadList === void 0 ? void 0 : noReadList.map(function (item) {
    return /*#__PURE__*/react.createElement(ApplyItem/* ApplyItem */.c, {
      data: item,
      key: item.id,
      onClick: function onClick() {
        var _pdfPreviewRef$curren;
        (_pdfPreviewRef$curren = pdfPreviewRef.current) === null || _pdfPreviewRef$curren === void 0 || _pdfPreviewRef$curren.handleOpen(item.resume.url, item.id, item.mark);
        setCurrentApply(item);
      }
    });
  })), /*#__PURE__*/react.createElement("div", {
    className: page_Job.pagination
  }, /*#__PURE__*/react.createElement(Pagination/* default */.c, {
    count: Math.ceil(noReadTotal / 12),
    variant: "outlined",
    color: "primary",
    onChange: function onChange(_, page) {
      setNoReadPage(page);
    }
  })))), /*#__PURE__*/react.createElement("div", {
    className: classnames_default()(page_Job.content, current !== "1" && page_Job.none)
  }, (haveReadList === null || haveReadList === void 0 ? void 0 : haveReadList.length) === 0 ? /*#__PURE__*/react.createElement("div", {
    className: page_Job.no__data
  }, /*#__PURE__*/react.createElement("img", {
    src: no_list
  }), /*#__PURE__*/react.createElement("span", null, "\u8FD8\u6CA1\u6709\u67E5\u770B\u6295\u9012")) : /*#__PURE__*/react.createElement(react.Fragment, null, /*#__PURE__*/react.createElement("div", {
    className: page_Job.wrap,
    style: {
      height: 336
    }
  }, haveReadList === null || haveReadList === void 0 ? void 0 : haveReadList.map(function (item) {
    return /*#__PURE__*/react.createElement(ApplyItem/* ApplyItem */.c, {
      data: item,
      key: item.id,
      onClick: function onClick() {
        var _pdfPreviewRef$curren2;
        (_pdfPreviewRef$curren2 = pdfPreviewRef.current) === null || _pdfPreviewRef$curren2 === void 0 || _pdfPreviewRef$curren2.handleOpen(item.resume.url, item.id, item.mark);
        setCurrentApply(item);
      }
    });
  })), /*#__PURE__*/react.createElement("div", {
    className: page_Job.pagination
  }, /*#__PURE__*/react.createElement(Pagination/* default */.c, {
    count: Math.ceil(haveReadTotal / 12),
    variant: "outlined",
    color: "primary",
    onChange: function onChange(_, page) {
      setHaveReadPage(page);
    }
  })))), /*#__PURE__*/react.createElement("div", {
    className: classnames_default()(page_Job.content, current !== "2" && page_Job.none)
  }, (markList === null || markList === void 0 ? void 0 : markList.length) === 0 ? /*#__PURE__*/react.createElement("div", {
    className: page_Job.no__data
  }, /*#__PURE__*/react.createElement("img", {
    src: no_list
  }), /*#__PURE__*/react.createElement("span", null, "\u8FD8\u6CA1\u6709\u6807\u8BB0\u6295\u9012")) : /*#__PURE__*/react.createElement(react.Fragment, null, /*#__PURE__*/react.createElement("div", {
    className: page_Job.wrap,
    style: {
      height: 336
    }
  }, markList === null || markList === void 0 ? void 0 : markList.map(function (item) {
    return /*#__PURE__*/react.createElement(ApplyItem/* ApplyItem */.c, {
      data: item,
      key: item.id,
      onClick: function onClick() {
        var _pdfPreviewRef$curren3;
        (_pdfPreviewRef$curren3 = pdfPreviewRef.current) === null || _pdfPreviewRef$curren3 === void 0 || _pdfPreviewRef$curren3.handleOpen(item.resume.url, item.id, item.mark);
        setCurrentApply(item);
      }
    });
  })), /*#__PURE__*/react.createElement("div", {
    className: page_Job.pagination
  }, /*#__PURE__*/react.createElement(Pagination/* default */.c, {
    count: Math.ceil(markTotal / 12),
    variant: "outlined",
    color: "primary",
    onChange: function onChange(_, page) {
      setMarkPage(page);
    }
  })))))))), /*#__PURE__*/react.createElement(PdfPreview, {
    ref: pdfPreviewRef,
    onLoad: function onLoad() {
      !currentApply.haveRead && (0,apply/* updateApply */.En)(currentApply.id, {
        haveRead: true
      });
    }
  }), /*#__PURE__*/react.createElement(ComfirmDelete/* Comfirm */.u, {
    open: confirmOpen,
    tip: "\u786E\u8BA4\u5220\u9664\u5417\uFF1F",
    onClose: closeConfirm,
    onConfirm: function onConfirm() {
      deleteJob().then(function (res) {
        if (res) {
          navigate("/company");
        }
      });
    }
  }), /*#__PURE__*/react.createElement(ComfirmDelete/* Comfirm */.u, {
    open: applyOpen,
    tip: "\u6295\u9012\u5C06\u6D88\u80175\u9897\u8C46\u8C46\uFF0C\u662F\u5426\u7EE7\u7EED\u6295\u9012\uFF1F",
    onClose: closeApply,
    onConfirm: function onConfirm() {
      var _userInfo$resumes3, _userInfo$resumes$2;
      (0,apply/* addApply */.ag)({
        jobId: detail === null || detail === void 0 ? void 0 : detail.id,
        resumeId: (userInfo === null || userInfo === void 0 || (_userInfo$resumes3 = userInfo.resumes) === null || _userInfo$resumes3 === void 0 ? void 0 : _userInfo$resumes3.length) > 1 ? select : userInfo === null || userInfo === void 0 || (_userInfo$resumes$2 = userInfo.resumes[0]) === null || _userInfo$resumes$2 === void 0 ? void 0 : _userInfo$resumes$2.id
      }).then(function (res) {
        var _res$result;
        dist/* toast */.m4.success("".concat(res.message, ",\u8FD8\u5269").concat((_res$result = res.result) === null || _res$result === void 0 ? void 0 : _res$result.resetIntegral, "\u8C46\u8C46"));
        closeApply();
        handleGetApply();
      })["catch"](function (error) {
        dist/* toast */.m4.error(error.message);
        setShareOpen(true);
        closeApply();
      });
    }
  }), /*#__PURE__*/react.createElement(ComfirmDelete/* Comfirm */.u, {
    open: downlaodOpen,
    tip: "\u4E0B\u8F7D\u5C06\u6D88\u80175\u9897\u8C46\u8C46\uFF0C\u662F\u5426\u7EE7\u7EED\u4E0B\u8F7D\uFF1F",
    onClose: closeDownlaod,
    onConfirm: function onConfirm() {
      download({
        url: decodeURIComponent(pdfPreviewRef.current.url.replace(constant/* OSS_ORIGIN */.WO, ""))
      }).then(function (res) {
        !currentApply.isDownload && (0,apply/* updateApply */.En)(currentApply.id, {
          isDownload: true
        });
        closeDownlaod();
        downloadOss(res.result, decodeURIComponent(pdfPreviewRef.current.url.replace(constant/* OSS_ORIGIN */.WO, "")));
      });
      // addApply({
      //   jobId: detail?.id,
      //   resumeId:
      //     userInfo?.resumes?.length > 1 ? select : userInfo?.resumes[0]?.id,
      // })
      //   .then((res) => {
      //     toast.success(
      //       `${res.message},还剩${res.result?.resetIntegral}豆豆`
      //     );
      //     closeApply();
      //     handleGetApply();
      //   })
      //   .catch((error) => {
      //     toast.error(error.message);
      //     setShareOpen(true);
      //     closeApply();
      //   });
    }
  }), /*#__PURE__*/react.createElement(ComfirmDelete/* Comfirm */.u, {
    open: shareOpen,
    tip: constant/* SHARE_TIP */.Kk,
    onClose: function onClose() {
      setShareOpen(false);
    },
    onConfirm: function onConfirm() {
      console.log("复制");
      navigator.clipboard.writeText("https://www.flowin3.com/jobs?address=".concat(userInfo.address)).then(function () {
        console.log("复制成功");
      })["catch"](function () {
        console.log("复制失败");
      });
      setShareOpen(false);
    }
  }), /*#__PURE__*/react.createElement(ResumeModal/* ResumeModal */.E, {
    ref: resumeModalRef,
    isChoice: true,
    showDelete: false,
    select: select,
    onSelect: function onSelect(select) {
      setSelect(select);
    },
    onPost: function onPost() {
      var _resumeModalRef$curre2;
      resumeModalRef === null || resumeModalRef === void 0 || (_resumeModalRef$curre2 = resumeModalRef.current) === null || _resumeModalRef$curre2 === void 0 || _resumeModalRef$curre2.handleClose();
      openApply();
    },
    openResume: function openResume(item) {
      var _pdfPreviewRef1$curre;
      (_pdfPreviewRef1$curre = pdfPreviewRef1.current) === null || _pdfPreviewRef1$curre === void 0 || _pdfPreviewRef1$curre.handleOpen(item.resumeUrl, item.id);
    }
  }), /*#__PURE__*/react.createElement(PdfPreview, {
    ref: pdfPreviewRef1,
    showMark: false
  }));
};
/* harmony default export */ const src_page_Job = (Job);

/***/ }),

/***/ 49760:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


var charAt = (__webpack_require__(97560).charAt);

// `AdvanceStringIndex` abstract operation
// https://tc39.es/ecma262/#sec-advancestringindex
module.exports = function (S, index, unicode) {
  return index + (unicode ? charAt(S, index).length : 1);
};


/***/ }),

/***/ 12932:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


var uncurryThis = __webpack_require__(5376);
var toObject = __webpack_require__(49056);

var floor = Math.floor;
var charAt = uncurryThis(''.charAt);
var replace = uncurryThis(''.replace);
var stringSlice = uncurryThis(''.slice);
// eslint-disable-next-line redos/no-vulnerable -- safe
var SUBSTITUTION_SYMBOLS = /\$([$&'`]|\d{1,2}|<[^>]*>)/g;
var SUBSTITUTION_SYMBOLS_NO_NAMED = /\$([$&'`]|\d{1,2})/g;

// `GetSubstitution` abstract operation
// https://tc39.es/ecma262/#sec-getsubstitution
module.exports = function (matched, str, position, captures, namedCaptures, replacement) {
  var tailPos = position + matched.length;
  var m = captures.length;
  var symbols = SUBSTITUTION_SYMBOLS_NO_NAMED;
  if (namedCaptures !== undefined) {
    namedCaptures = toObject(namedCaptures);
    symbols = SUBSTITUTION_SYMBOLS;
  }
  return replace(replacement, symbols, function (match, ch) {
    var capture;
    switch (charAt(ch, 0)) {
      case '$': return '$';
      case '&': return matched;
      case '`': return stringSlice(str, 0, position);
      case "'": return stringSlice(str, tailPos);
      case '<':
        capture = namedCaptures[stringSlice(ch, 1, -1)];
        break;
      default: // \d\d?
        var n = +ch;
        if (n === 0) return match;
        if (n > m) {
          var f = floor(n / 10);
          if (f === 0) return match;
          if (f <= m) return captures[f - 1] === undefined ? charAt(ch, 1) : captures[f - 1] + charAt(ch, 1);
          return match;
        }
        capture = captures[n - 1];
    }
    return capture === undefined ? '' : capture;
  });
};


/***/ }),

/***/ 99812:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {


var apply = __webpack_require__(26928);
var call = __webpack_require__(97764);
var uncurryThis = __webpack_require__(5376);
var fixRegExpWellKnownSymbolLogic = __webpack_require__(5164);
var fails = __webpack_require__(77008);
var anObject = __webpack_require__(62888);
var isCallable = __webpack_require__(11568);
var isNullOrUndefined = __webpack_require__(85592);
var toIntegerOrInfinity = __webpack_require__(30928);
var toLength = __webpack_require__(76032);
var toString = __webpack_require__(56576);
var requireObjectCoercible = __webpack_require__(18756);
var advanceStringIndex = __webpack_require__(49760);
var getMethod = __webpack_require__(13176);
var getSubstitution = __webpack_require__(12932);
var regExpExec = __webpack_require__(55092);
var wellKnownSymbol = __webpack_require__(95600);

var REPLACE = wellKnownSymbol('replace');
var max = Math.max;
var min = Math.min;
var concat = uncurryThis([].concat);
var push = uncurryThis([].push);
var stringIndexOf = uncurryThis(''.indexOf);
var stringSlice = uncurryThis(''.slice);

var maybeToString = function (it) {
  return it === undefined ? it : String(it);
};

// IE <= 11 replaces $0 with the whole match, as if it was $&
// https://stackoverflow.com/questions/6024666/getting-ie-to-replace-a-regex-with-the-literal-string-0
var REPLACE_KEEPS_$0 = (function () {
  // eslint-disable-next-line regexp/prefer-escape-replacement-dollar-char -- required for testing
  return 'a'.replace(/./, '$0') === '$0';
})();

// Safari <= 13.0.3(?) substitutes nth capture where n>m with an empty string
var REGEXP_REPLACE_SUBSTITUTES_UNDEFINED_CAPTURE = (function () {
  if (/./[REPLACE]) {
    return /./[REPLACE]('a', '$0') === '';
  }
  return false;
})();

var REPLACE_SUPPORTS_NAMED_GROUPS = !fails(function () {
  var re = /./;
  re.exec = function () {
    var result = [];
    result.groups = { a: '7' };
    return result;
  };
  // eslint-disable-next-line regexp/no-useless-dollar-replacements -- false positive
  return ''.replace(re, '$<a>') !== '7';
});

// @@replace logic
fixRegExpWellKnownSymbolLogic('replace', function (_, nativeReplace, maybeCallNative) {
  var UNSAFE_SUBSTITUTE = REGEXP_REPLACE_SUBSTITUTES_UNDEFINED_CAPTURE ? '$' : '$0';

  return [
    // `String.prototype.replace` method
    // https://tc39.es/ecma262/#sec-string.prototype.replace
    function replace(searchValue, replaceValue) {
      var O = requireObjectCoercible(this);
      var replacer = isNullOrUndefined(searchValue) ? undefined : getMethod(searchValue, REPLACE);
      return replacer
        ? call(replacer, searchValue, O, replaceValue)
        : call(nativeReplace, toString(O), searchValue, replaceValue);
    },
    // `RegExp.prototype[@@replace]` method
    // https://tc39.es/ecma262/#sec-regexp.prototype-@@replace
    function (string, replaceValue) {
      var rx = anObject(this);
      var S = toString(string);

      if (
        typeof replaceValue == 'string' &&
        stringIndexOf(replaceValue, UNSAFE_SUBSTITUTE) === -1 &&
        stringIndexOf(replaceValue, '$<') === -1
      ) {
        var res = maybeCallNative(nativeReplace, rx, S, replaceValue);
        if (res.done) return res.value;
      }

      var functionalReplace = isCallable(replaceValue);
      if (!functionalReplace) replaceValue = toString(replaceValue);

      var global = rx.global;
      var fullUnicode;
      if (global) {
        fullUnicode = rx.unicode;
        rx.lastIndex = 0;
      }

      var results = [];
      var result;
      while (true) {
        result = regExpExec(rx, S);
        if (result === null) break;

        push(results, result);
        if (!global) break;

        var matchStr = toString(result[0]);
        if (matchStr === '') rx.lastIndex = advanceStringIndex(S, toLength(rx.lastIndex), fullUnicode);
      }

      var accumulatedResult = '';
      var nextSourcePosition = 0;
      for (var i = 0; i < results.length; i++) {
        result = results[i];

        var matched = toString(result[0]);
        var position = max(min(toIntegerOrInfinity(result.index), S.length), 0);
        var captures = [];
        var replacement;
        // NOTE: This is equivalent to
        //   captures = result.slice(1).map(maybeToString)
        // but for some reason `nativeSlice.call(result, 1, result.length)` (called in
        // the slice polyfill when slicing native arrays) "doesn't work" in safari 9 and
        // causes a crash (https://pastebin.com/N21QzeQA) when trying to debug it.
        for (var j = 1; j < result.length; j++) push(captures, maybeToString(result[j]));
        var namedCaptures = result.groups;
        if (functionalReplace) {
          var replacerArgs = concat([matched], captures, position, S);
          if (namedCaptures !== undefined) push(replacerArgs, namedCaptures);
          replacement = toString(apply(replaceValue, undefined, replacerArgs));
        } else {
          replacement = getSubstitution(matched, S, position, captures, namedCaptures, replaceValue);
        }
        if (position >= nextSourcePosition) {
          accumulatedResult += stringSlice(S, nextSourcePosition, position) + replacement;
          nextSourcePosition = position + matched.length;
        }
      }

      return accumulatedResult + stringSlice(S, nextSourcePosition);
    }
  ];
}, !REPLACE_SUPPORTS_NAMED_GROUPS || !REPLACE_KEEPS_$0 || REGEXP_REPLACE_SUBSTITUTES_UNDEFINED_CAPTURE);


/***/ })

}]);