"use strict";
(self["webpackChunkweb3_design_style"] = self["webpackChunkweb3_design_style"] || []).push([[492],{

/***/ 86479:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  c: () => (/* binding */ src_page_Jobs)
});

// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.js
var es_symbol = __webpack_require__(42856);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.description.js
var es_symbol_description = __webpack_require__(63397);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.iterator.js
var es_symbol_iterator = __webpack_require__(54000);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.from.js
var es_array_from = __webpack_require__(67972);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.is-array.js
var es_array_is_array = __webpack_require__(29448);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.iterator.js
var es_array_iterator = __webpack_require__(44272);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.slice.js
var es_array_slice = __webpack_require__(72344);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.date.to-string.js
var es_date_to_string = __webpack_require__(28612);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__(26572);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__(88012);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__(23784);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.regexp.to-string.js
var es_regexp_to_string = __webpack_require__(81852);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.string.iterator.js
var es_string_iterator = __webpack_require__(13755);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/web.dom-collections.iterator.js
var web_dom_collections_iterator = __webpack_require__(22248);
// EXTERNAL MODULE: ./node_modules/.pnpm/react@18.2.0/node_modules/react/index.js
var react = __webpack_require__(96651);
// EXTERNAL MODULE: ./node_modules/.pnpm/antd-mobile@5.35.0_react-dom@18.2.0_react@18.2.0/node_modules/antd-mobile/es/index.js + 43 modules
var es = __webpack_require__(78576);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__(18440);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.string.search.js
var es_string_search = __webpack_require__(43792);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/TextField/TextField.js + 34 modules
var TextField = __webpack_require__(53324);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/MenuItem/MenuItem.js + 4 modules
var MenuItem = __webpack_require__(81548);
;// CONCATENATED MODULE: ./src/page/Jobs/components/Search/index.less
// extracted by mini-css-extract-plugin
/* harmony default export */ const components_Search = ({"search":"src-page-Jobs-components-Search-__index__search","keyword":"src-page-Jobs-components-Search-__index__keyword","type":"src-page-Jobs-components-Search-__index__type","city":"src-page-Jobs-components-Search-__index__city","search__btn":"src-page-Jobs-components-Search-__index__search__btn"});
// EXTERNAL MODULE: ./src/store/index.ts + 4 modules
var store = __webpack_require__(75899);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/Button/Button.js + 3 modules
var Button = __webpack_require__(80180);
;// CONCATENATED MODULE: ./src/page/Jobs/components/Search/index.tsx










var Search = function Search() {
  var citys = [{
    value: "1",
    label: "北京"
  }, {
    value: "2",
    label: "上海"
  }, {
    value: "3",
    label: "深圳"
  }, {
    value: "4",
    label: "杭州"
  }];
  var types = [{
    value: "1",
    label: "是"
  }, {
    value: "0",
    label: "否"
  }];
  var _useJobsStore = (0,store/* useJobsStore */.ac)(),
    setName = _useJobsStore.setName,
    setIsRemote = _useJobsStore.setIsRemote,
    setLocation = _useJobsStore.setLocation,
    name = _useJobsStore.name,
    location = _useJobsStore.location,
    isRemote = _useJobsStore.isRemote,
    getJobList = _useJobsStore.getJobList,
    refresh = _useJobsStore.refresh;
  return /*#__PURE__*/react.createElement("div", {
    className: components_Search.search
  }, /*#__PURE__*/react.createElement("div", {
    className: components_Search.keyword
  }, /*#__PURE__*/react.createElement(TextField/* default */.c, {
    id: "name",
    label: "\u5C97\u4F4D\u540D\u79F0",
    fullWidth: true,
    value: name,
    onChange: function onChange(event) {
      setName(event.target.value);
    }
  })), /*#__PURE__*/react.createElement("div", {
    className: components_Search.type
  }, /*#__PURE__*/react.createElement(TextField/* default */.c, {
    id: "isRemote",
    label: "\u662F\u5426\u8FDC\u7A0B",
    select: true,
    fullWidth: true,
    value: isRemote === false ? "0" : isRemote === true ? "1" : "",
    onChange: function onChange(event) {
      setIsRemote(event.target.value === "1" ? true : false);
    }
  }, types.map(function (option) {
    return /*#__PURE__*/react.createElement(MenuItem/* default */.c, {
      key: option.value,
      value: option.value
    }, option.label);
  }))), /*#__PURE__*/react.createElement("div", {
    className: components_Search.city
  }, /*#__PURE__*/react.createElement(TextField/* default */.c, {
    id: "location",
    label: "\u5730\u5740",
    value: location,
    fullWidth: true,
    onChange: function onChange(event) {
      setLocation(event.target.value);
    }
  })), /*#__PURE__*/react.createElement(Button/* default */.c, {
    variant: "contained",
    size: "large",
    className: components_Search.search__btn,
    onClick: function onClick() {
      refresh();
      getJobList();
    }
  }, "\u641C\u7D22"));
};
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.to-primitive.js
var es_symbol_to_primitive = __webpack_require__(2240);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.date.to-primitive.js
var es_date_to_primitive = __webpack_require__(20784);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.number.constructor.js
var es_number_constructor = __webpack_require__(95392);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.object.define-property.js
var es_object_define_property = __webpack_require__(55888);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.concat.js
var es_array_concat = __webpack_require__(70516);
// EXTERNAL MODULE: ./src/components/Ellipsis/index.tsx + 1 modules
var Ellipsis = __webpack_require__(11008);
;// CONCATENATED MODULE: ./src/page/Jobs/components/Result/Item/index.less
// extracted by mini-css-extract-plugin
/* harmony default export */ const Result_Item = ({"item":"src-page-Jobs-components-Result-Item-__index__item","logo":"src-page-Jobs-components-Result-Item-__index__logo","tag":"src-page-Jobs-components-Result-Item-__index__tag","chip":"src-page-Jobs-components-Result-Item-__index__chip","company__name":"src-page-Jobs-components-Result-Item-__index__company__name","position":"src-page-Jobs-components-Result-Item-__index__position","address":"src-page-Jobs-components-Result-Item-__index__address","required":"src-page-Jobs-components-Result-Item-__index__required","time":"src-page-Jobs-components-Result-Item-__index__time"});
// EXTERNAL MODULE: ./src/components/Image/index.tsx + 1 modules
var Image = __webpack_require__(97144);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/Chip/Chip.js + 2 modules
var Chip = __webpack_require__(34336);
// EXTERNAL MODULE: ./node_modules/.pnpm/react-router@6.22.3_react@18.2.0/node_modules/react-router/dist/index.js
var dist = __webpack_require__(66336);
// EXTERNAL MODULE: ./src/utils/time.ts
var time = __webpack_require__(56480);
;// CONCATENATED MODULE: ./src/page/Jobs/components/Result/Item/index.tsx













var Item = function Item(props) {
  var _data$tag;
  var data = props.data;
  console.log(data, "fds");
  var navigate = (0,dist/* useNavigate */.i6)();
  var salary = (0,react.useMemo)(function () {
    return data !== null && data !== void 0 && data.isFace ? "面议" : "".concat(data.minSalary, "~").concat(data.maxSalary);
  }, [data]);
  return /*#__PURE__*/react.createElement("div", {
    className: Result_Item.item,
    onClick: function onClick() {
      navigate("/job/".concat(data.id));
    }
  }, /*#__PURE__*/react.createElement(Image/* Image */.W, {
    className: Result_Item.logo,
    src: data.company.logo
  }), /*#__PURE__*/react.createElement("div", {
    className: Result_Item.company__name
  }, /*#__PURE__*/react.createElement("span", null, data.company.name)), /*#__PURE__*/react.createElement("div", {
    className: Result_Item.position
  }, /*#__PURE__*/react.createElement("span", null, data.name), /*#__PURE__*/react.createElement("span", null, salary)), /*#__PURE__*/react.createElement("div", {
    className: Result_Item.address
  }, /*#__PURE__*/react.createElement("span", null, "\u5730\u5740\uFF1A"), /*#__PURE__*/react.createElement("span", null, data.location)), /*#__PURE__*/react.createElement("div", {
    className: Result_Item.tag
  }, data === null || data === void 0 || (_data$tag = data.tag) === null || _data$tag === void 0 ? void 0 : _data$tag.split(",").map(function (item) {
    return /*#__PURE__*/react.createElement(Chip/* default */.c, {
      key: item,
      label: item,
      className: Result_Item.chip,
      size: "small"
    });
  }), /*#__PURE__*/react.createElement(Chip/* default */.c, {
    key: data !== null && data !== void 0 && data.isRemote ? "支持远程" : "不支持远程",
    label: data !== null && data !== void 0 && data.isRemote ? "支持远程" : "不支持远程",
    className: Result_Item.chip,
    size: "small"
  })), /*#__PURE__*/react.createElement("div", {
    className: Result_Item.required
  }, /*#__PURE__*/react.createElement("span", null, "\u5C97\u4F4D\u63CF\u8FF0"), /*#__PURE__*/react.createElement(Ellipsis/* Ellipsis */.C, {
    content: data.description
  })), /*#__PURE__*/react.createElement("div", {
    className: Result_Item.time
  }, /*#__PURE__*/react.createElement("span", null, (0,time/* timeAgo */.c)(new Date(data === null || data === void 0 ? void 0 : data.updatedAt).getTime()))));
};
// EXTERNAL MODULE: ./src/image/common/no-list.png
var no_list = __webpack_require__(37428);
;// CONCATENATED MODULE: ./src/page/Jobs/components/Result/index.less
// extracted by mini-css-extract-plugin
/* harmony default export */ const components_Result = ({"result":"src-page-Jobs-components-Result-__index__result","block":"src-page-Jobs-components-Result-__index__block","no__data":"src-page-Jobs-components-Result-__index__no__data"});
// EXTERNAL MODULE: ./src/components/Waterfull/index.tsx + 3 modules
var Waterfull = __webpack_require__(40280);
// EXTERNAL MODULE: ./node_modules/.pnpm/classnames@2.5.1/node_modules/classnames/index.js
var classnames = __webpack_require__(10124);
var classnames_default = /*#__PURE__*/__webpack_require__.n(classnames);
;// CONCATENATED MODULE: ./src/page/Jobs/components/Result/index.tsx
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }


















function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : String(i); }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }







var Result = function Result() {
  var list = [{
    logo: "https://bx-branding-gateway.cloud.seek.com.au/7964ed18-692c-40c5-a733-c4540ee12ae8.1/serpLogo",
    companyName: "杭州阿里巴巴集团",
    position: "产品经理",
    address: "杭州市西湖区南山路128号2楼",
    description: "1、精通JavaScript语言核心技术开发DOM、Ajax、JSON等相关技术，对JavaScript面向对象编程有自己的理解,\n2、熟悉ES6规范，可以使用基本的ES6语法,熟悉应用JQuery,\n2、同时熟悉Vue、React、angular等前端主流框架之一；",
    time: "2024-03-29",
    id: 0,
    salary: "20k~25k"
  }, {
    logo: "https://bx-branding-gateway.cloud.seek.com.au/04728ee7-b4c6-4fef-a3d4-9286247eda43.1/serpLogo",
    companyName: "杭州网易",
    position: "产品经理",
    address: "杭州市余杭区南北山路340号3楼",
    description: "现在，我们正处在长达 100 年的伟大的去中心化进程的中点。在各种机构正在进行大量的去中心化工作时，将这些机构与进程粘起来的则是便宜且无处不在的通信技术。当事物广泛传播到互联网时，如果没有能力让它们保持连接，工作着的集体就会分崩离析，并且带来些许倒退。更准确的说，是长距离即时通信的技术手段促成了这个去中心化的时代。也就是说，当我们用跨越沙漠、穿越海底的电费无休无止地在地球上缠绕时，去中心化趋势就成为了必然。现在，我们正处在长达 100 年的伟大的去中心化进程的中点。在各种机构正在进行大量的去中心化工作时，将这些机构与进程粘起来的则是便宜且无处不在的通信技术。当事物广泛传播到互联网时，如果没有能力让它们保持连接，工作着的集体就会分崩离析，并且带来些许倒退。更准确的说，是长距离即时通信的技术手段促成了这个去中心化的时代。也就是说，当我们用跨越沙漠、穿越海底的电费无休无止地在地球上缠绕时，去中心化趋势就成为了必然。",
    time: "2024-03-29",
    salary: "15k~20k",
    id: 1
  }, {
    logo: "https://bx-branding-gateway.cloud.seek.com.au/04728ee7-b4c6-4fef-a3d4-9286247eda43.1/serpLogo",
    companyName: "杭州网易",
    position: "产品经理",
    address: "杭州市余杭区南北山路340号3楼",
    description: "1、制定前端技术规划，选择技术团队的技术路线；2、优化前端/客户端业务架构；3、对内对外提升前端技术影响力；",
    time: "2024-03-29",
    id: 2,
    salary: "15k~20k"
  }, {
    logo: "https://bx-branding-gateway.cloud.seek.com.au/04728ee7-b4c6-4fef-a3d4-9286247eda43.1/serpLogo",
    companyName: "杭州网易",
    position: "产品经理",
    address: "杭州市余杭区南北山路340号3楼",
    description: "1、制定前端技术规划，选择技术团队的技术路线；\n2、优化前端/客户端业务架构；\n3、对内对外提升前端技术影响力；",
    time: "2024-03-29",
    id: 3,
    salary: "15k~20k"
  }, {
    logo: "https://bx-branding-gateway.cloud.seek.com.au/04728ee7-b4c6-4fef-a3d4-9286247eda43.1/serpLogo",
    companyName: "杭州网易",
    position: "产品经理",
    address: "杭州市余杭区南北山路340号3楼",
    description: "1、制定前端技术规划，选择技术团队的技术路线；\n2、优化前端/客户端业务架构；\n3、对内对外提升前端技术影响力；",
    time: "2024-03-29",
    id: 4,
    salary: "15k~20k"
  }, {
    logo: "https://bx-branding-gateway.cloud.seek.com.au/04728ee7-b4c6-4fef-a3d4-9286247eda43.1/serpLogo",
    companyName: "杭州网易",
    position: "产品经理",
    address: "杭州市余杭区南北山路340号3楼",
    description: "1、制定前端技术规划，选择技术团队的技术路线；\n2、优化前端/客户端业务架构；\n3、对内对外提升前端技术影响力；",
    time: "2024-03-29",
    id: 5,
    salary: "15k~20k"
  }, {
    logo: "https://bx-branding-gateway.cloud.seek.com.au/04728ee7-b4c6-4fef-a3d4-9286247eda43.1/serpLogo",
    companyName: "杭州网易",
    position: "产品经理",
    address: "杭州市余杭区南北山路340号3楼",
    description: "1、制定前端技术规划，选择技术团队的技术路线；\n2、优化前端/客户端业务架构；\n3、对内对外提升前端技术影响力；",
    time: "2024-03-29",
    id: 6,
    salary: "15k~20k"
  }, {
    logo: "https://bx-branding-gateway.cloud.seek.com.au/04728ee7-b4c6-4fef-a3d4-9286247eda43.1/serpLogo",
    companyName: "杭州网易",
    position: "产品经理",
    address: "杭州市余杭区南北山路340号3楼",
    description: "1、制定前端技术规划，选择技术团队的技术路线；\n2、优化前端/客户端业务架构；\n3、对内对外提升前端技术影响力；",
    time: "2024-03-29",
    id: 7,
    salary: "15k~20k"
  }];
  var divRef = (0,react.useRef)();
  var _useState = (0,react.useState)(0),
    _useState2 = _slicedToArray(_useState, 2),
    height = _useState2[0],
    setHeight = _useState2[1];
  var _useJobsStore = (0,store/* useJobsStore */.ac)(),
    jobList = _useJobsStore.jobList;
  var _useState3 = (0,react.useState)(1600),
    _useState4 = _slicedToArray(_useState3, 2),
    width = _useState4[0],
    setWidth = _useState4[1];
  var _useState5 = (0,react.useState)(4),
    _useState6 = _slicedToArray(_useState5, 2),
    columns = _useState6[0],
    setColumns = _useState6[1];
  (0,react.useEffect)(function () {
    var width = document.documentElement.clientWidth;
    if (width < 1700) {
      setWidth(width - 100);
      if (width < 1550) {
        setColumns(3);
      }
    }
    if (width < 750) {
      setWidth(width - 20);
      setColumns(1);
    }
  }, []);
  return /*#__PURE__*/react.createElement("div", {
    className: classnames_default()(components_Result.result, jobList.length === 0 && components_Result.block),
    style: _defineProperty({}, jobList.length !== 0 ? "height" : "", height),
    ref: divRef
  }, (jobList === null || jobList === void 0 ? void 0 : jobList.length) == 0 ? /*#__PURE__*/react.createElement("div", {
    className: components_Result.no__data
  }, /*#__PURE__*/react.createElement("img", {
    src: no_list
  }), /*#__PURE__*/react.createElement("span", null, "\u8FD8\u6CA1\u6709\u5DE5\u4F5C\u673A\u4F1A\uFF0C\u975E\u5E38\u62B1\u6B49")) : /*#__PURE__*/react.createElement(Waterfull/* Waterfull */.K_, {
    columns: columns,
    data: jobList,
    width: width,
    onHeight: function onHeight(height) {
      setHeight(height);
    },
    itemGap: 15,
    renderItem: function renderItem(data) {
      return /*#__PURE__*/react.createElement(Item, {
        data: data
      });
    }
  }));
};
;// CONCATENATED MODULE: ./src/page/Jobs/index.less
// extracted by mini-css-extract-plugin
/* harmony default export */ const page_Jobs = ({"jobs":"src-page-Jobs-__index__jobs","footer":"src-page-Jobs-__index__footer","add":"src-page-Jobs-__index__add"});
// EXTERNAL MODULE: ./node_modules/.pnpm/react-router-dom@6.22.3_react-dom@18.2.0_react@18.2.0/node_modules/react-router-dom/dist/index.js
var react_router_dom_dist = __webpack_require__(5135);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/Fab/Fab.js + 1 modules
var Fab = __webpack_require__(42984);
;// CONCATENATED MODULE: ./src/page/Jobs/index.tsx














function Jobs_slicedToArray(arr, i) { return Jobs_arrayWithHoles(arr) || Jobs_iterableToArrayLimit(arr, i) || Jobs_unsupportedIterableToArray(arr, i) || Jobs_nonIterableRest(); }
function Jobs_nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function Jobs_unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return Jobs_arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return Jobs_arrayLikeToArray(o, minLen); }
function Jobs_arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function Jobs_iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function Jobs_arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }









var Jobs = function Jobs() {
  var _useSearchParams = (0,react_router_dom_dist/* useSearchParams */.k5)(),
    _useSearchParams2 = Jobs_slicedToArray(_useSearchParams, 1),
    searchParams = _useSearchParams2[0];
  var divRef = (0,react.useRef)();
  var address = searchParams.get("address");
  var _useJobsStore = (0,store/* useJobsStore */.ac)(),
    getJobList = _useJobsStore.getJobList,
    hasMore = _useJobsStore.hasMore,
    refresh = _useJobsStore.refresh,
    refreshing = _useJobsStore.refreshing,
    first = _useJobsStore.first,
    jobList = _useJobsStore.jobList;
  address && localStorage.setItem("address", address);
  return /*#__PURE__*/react.createElement("div", {
    className: page_Jobs.jobs,
    ref: divRef
  }, /*#__PURE__*/react.createElement(es/* PullToRefresh */.cd, {
    onRefresh: function onRefresh() {
      // store.Message.resetCOData();
      // store.Message.setCORefresh(true);
      refresh();
      return getJobList();
    }
  }, /*#__PURE__*/react.createElement(Search, null), /*#__PURE__*/react.createElement(Result, null), !refreshing && (first || jobList.length > 0) && /*#__PURE__*/react.createElement(es/* InfiniteScroll */.kl, {
    hasMore: hasMore,
    loadMore: getJobList,
    className: classnames_default()(page_Jobs.footer)
  })), /*#__PURE__*/react.createElement(Fab/* default */.c, {
    color: "primary",
    "aria-label": "add",
    className: page_Jobs.add,
    onClick: function onClick() {
      var _divRef$current;
      (_divRef$current = divRef.current) === null || _divRef$current === void 0 || _divRef$current.scrollTo({
        top: 0
      });
    }
  }, /*#__PURE__*/react.createElement("i", {
    className: "iconfont icon-huidaodingbu"
  })));
};
/* harmony default export */ const src_page_Jobs = (Jobs);

/***/ })

}]);