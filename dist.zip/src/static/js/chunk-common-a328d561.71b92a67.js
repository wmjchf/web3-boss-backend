"use strict";
(self["webpackChunkweb3_design_style"] = self["webpackChunkweb3_design_style"] || []).push([[620],{

/***/ 98652:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96651);
/* harmony import */ var react_dom_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(47428);
/* harmony import */ var react_activation__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(10196);
/* harmony import */ var react_activation__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_activation__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _App__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(62396);
/* harmony import */ var _style_global_less__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(18107);
/* harmony import */ var _style_iconfont_less__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(14048);






var root = (0,react_dom_client__WEBPACK_IMPORTED_MODULE_1__/* .createRoot */ .C)(document.querySelector("#app"));
root.render( /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(react_activation__WEBPACK_IMPORTED_MODULE_5__.AliveScope, null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_App__WEBPACK_IMPORTED_MODULE_2__/* .App */ .q, null)));

/***/ })

}]);