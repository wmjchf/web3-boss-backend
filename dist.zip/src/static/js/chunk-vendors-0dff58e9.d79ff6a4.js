"use strict";
(self["webpackChunkweb3_design_style"] = self["webpackChunkweb3_design_style"] || []).push([[952],{

/***/ 2120:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   c: () => (/* binding */ makeCancellablePromise)
/* harmony export */ });
function makeCancellablePromise(promise) {
    var isCancelled = false;
    var wrappedPromise = new Promise(function (resolve, reject) {
        promise
            .then(function (value) { return !isCancelled && resolve(value); })
            .catch(function (error) { return !isCancelled && reject(error); });
    });
    return {
        promise: wrappedPromise,
        cancel: function () {
            isCancelled = true;
        },
    };
}


/***/ }),

/***/ 30180:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   cp: () => (/* binding */ makeEventProps),
/* harmony export */   kB: () => (/* binding */ allEvents)
/* harmony export */ });
/* unused harmony exports clipboardEvents, compositionEvents, focusEvents, formEvents, imageEvents, keyboardEvents, mediaEvents, mouseEvents, dragEvents, selectionEvents, touchEvents, pointerEvents, uiEvents, wheelEvents, animationEvents, transitionEvents, otherEvents, changeEvents */
var __spreadArray = (undefined && undefined.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
// As defined on the list of supported events: https://reactjs.org/docs/events.html
var clipboardEvents = ['onCopy', 'onCut', 'onPaste'];
var compositionEvents = [
    'onCompositionEnd',
    'onCompositionStart',
    'onCompositionUpdate',
];
var focusEvents = ['onFocus', 'onBlur'];
var formEvents = ['onInput', 'onInvalid', 'onReset', 'onSubmit'];
var imageEvents = ['onLoad', 'onError'];
var keyboardEvents = ['onKeyDown', 'onKeyPress', 'onKeyUp'];
var mediaEvents = [
    'onAbort',
    'onCanPlay',
    'onCanPlayThrough',
    'onDurationChange',
    'onEmptied',
    'onEncrypted',
    'onEnded',
    'onError',
    'onLoadedData',
    'onLoadedMetadata',
    'onLoadStart',
    'onPause',
    'onPlay',
    'onPlaying',
    'onProgress',
    'onRateChange',
    'onSeeked',
    'onSeeking',
    'onStalled',
    'onSuspend',
    'onTimeUpdate',
    'onVolumeChange',
    'onWaiting',
];
var mouseEvents = [
    'onClick',
    'onContextMenu',
    'onDoubleClick',
    'onMouseDown',
    'onMouseEnter',
    'onMouseLeave',
    'onMouseMove',
    'onMouseOut',
    'onMouseOver',
    'onMouseUp',
];
var dragEvents = [
    'onDrag',
    'onDragEnd',
    'onDragEnter',
    'onDragExit',
    'onDragLeave',
    'onDragOver',
    'onDragStart',
    'onDrop',
];
var selectionEvents = ['onSelect'];
var touchEvents = ['onTouchCancel', 'onTouchEnd', 'onTouchMove', 'onTouchStart'];
var pointerEvents = [
    'onPointerDown',
    'onPointerMove',
    'onPointerUp',
    'onPointerCancel',
    'onGotPointerCapture',
    'onLostPointerCapture',
    'onPointerEnter',
    'onPointerLeave',
    'onPointerOver',
    'onPointerOut',
];
var uiEvents = ['onScroll'];
var wheelEvents = ['onWheel'];
var animationEvents = [
    'onAnimationStart',
    'onAnimationEnd',
    'onAnimationIteration',
];
var transitionEvents = ['onTransitionEnd'];
var otherEvents = ['onToggle'];
var changeEvents = ['onChange'];
var allEvents = __spreadArray(__spreadArray(__spreadArray(__spreadArray(__spreadArray(__spreadArray(__spreadArray(__spreadArray(__spreadArray(__spreadArray(__spreadArray(__spreadArray(__spreadArray(__spreadArray(__spreadArray(__spreadArray(__spreadArray(__spreadArray([], clipboardEvents, true), compositionEvents, true), focusEvents, true), formEvents, true), imageEvents, true), keyboardEvents, true), mediaEvents, true), mouseEvents, true), dragEvents, true), selectionEvents, true), touchEvents, true), pointerEvents, true), uiEvents, true), wheelEvents, true), animationEvents, true), transitionEvents, true), changeEvents, true), otherEvents, true);
/**
 * Returns an object with on-event callback props curried with provided args.
 * @param {Object} props Props passed to a component.
 * @param {Function=} getArgs A function that returns argument(s) on-event callbacks
 *   shall be curried with.
 */
function makeEventProps(props, getArgs) {
    var eventProps = {};
    allEvents.forEach(function (eventName) {
        var eventHandler = props[eventName];
        if (!eventHandler) {
            return;
        }
        if (getArgs) {
            eventProps[eventName] = (function (event) {
                return eventHandler(event, getArgs(eventName));
            });
        }
        else {
            eventProps[eventName] = eventHandler;
        }
    });
    return eventProps;
}


/***/ }),

/***/ 80608:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   c: () => (/* binding */ mergeRefs)
/* harmony export */ });
/**
 * A function that merges React refs into one.
 * Supports both functions and ref objects created using createRef() and useRef().
 *
 * Usage:
 * ```tsx
 * <div ref={mergeRefs(ref1, ref2, ref3)} />
 * ```
 *
 * @param {(React.Ref<T> | undefined)[]} inputRefs Array of refs
 * @returns {React.Ref<T> | React.RefCallback<T>} Merged refs
 */
function mergeRefs() {
    var inputRefs = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        inputRefs[_i] = arguments[_i];
    }
    var filteredInputRefs = inputRefs.filter(Boolean);
    if (filteredInputRefs.length <= 1) {
        var firstRef = filteredInputRefs[0];
        return firstRef || null;
    }
    return function mergedRefs(ref) {
        filteredInputRefs.forEach(function (inputRef) {
            if (typeof inputRef === 'function') {
                inputRef(ref);
            }
            else if (inputRef) {
                inputRef.current = ref;
            }
        });
    };
}


/***/ }),

/***/ 10032:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  e: () => (/* binding */ createStore)
});

;// CONCATENATED MODULE: ./node_modules/.pnpm/mipd@0.0.5_typescript@5.3.3/node_modules/mipd/dist/esm/utils.js
/**
 * Announces an EIP-1193 Provider.
 */
function announceProvider(detail) {
    const event = new CustomEvent('eip6963:announceProvider', { detail: Object.freeze(detail) });
    window.dispatchEvent(event);
    const handler = () => window.dispatchEvent(event);
    window.addEventListener('eip6963:requestProvider', handler);
    return () => window.removeEventListener('eip6963:requestProvider', handler);
}
/**
 * Watches for EIP-1193 Providers to be announced.
 */
function requestProviders(listener) {
    const handler = (event) => listener(event.detail);
    window.addEventListener('eip6963:announceProvider', handler);
    window.dispatchEvent(new CustomEvent('eip6963:requestProvider'));
    return () => window.removeEventListener('eip6963:announceProvider', handler);
}
//# sourceMappingURL=utils.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/mipd@0.0.5_typescript@5.3.3/node_modules/mipd/dist/esm/store.js

function createStore() {
    const listeners = new Set();
    let providerDetails = [];
    const request = () => requestProviders((providerDetail) => {
        if (providerDetails.some(({ info }) => info.uuid === providerDetail.info.uuid))
            return;
        providerDetails = [...providerDetails, providerDetail];
        listeners.forEach((listener) => listener(providerDetails, { added: [providerDetail] }));
    });
    let unwatch = request();
    return {
        _listeners() {
            return listeners;
        },
        clear() {
            listeners.forEach((listener) => listener([], { removed: [...providerDetails] }));
            providerDetails = [];
        },
        destroy() {
            this.clear();
            listeners.clear();
            unwatch();
        },
        findProvider({ rdns }) {
            return providerDetails.find((providerDetail) => providerDetail.info.rdns === rdns);
        },
        getProviders() {
            return providerDetails;
        },
        reset() {
            this.clear();
            unwatch();
            unwatch = request();
        },
        subscribe(listener, { emitImmediately } = {}) {
            listeners.add(listener);
            if (emitImmediately)
                listener(providerDetails, { added: providerDetails });
            return () => listeners.delete(listener);
        },
    };
}
//# sourceMappingURL=store.js.map

/***/ })

}]);