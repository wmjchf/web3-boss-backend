"use strict";
(self["webpackChunkweb3_design_style"] = self["webpackChunkweb3_design_style"] || []).push([[496],{

/***/ 39784:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Kk: () => (/* binding */ SHARE_TIP),
/* harmony export */   WO: () => (/* binding */ OSS_ORIGIN),
/* harmony export */   yk: () => (/* binding */ BASE_URL)
/* harmony export */ });
/* unused harmony export isDev */
var isDev = "production" === "development";
var OSS_ORIGIN = isDev ? "http://flowin3-dev.oss-cn-hangzhou.aliyuncs.com/" : "http://flowin3.oss-cn-hangzhou.aliyuncs.com/";
var SHARE_TIP = "点击复制按钮，分享给其他用户并成功注册，即可获得20颗豆豆";
var BASE_URL = isDev ? "http://192.168.0.106:8000" : "https://116.62.109.162";

/***/ })

}]);