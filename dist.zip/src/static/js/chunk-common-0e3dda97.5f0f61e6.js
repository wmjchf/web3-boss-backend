"use strict";
(self["webpackChunkweb3_design_style"] = self["webpackChunkweb3_design_style"] || []).push([[360],{

/***/ 85768:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   En: () => (/* binding */ updateApply),
/* harmony export */   O: () => (/* binding */ getApplyList),
/* harmony export */   a8: () => (/* binding */ getApplySelf),
/* harmony export */   ag: () => (/* binding */ addApply)
/* harmony export */ });
/* harmony import */ var _request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(58772);

var addApply = function addApply(data) {
  return (0,_request__WEBPACK_IMPORTED_MODULE_0__/* .post */ .s$)("apply", data);
};
var getApplyList = function getApplyList(data) {
  return (0,_request__WEBPACK_IMPORTED_MODULE_0__/* .get */ ._M)("apply/list", data);
};
var getApplySelf = function getApplySelf(data) {
  return (0,_request__WEBPACK_IMPORTED_MODULE_0__/* .get */ ._M)("apply", data);
};
var updateApply = function updateApply(id, data) {
  return (0,_request__WEBPACK_IMPORTED_MODULE_0__/* .put */ .Aj)("apply/".concat(id), data);
};

/***/ }),

/***/ 4512:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MN: () => (/* binding */ addPicture),
/* harmony export */   Y9: () => (/* binding */ addCompany),
/* harmony export */   a2: () => (/* binding */ updateCompany),
/* harmony export */   kT: () => (/* binding */ getPicture),
/* harmony export */   st: () => (/* binding */ getCompanyDetail)
/* harmony export */ });
/* unused harmony export getCompanyListByAddress */
/* harmony import */ var _request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(58772);

var addCompany = function addCompany(data) {
  return (0,_request__WEBPACK_IMPORTED_MODULE_0__/* .post */ .s$)("company", data);
};
var getCompanyListByAddress = function getCompanyListByAddress(address) {
  return get("company", {
    address: address
  });
};
var getCompanyDetail = function getCompanyDetail(id) {
  return (0,_request__WEBPACK_IMPORTED_MODULE_0__/* .get */ ._M)("company/".concat(id));
};
var updateCompany = function updateCompany(id, data) {
  return (0,_request__WEBPACK_IMPORTED_MODULE_0__/* .put */ .Aj)("company/".concat(id), data);
};
var addPicture = function addPicture(companyId, data) {
  return (0,_request__WEBPACK_IMPORTED_MODULE_0__/* .post */ .s$)("cpicture/".concat(companyId), data);
};
var getPicture = function getPicture(companyId) {
  return (0,_request__WEBPACK_IMPORTED_MODULE_0__/* .get */ ._M)("cpicture", {
    companyId: companyId
  });
};

/***/ }),

/***/ 70348:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Ab: () => (/* binding */ addJob),
/* harmony export */   It: () => (/* binding */ getJobDetail),
/* harmony export */   OW: () => (/* binding */ deleteJob),
/* harmony export */   aG: () => (/* binding */ updateJob),
/* harmony export */   m6: () => (/* binding */ getJobList),
/* harmony export */   yE: () => (/* binding */ getJobListByCompanyId)
/* harmony export */ });
/* harmony import */ var _request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(58772);

var addJob = function addJob(data) {
  return (0,_request__WEBPACK_IMPORTED_MODULE_0__/* .post */ .s$)("job", data);
};
var getJobListByCompanyId = function getJobListByCompanyId(data) {
  return (0,_request__WEBPACK_IMPORTED_MODULE_0__/* .get */ ._M)("job", data);
};
var getJobList = function getJobList(data) {
  return (0,_request__WEBPACK_IMPORTED_MODULE_0__/* .get */ ._M)("job", data);
};
var getJobDetail = function getJobDetail(id) {
  return (0,_request__WEBPACK_IMPORTED_MODULE_0__/* .get */ ._M)("job/".concat(id));
};
var updateJob = function updateJob(id, data) {
  return (0,_request__WEBPACK_IMPORTED_MODULE_0__/* .put */ .Aj)("job/".concat(id), data);
};
var deleteJob = function deleteJob(id, data) {
  return (0,_request__WEBPACK_IMPORTED_MODULE_0__/* .post */ .s$)("job/delete/".concat(id));
};

/***/ }),

/***/ 60704:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _2: () => (/* binding */ addResume),
/* harmony export */   uY: () => (/* binding */ deleteResume)
/* harmony export */ });
/* unused harmony export getResume */
/* harmony import */ var _request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(58772);

var addResume = function addResume(data) {
  return (0,_request__WEBPACK_IMPORTED_MODULE_0__/* .post */ .s$)("resume", data);
};
var getResume = function getResume() {
  return get("resume");
};
var deleteResume = function deleteResume(id) {
  return (0,_request__WEBPACK_IMPORTED_MODULE_0__/* .post */ .s$)("resume/delete/".concat(id));
};

/***/ }),

/***/ 85488:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Mp: () => (/* binding */ login),
/* harmony export */   eo: () => (/* binding */ getCurrentUser),
/* harmony export */   es: () => (/* binding */ getNonce)
/* harmony export */ });
/* harmony import */ var _request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(58772);

// export const setProfile = (data: unknown) => post("/api/profile", data);

var getNonce = function getNonce() {
  return (0,_request__WEBPACK_IMPORTED_MODULE_0__/* .get */ ._M)("user/nonce");
};
var login = function login(data) {
  return (0,_request__WEBPACK_IMPORTED_MODULE_0__/* .post */ .s$)("user/login", data);
};
var getCurrentUser = function getCurrentUser() {
  return (0,_request__WEBPACK_IMPORTED_MODULE_0__/* .get */ ._M)("/user");
};

/***/ })

}]);