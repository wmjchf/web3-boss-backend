"use strict";
(self["webpackChunkweb3_design_style"] = self["webpackChunkweb3_design_style"] || []).push([[992],{

/***/ 49648:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Q: () => (/* binding */ EditPannel)
});

// EXTERNAL MODULE: ./node_modules/.pnpm/react@18.2.0/node_modules/react/index.js
var react = __webpack_require__(96651);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/Button/Button.js + 3 modules
var Button = __webpack_require__(80180);
;// CONCATENATED MODULE: ./src/page/Company/components/EditPannel/index.less
// extracted by mini-css-extract-plugin
/* harmony default export */ const components_EditPannel = ({"edit__pannel":"src-page-Company-components-EditPannel-__index__edit__pannel","edit__pannel__inner":"src-page-Company-components-EditPannel-__index__edit__pannel__inner","btn":"src-page-Company-components-EditPannel-__index__btn"});
// EXTERNAL MODULE: ./node_modules/.pnpm/classnames@2.5.1/node_modules/classnames/index.js
var classnames = __webpack_require__(10124);
var classnames_default = /*#__PURE__*/__webpack_require__.n(classnames);
// EXTERNAL MODULE: ./src/components/AuthBtn/index.tsx
var AuthBtn = __webpack_require__(27444);
;// CONCATENATED MODULE: ./src/page/Company/components/EditPannel/index.tsx





var EditPannel = function EditPannel(props) {
  var children = props.children,
    onEdit = props.onEdit,
    onSave = props.onSave,
    className = props.className,
    _props$showEdit = props.showEdit,
    showEdit = _props$showEdit === void 0 ? true : _props$showEdit,
    onClose = props.onClose,
    _props$isEdit = props.isEdit,
    isEdit = _props$isEdit === void 0 ? false : _props$isEdit;
  // const [isEdit, setIsEdit] = useState(false);
  return /*#__PURE__*/react.createElement("div", {
    className: classnames_default()(components_EditPannel.edit__pannel, className)
  }, /*#__PURE__*/react.createElement("div", {
    className: components_EditPannel.edit__pannel__inner
  }, children, showEdit && /*#__PURE__*/react.createElement("div", {
    className: components_EditPannel.btn
  }, isEdit && /*#__PURE__*/react.createElement(Button/* default */.c, {
    onClick: function onClick() {
      // setIsEdit(false);
      onClose && onClose();
    }
  }, "\u53D6\u6D88"), !isEdit ? /*#__PURE__*/react.createElement(AuthBtn/* AuthBtn */.k, {
    onClick: function onClick() {
      // setIsEdit(true);
      onEdit && onEdit();
    }
  }, /*#__PURE__*/react.createElement(Button/* default */.c, null, "\u7F16\u8F91")) : /*#__PURE__*/react.createElement(AuthBtn/* AuthBtn */.k, {
    onClick: function onClick() {
      // setIsEdit(false);
      onSave && onSave();
    }
  }, /*#__PURE__*/react.createElement(Button/* default */.c, null, "\u4FDD\u5B58")))));
};

/***/ }),

/***/ 56176:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  x: () => (/* binding */ Introduce)
});

// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.js
var es_symbol = __webpack_require__(42856);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.description.js
var es_symbol_description = __webpack_require__(63397);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.async-iterator.js
var es_symbol_async_iterator = __webpack_require__(44024);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.iterator.js
var es_symbol_iterator = __webpack_require__(54000);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.to-string-tag.js
var es_symbol_to_string_tag = __webpack_require__(78264);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.for-each.js
var es_array_for_each = __webpack_require__(93552);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.from.js
var es_array_from = __webpack_require__(67972);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.is-array.js
var es_array_is_array = __webpack_require__(29448);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.iterator.js
var es_array_iterator = __webpack_require__(44272);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.reverse.js
var es_array_reverse = __webpack_require__(51136);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.slice.js
var es_array_slice = __webpack_require__(72344);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.date.to-string.js
var es_date_to_string = __webpack_require__(28612);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__(26572);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.json.to-string-tag.js
var es_json_to_string_tag = __webpack_require__(70048);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.math.to-string-tag.js
var es_math_to_string_tag = __webpack_require__(97304);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.object.create.js
var es_object_create = __webpack_require__(66056);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.object.define-property.js
var es_object_define_property = __webpack_require__(55888);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.object.get-prototype-of.js
var es_object_get_prototype_of = __webpack_require__(98232);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.object.set-prototype-of.js
var es_object_set_prototype_of = __webpack_require__(37456);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__(88012);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.promise.js
var es_promise = __webpack_require__(75908);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__(23784);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.regexp.to-string.js
var es_regexp_to_string = __webpack_require__(81852);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.string.iterator.js
var es_string_iterator = __webpack_require__(13755);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/web.dom-collections.for-each.js
var web_dom_collections_for_each = __webpack_require__(23408);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/web.dom-collections.iterator.js
var web_dom_collections_iterator = __webpack_require__(22248);
// EXTERNAL MODULE: ./node_modules/.pnpm/react@18.2.0/node_modules/react/index.js
var react = __webpack_require__(96651);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/TextField/TextField.js + 34 modules
var TextField = __webpack_require__(53324);
// EXTERNAL MODULE: ./node_modules/.pnpm/antd-img-crop@4.21.0_antd@5.14.0_react-dom@18.2.0_react@18.2.0/node_modules/antd-img-crop/dist/antd-img-crop.esm.js + 41 modules
var antd_img_crop_esm = __webpack_require__(23340);
// EXTERNAL MODULE: ./node_modules/.pnpm/react-hot-toast@2.4.1_csstype@3.1.3_react-dom@18.2.0_react@18.2.0/node_modules/react-hot-toast/dist/index.mjs
var dist = __webpack_require__(98448);
// EXTERNAL MODULE: ./src/components/Image/index.tsx + 1 modules
var Image = __webpack_require__(97144);
// EXTERNAL MODULE: ./src/page/Company/components/EditPannel/index.tsx + 1 modules
var EditPannel = __webpack_require__(49648);
;// CONCATENATED MODULE: ./src/page/Company/components/Introduce/index.less
// extracted by mini-css-extract-plugin
/* harmony default export */ const components_Introduce = ({"introduce":"src-page-Company-components-Introduce-__index__introduce","top":"src-page-Company-components-Introduce-__index__top","logo":"src-page-Company-components-Introduce-__index__logo","logo__image":"src-page-Company-components-Introduce-__index__logo__image","upload":"src-page-Company-components-Introduce-__index__upload","name":"src-page-Company-components-Introduce-__index__name","none":"src-page-Company-components-Introduce-__index__none","copy":"src-page-Company-components-Introduce-__index__copy","middle":"src-page-Company-components-Introduce-__index__middle","location":"src-page-Company-components-Introduce-__index__location","bottom":"src-page-Company-components-Introduce-__index__bottom","more":"src-page-Company-components-Introduce-__index__more","edit__introduce":"src-page-Company-components-Introduce-__index__edit__introduce"});
// EXTERNAL MODULE: ./node_modules/.pnpm/classnames@2.5.1/node_modules/classnames/index.js
var classnames = __webpack_require__(10124);
var classnames_default = /*#__PURE__*/__webpack_require__.n(classnames);
// EXTERNAL MODULE: ./node_modules/.pnpm/antd@5.14.0_react-dom@18.2.0_react@18.2.0/node_modules/antd/es/upload/index.js + 34 modules
var upload = __webpack_require__(10700);
// EXTERNAL MODULE: ./src/api/company.ts
var company = __webpack_require__(4512);
// EXTERNAL MODULE: ./src/store/index.ts + 4 modules
var store = __webpack_require__(75899);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/Button/Button.js + 3 modules
var Button = __webpack_require__(80180);
// EXTERNAL MODULE: ./src/constant/index.ts
var constant = __webpack_require__(39784);
// EXTERNAL MODULE: ./node_modules/.pnpm/react-router@6.22.3_react@18.2.0/node_modules/react-router/dist/index.js
var react_router_dist = __webpack_require__(66336);
;// CONCATENATED MODULE: ./src/page/Company/components/Introduce/index.tsx
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }


























function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == _typeof(h) && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator["return"] && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(_typeof(e) + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, "catch": function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }














var Introduce = function Introduce(props) {
  var companyId = props.companyId,
    className = props.className,
    _props$showMore = props.showMore,
    showMore = _props$showMore === void 0 ? false : _props$showMore;
  var _userUserStore = (0,store/* userUserStore */.Wu)(),
    userInfo = _userUserStore.userInfo,
    getCurrentUser = _userUserStore.getCurrentUser;
  var id = userInfo.id;
  var navigate = (0,react_router_dist/* useNavigate */.i6)();
  var _useState = (0,react.useState)(false),
    _useState2 = _slicedToArray(_useState, 2),
    isEdit = _useState2[0],
    setIsEdit = _useState2[1];
  var _useState3 = (0,react.useState)(""),
    _useState4 = _slicedToArray(_useState3, 2),
    name = _useState4[0],
    setName = _useState4[1];
  var _useState5 = (0,react.useState)(-1),
    _useState6 = _slicedToArray(_useState5, 2),
    cuserId = _useState6[0],
    setCUserId = _useState6[1];
  var _useState7 = (0,react.useState)(""),
    _useState8 = _slicedToArray(_useState7, 2),
    location = _useState8[0],
    setLocation = _useState8[1];
  var _useState9 = (0,react.useState)(""),
    _useState10 = _slicedToArray(_useState9, 2),
    description = _useState10[0],
    setDescription = _useState10[1];
  var _useState11 = (0,react.useState)(""),
    _useState12 = _slicedToArray(_useState11, 2),
    logo = _useState12[0],
    setLogo = _useState12[1];
  var handleChange = function handleChange(_ref) {
    var _file$response;
    var file = _ref.file;
    if (file !== null && file !== void 0 && (_file$response = file.response) !== null && _file$response !== void 0 && (_file$response = _file$response.result) !== null && _file$response !== void 0 && _file$response.url) {
      var _file$response2;
      setLogo(file === null || file === void 0 || (_file$response2 = file.response) === null || _file$response2 === void 0 || (_file$response2 = _file$response2.result) === null || _file$response2 === void 0 ? void 0 : _file$response2.url);
    }
  };
  var onSave = function onSave() {
    if (companyId) {
      handleUpdateCompany();
    } else {
      handleAddCompany();
    }
  };
  var handleAddCompany = /*#__PURE__*/function () {
    var _ref2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
      return _regeneratorRuntime().wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            if (name) {
              _context.next = 3;
              break;
            }
            dist/* default */.cp.error("相关团队/项目/公司名称必填");
            return _context.abrupt("return");
          case 3:
            if (location) {
              _context.next = 6;
              break;
            }
            dist/* default */.cp.error("相关地址必填");
            return _context.abrupt("return");
          case 6:
            if (description) {
              _context.next = 9;
              break;
            }
            dist/* default */.cp.error("相关简介必填");
            return _context.abrupt("return");
          case 9:
            if (logo) {
              _context.next = 12;
              break;
            }
            dist/* default */.cp.error("相关logo必填");
            return _context.abrupt("return");
          case 12:
            _context.next = 14;
            return (0,company/* addCompany */.Y9)({
              name: name,
              location: location,
              description: description,
              logo: logo
            });
          case 14:
            getCurrentUser();
            setIsEdit(false);
          case 16:
          case "end":
            return _context.stop();
        }
      }, _callee);
    }));
    return function handleAddCompany() {
      return _ref2.apply(this, arguments);
    };
  }();
  var handleUpdateCompany = /*#__PURE__*/function () {
    var _ref3 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
      return _regeneratorRuntime().wrap(function _callee2$(_context2) {
        while (1) switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;
            _context2.next = 3;
            return (0,company/* updateCompany */.a2)(companyId, {
              name: name,
              location: location,
              description: description,
              logo: logo
            });
          case 3:
            setIsEdit(false);
            _context2.next = 9;
            break;
          case 6:
            _context2.prev = 6;
            _context2.t0 = _context2["catch"](0);
            dist/* default */.cp.error(_context2.t0.message);
          case 9:
          case "end":
            return _context2.stop();
        }
      }, _callee2, null, [[0, 6]]);
    }));
    return function handleUpdateCompany() {
      return _ref3.apply(this, arguments);
    };
  }();
  var handleGetCompanyDetail = /*#__PURE__*/function () {
    var _ref4 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee3() {
      var _yield$getCompanyDeta, result;
      return _regeneratorRuntime().wrap(function _callee3$(_context3) {
        while (1) switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return (0,company/* getCompanyDetail */.st)(companyId);
          case 2:
            _yield$getCompanyDeta = _context3.sent;
            result = _yield$getCompanyDeta.result;
            setDescription(result.description);
            setLocation(result.location);
            setLogo(result.logo);
            setName(result.name);
            setCUserId(result.userId);
          case 9:
          case "end":
            return _context3.stop();
        }
      }, _callee3);
    }));
    return function handleGetCompanyDetail() {
      return _ref4.apply(this, arguments);
    };
  }();
  (0,react.useEffect)(function () {
    if (companyId) {
      handleGetCompanyDetail();
    }
  }, [companyId]);
  return /*#__PURE__*/react.createElement(EditPannel/* EditPannel */.Q, {
    onEdit: function onEdit() {
      setIsEdit(true);
    },
    isEdit: isEdit,
    showEdit: id === cuserId || !companyId,
    onSave: onSave,
    onClose: function onClose() {
      setIsEdit(false);
    },
    className: classnames_default()(components_Introduce.edit__introduce, className)
  }, /*#__PURE__*/react.createElement("div", {
    className: components_Introduce.introduce
  }, /*#__PURE__*/react.createElement("div", {
    className: components_Introduce.top
  }, /*#__PURE__*/react.createElement("div", {
    className: components_Introduce.logo
  }, isEdit ? /*#__PURE__*/react.createElement(antd_img_crop_esm/* default */.c, {
    aspect: 100 / 65,
    zoomSlider: false,
    quality: 1
  }, /*#__PURE__*/react.createElement(upload/* default */.c
  // className={styles.upload}
  , {
    action: "".concat(constant/* BASE_URL */.yk, "/common/upload"),
    listType: "picture-card",
    showUploadList: false,
    onChange: handleChange,
    headers: {
      Authorization: "Bearer ".concat(localStorage.getItem("token"))
    }
  }, logo ? /*#__PURE__*/react.createElement(Image/* Image */.W, {
    src: logo
  }) : /*#__PURE__*/react.createElement("div", {
    className: components_Introduce.upload
  }))) : logo ? /*#__PURE__*/react.createElement(Image/* Image */.W, {
    src: logo,
    className: components_Introduce.logo__image
  }) : /*#__PURE__*/react.createElement("div", {
    className: components_Introduce.upload
  })), /*#__PURE__*/react.createElement("div", {
    className: components_Introduce.name
  }, isEdit ? /*#__PURE__*/react.createElement(TextField/* default */.c, {
    id: "name",
    label: "\u9879\u76EE/\u56E2\u961F/\u516C\u53F8\u540D\u5B57",
    fullWidth: true,
    value: name,
    onChange: function onChange(event) {
      setName(event.target.value);
    }
  }) : /*#__PURE__*/react.createElement("span", {
    className: classnames_default()(!name && components_Introduce.none)
  }, name || "项目/团队/公司名称", companyId && /*#__PURE__*/react.createElement(Button/* default */.c, {
    className: components_Introduce.copy,
    onClick: function onClick() {
      navigator.clipboard.writeText("https://www.flowin3.com/company/".concat(companyId)).then(function () {
        console.log("复制成功");
      })["catch"](function () {
        console.log("复制失败");
      });
    }
  }, "\u590D\u5236")))), /*#__PURE__*/react.createElement("div", {
    className: components_Introduce.middle
  }, /*#__PURE__*/react.createElement("div", {
    className: components_Introduce.location
  }, /*#__PURE__*/react.createElement("i", {
    className: "iconfont icon-shouye"
  }), isEdit ? /*#__PURE__*/react.createElement(TextField/* default */.c, {
    id: "location",
    label: "\u5730\u5740",
    fullWidth: true,
    value: location,
    onChange: function onChange(event) {
      setLocation(event.target.value);
    }
  }) : /*#__PURE__*/react.createElement("span", {
    className: classnames_default()(!location && components_Introduce.none)
  }, location || "项目/团队/公司地址"))), /*#__PURE__*/react.createElement("div", {
    className: components_Introduce.bottom
  }, isEdit ? /*#__PURE__*/react.createElement(TextField/* default */.c, {
    id: "description",
    label: "\u7B80\u4ECB",
    fullWidth: true,
    value: description
    // defaultValue="杭州电子科技大学（Hangzhou Dianzi
    // University），简称“杭电”，位于杭州市，是浙江省人民政府与国防科技工业局共建高校，是一所电子信息特色突出，经管学科优势明显，工、理、经、管、文、法、艺等多学科相互渗透的教学研究型大学，是浙江省首批重点建设的5所高校之一，是省属高校中唯一拥有国防特色重点专业的高校，是长三角高水平行业特色大学联盟成员，入选国家“111计划”、教育部“卓越工程师教育培养计划”、“国家级大学生创新创业训练计划”、“国家级新工科研究与实践项目”、“国家级特色专业建设点”、“全国毕业生就业典型经验高校，是博士学位授予单位，具有硕士推免权和全球雅思考点。对口支援衢州学院。"
    ,
    multiline: true,
    onChange: function onChange(event) {
      setDescription(event.target.value);
    }
  }) : /*#__PURE__*/react.createElement("span", {
    className: classnames_default()(!description && components_Introduce.none)
  }, description || "项目/团队/公司简介", showMore && /*#__PURE__*/react.createElement("i", {
    className: components_Introduce.more,
    onClick: function onClick() {
      navigate("/company/".concat(companyId));
    }
  }, "\u67E5\u770B\u66F4\u591A\u5C97\u4F4D")))));
};

/***/ }),

/***/ 3704:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Q: () => (/* binding */ Navbar)
});

// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.js
var es_symbol = __webpack_require__(42856);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.description.js
var es_symbol_description = __webpack_require__(63397);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.iterator.js
var es_symbol_iterator = __webpack_require__(54000);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.from.js
var es_array_from = __webpack_require__(67972);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.is-array.js
var es_array_is_array = __webpack_require__(29448);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.iterator.js
var es_array_iterator = __webpack_require__(44272);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.slice.js
var es_array_slice = __webpack_require__(72344);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.date.to-string.js
var es_date_to_string = __webpack_require__(28612);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__(26572);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__(88012);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__(23784);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.regexp.to-string.js
var es_regexp_to_string = __webpack_require__(81852);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.string.iterator.js
var es_string_iterator = __webpack_require__(13755);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/web.dom-collections.iterator.js
var web_dom_collections_iterator = __webpack_require__(22248);
// EXTERNAL MODULE: ./node_modules/.pnpm/react@18.2.0/node_modules/react/index.js
var react = __webpack_require__(96651);
// EXTERNAL MODULE: ./src/page/Company/components/EditPannel/index.tsx + 1 modules
var EditPannel = __webpack_require__(49648);
// EXTERNAL MODULE: ./node_modules/.pnpm/antd-mobile@5.35.0_react-dom@18.2.0_react@18.2.0/node_modules/antd-mobile/es/index.js + 43 modules
var es = __webpack_require__(78576);
;// CONCATENATED MODULE: ./src/page/Company/components/Navbar/index.less
// extracted by mini-css-extract-plugin
/* harmony default export */ const components_Navbar = ({"edit__navbar":"src-page-Company-components-Navbar-__index__edit__navbar","navbar":"src-page-Company-components-Navbar-__index__navbar","item":"src-page-Company-components-Navbar-__index__item","active":"src-page-Company-components-Navbar-__index__active","indictor":"src-page-Company-components-Navbar-__index__indictor","body":"src-page-Company-components-Navbar-__index__body","job":"src-page-Company-components-Navbar-__index__job","list":"src-page-Company-components-Navbar-__index__list","no__data":"src-page-Company-components-Navbar-__index__no__data"});
// EXTERNAL MODULE: ./node_modules/.pnpm/classnames@2.5.1/node_modules/classnames/index.js
var classnames = __webpack_require__(10124);
var classnames_default = /*#__PURE__*/__webpack_require__.n(classnames);
// EXTERNAL MODULE: ./src/components/Waterfull/index.tsx + 3 modules
var Waterfull = __webpack_require__(40280);
// EXTERNAL MODULE: ./src/image/common/no-list.png
var no_list = __webpack_require__(37428);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.concat.js
var es_array_concat = __webpack_require__(70516);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__(18440);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/Button/Button.js + 3 modules
var Button = __webpack_require__(80180);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/Chip/Chip.js + 2 modules
var Chip = __webpack_require__(34336);
// EXTERNAL MODULE: ./src/components/Ellipsis/index.tsx + 1 modules
var Ellipsis = __webpack_require__(11008);
// EXTERNAL MODULE: ./src/utils/time.ts
var time = __webpack_require__(56480);
;// CONCATENATED MODULE: ./src/page/Company/components/Navbar/Item/index.less
// extracted by mini-css-extract-plugin
/* harmony default export */ const Navbar_Item = ({"item":"src-page-Company-components-Navbar-Item-__index__item","edit":"src-page-Company-components-Navbar-Item-__index__edit","logo":"src-page-Company-components-Navbar-Item-__index__logo","company__name":"src-page-Company-components-Navbar-Item-__index__company__name","position":"src-page-Company-components-Navbar-Item-__index__position","address":"src-page-Company-components-Navbar-Item-__index__address","required":"src-page-Company-components-Navbar-Item-__index__required","tag":"src-page-Company-components-Navbar-Item-__index__tag","chip":"src-page-Company-components-Navbar-Item-__index__chip","time":"src-page-Company-components-Navbar-Item-__index__time"});
// EXTERNAL MODULE: ./node_modules/.pnpm/react-router@6.22.3_react@18.2.0/node_modules/react-router/dist/index.js
var dist = __webpack_require__(66336);
// EXTERNAL MODULE: ./src/store/index.ts + 4 modules
var store = __webpack_require__(75899);
// EXTERNAL MODULE: ./src/components/AuthBtn/index.tsx
var AuthBtn = __webpack_require__(27444);
;// CONCATENATED MODULE: ./src/page/Company/components/Navbar/Item/index.tsx















var Item = function Item(props) {
  var _data$tag;
  var data = props.data,
    userId = props.userId;
  var confirmRef = (0,react.useRef)();
  var navigate = (0,dist/* useNavigate */.i6)();
  var _userUserStore = (0,store/* userUserStore */.Wu)(),
    userInfo = _userUserStore.userInfo;
  var id = userInfo.id;
  var salary = (0,react.useMemo)(function () {
    return data !== null && data !== void 0 && data.isFace ? "面议" : "".concat(data.minSalary, "~").concat(data.maxSalary);
  }, [data]);
  return /*#__PURE__*/react.createElement("div", {
    className: Navbar_Item.item,
    onClick: function onClick() {
      navigate("/job/".concat(data.id));
    }
  }, id === userId && /*#__PURE__*/react.createElement("div", {
    className: Navbar_Item.edit
  }, /*#__PURE__*/react.createElement(AuthBtn/* AuthBtn */.k, null, /*#__PURE__*/react.createElement(Button/* default */.c, {
    onClick: function onClick(event) {
      event.stopPropagation();
      navigate("/updateJob/".concat(data.id));
    }
  }, "\u7F16\u8F91"))), /*#__PURE__*/react.createElement("div", {
    className: Navbar_Item.position
  }, /*#__PURE__*/react.createElement("span", null, data.name), /*#__PURE__*/react.createElement("span", null, salary)), /*#__PURE__*/react.createElement("div", {
    className: Navbar_Item.tag
  }, data === null || data === void 0 || (_data$tag = data.tag) === null || _data$tag === void 0 ? void 0 : _data$tag.split(",").map(function (item) {
    return /*#__PURE__*/react.createElement(Chip/* default */.c, {
      key: item,
      label: item,
      className: Navbar_Item.chip,
      size: "small"
    });
  }), /*#__PURE__*/react.createElement(Chip/* default */.c, {
    key: data !== null && data !== void 0 && data.isRemote ? "支持远程" : "不支持远程",
    label: data !== null && data !== void 0 && data.isRemote ? "支持远程" : "不支持远程",
    className: Navbar_Item.chip,
    size: "small"
  })), /*#__PURE__*/react.createElement("div", {
    className: Navbar_Item.address
  }, /*#__PURE__*/react.createElement("span", null, "\u5730\u5740\uFF1A"), /*#__PURE__*/react.createElement("span", null, data.location)), /*#__PURE__*/react.createElement("div", {
    className: Navbar_Item.required
  }, /*#__PURE__*/react.createElement("span", null, "\u5C97\u4F4D\u63CF\u8FF0"), /*#__PURE__*/react.createElement(Ellipsis/* Ellipsis */.C, {
    content: data.description
  })), /*#__PURE__*/react.createElement("div", {
    className: Navbar_Item.time
  }, /*#__PURE__*/react.createElement("span", null, (0,time/* timeAgo */.c)(new Date(data === null || data === void 0 ? void 0 : data.updatedAt).getTime()))));
};
;// CONCATENATED MODULE: ./src/page/Company/components/Navbar/index.tsx














function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }









var Navbar = function Navbar(props) {
  var companyId = props.companyId,
    userId = props.userId;
  var _useState = (0,react.useState)(1000),
    _useState2 = _slicedToArray(_useState, 2),
    index = _useState2[0],
    setIndex = _useState2[1];
  var _useState3 = (0,react.useState)(0),
    _useState4 = _slicedToArray(_useState3, 2),
    height = _useState4[0],
    setHeight = _useState4[1];
  var _useState5 = (0,react.useState)(1552),
    _useState6 = _slicedToArray(_useState5, 2),
    width = _useState6[0],
    setWidth = _useState6[1];
  var _useState7 = (0,react.useState)(4),
    _useState8 = _slicedToArray(_useState7, 2),
    columns = _useState8[0],
    setColumns = _useState8[1];
  // const { getJobList, jobList } = useJobListStore();
  (0,react.useEffect)(function () {
    var width = document.documentElement.clientWidth;
    if (width < 1700) {
      setWidth(width - 148);
      if (width < 1500) {
        setColumns(3);
      }
    }
    if (width < 750) {
      setWidth(width - 50);
      setColumns(1);
    }
  }, []);
  // useEffect(() => {
  //   // if (companyId) {
  //   getJobList(companyId);
  //   // }
  // }, [companyId]);
  var _useJobListStore = (0,store/* useJobListStore */.SC)(),
    getJobList = _useJobListStore.getJobList,
    hasMore = _useJobListStore.hasMore,
    refresh = _useJobListStore.refresh,
    refreshing = _useJobListStore.refreshing,
    first = _useJobListStore.first,
    jobList = _useJobListStore.jobList;
  return /*#__PURE__*/react.createElement(EditPannel/* EditPannel */.Q, {
    className: components_Navbar.edit__navbar,
    showEdit: false
  }, /*#__PURE__*/react.createElement("div", {
    className: components_Navbar.navbar,
    id: "jobs"
  }, /*#__PURE__*/react.createElement("div", {
    className: classnames_default()(components_Navbar.item, index === 0 ? components_Navbar.active : ""),
    onClick: function onClick() {
      setIndex(0);
    }
  }, /*#__PURE__*/react.createElement("span", null, "\u804C\u4F4D")), /*#__PURE__*/react.createElement("div", {
    className: components_Navbar.indictor,
    style: {
      left: "".concat(index * 100, "px")
    }
  })), /*#__PURE__*/react.createElement(es/* PullToRefresh */.cd, {
    onRefresh: function onRefresh() {
      // store.Message.resetCOData();
      // store.Message.setCORefresh(true);
      refresh();
      return getJobList(companyId);
    }
  }, /*#__PURE__*/react.createElement("div", {
    className: components_Navbar.body,
    style: {
      height: (jobList === null || jobList === void 0 ? void 0 : jobList.length) > 0 ? height : "auto"
    }
  }, (jobList === null || jobList === void 0 ? void 0 : jobList.length) > 0 ? /*#__PURE__*/react.createElement(Waterfull/* Waterfull */.K_, {
    columns: columns,
    data: jobList,
    width: width,
    itemGap: 15,
    renderItem: function renderItem(data) {
      return /*#__PURE__*/react.createElement(Item, {
        data: data,
        userId: userId
      });
    },
    onHeight: function onHeight(height) {
      setHeight(height);
    }
  }) : /*#__PURE__*/react.createElement("div", {
    className: components_Navbar.no__data
  }, /*#__PURE__*/react.createElement("img", {
    src: no_list
  }), /*#__PURE__*/react.createElement("span", null, "\u8D76\u5FEB\u53BB\u53D1\u5E03\u5C97\u4F4D\u5427"))), !refreshing && (first || jobList.length > 0) && /*#__PURE__*/react.createElement(es/* InfiniteScroll */.kl, {
    hasMore: hasMore,
    loadMore: function loadMore() {
      return getJobList(companyId);
    },
    className: classnames_default()(components_Navbar.footer)
  })));
};

/***/ }),

/***/ 63584:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  u: () => (/* binding */ Picture)
});

// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.js
var es_symbol = __webpack_require__(42856);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.description.js
var es_symbol_description = __webpack_require__(63397);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.async-iterator.js
var es_symbol_async_iterator = __webpack_require__(44024);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.iterator.js
var es_symbol_iterator = __webpack_require__(54000);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.symbol.to-string-tag.js
var es_symbol_to_string_tag = __webpack_require__(78264);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.concat.js
var es_array_concat = __webpack_require__(70516);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__(36160);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.for-each.js
var es_array_for_each = __webpack_require__(93552);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.from.js
var es_array_from = __webpack_require__(67972);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.is-array.js
var es_array_is_array = __webpack_require__(29448);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.iterator.js
var es_array_iterator = __webpack_require__(44272);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__(18440);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.reverse.js
var es_array_reverse = __webpack_require__(51136);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.array.slice.js
var es_array_slice = __webpack_require__(72344);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.date.to-string.js
var es_date_to_string = __webpack_require__(28612);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__(26572);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.json.to-string-tag.js
var es_json_to_string_tag = __webpack_require__(70048);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.math.to-string-tag.js
var es_math_to_string_tag = __webpack_require__(97304);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.object.create.js
var es_object_create = __webpack_require__(66056);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.object.define-property.js
var es_object_define_property = __webpack_require__(55888);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.object.get-prototype-of.js
var es_object_get_prototype_of = __webpack_require__(98232);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.object.set-prototype-of.js
var es_object_set_prototype_of = __webpack_require__(37456);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__(88012);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.promise.js
var es_promise = __webpack_require__(75908);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__(23784);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.regexp.to-string.js
var es_regexp_to_string = __webpack_require__(81852);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/es.string.iterator.js
var es_string_iterator = __webpack_require__(13755);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/web.dom-collections.for-each.js
var web_dom_collections_for_each = __webpack_require__(23408);
// EXTERNAL MODULE: ./node_modules/.pnpm/core-js@3.35.1/node_modules/core-js/modules/web.dom-collections.iterator.js
var web_dom_collections_iterator = __webpack_require__(22248);
// EXTERNAL MODULE: ./node_modules/.pnpm/react@18.2.0/node_modules/react/index.js
var react = __webpack_require__(96651);
// EXTERNAL MODULE: ./node_modules/.pnpm/antd@5.14.0_react-dom@18.2.0_react@18.2.0/node_modules/antd/es/upload/index.js + 34 modules
var upload = __webpack_require__(10700);
// EXTERNAL MODULE: ./node_modules/.pnpm/react-photo-view@1.2.4_react-dom@18.2.0_react@18.2.0/node_modules/react-photo-view/dist/react-photo-view.module.js
var react_photo_view_module = __webpack_require__(33171);
// EXTERNAL MODULE: ./src/image/common/no-list.png
var no_list = __webpack_require__(37428);
// EXTERNAL MODULE: ./src/api/company.ts
var company = __webpack_require__(4512);
// EXTERNAL MODULE: ./src/components/Image/index.tsx + 1 modules
var Image = __webpack_require__(97144);
;// CONCATENATED MODULE: ./src/page/Company/components/Picture/index.less
// extracted by mini-css-extract-plugin
/* harmony default export */ const components_Picture = ({"picture":"src-page-Company-components-Picture-__index__picture","image":"src-page-Company-components-Picture-__index__image","delete":"src-page-Company-components-Picture-__index__delete","preview__image":"src-page-Company-components-Picture-__index__preview__image","no__data":"src-page-Company-components-Picture-__index__no__data","upload":"src-page-Company-components-Picture-__index__upload","edit__picture":"src-page-Company-components-Picture-__index__edit__picture"});
// EXTERNAL MODULE: ./src/page/Company/components/EditPannel/index.tsx + 1 modules
var EditPannel = __webpack_require__(49648);
// EXTERNAL MODULE: ./src/store/index.ts + 4 modules
var store = __webpack_require__(75899);
// EXTERNAL MODULE: ./node_modules/.pnpm/react-hot-toast@2.4.1_csstype@3.1.3_react-dom@18.2.0_react@18.2.0/node_modules/react-hot-toast/dist/index.mjs
var dist = __webpack_require__(98448);
// EXTERNAL MODULE: ./src/constant/index.ts
var constant = __webpack_require__(39784);
;// CONCATENATED MODULE: ./src/page/Company/components/Picture/index.tsx
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == _typeof(h) && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator["return"] && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(_typeof(e) + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, "catch": function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }





























function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }












var Picture = function Picture(props) {
  var companyId = props.companyId,
    userId = props.userId;
  var _useState = (0,react.useState)(false),
    _useState2 = _slicedToArray(_useState, 2),
    isEdit = _useState2[0],
    setIsEdit = _useState2[1];
  var _userUserStore = (0,store/* userUserStore */.Wu)(),
    userInfo = _userUserStore.userInfo;
  var id = userInfo.id;
  var _useState3 = (0,react.useState)([]),
    _useState4 = _slicedToArray(_useState3, 2),
    fileList = _useState4[0],
    setFileList = _useState4[1];
  var handleChange = function handleChange(_ref) {
    var newFileList = _ref.fileList,
      file = _ref.file;
    var list = [file].map(function (item) {
      var _item$response;
      return item === null || item === void 0 || (_item$response = item.response) === null || _item$response === void 0 ? void 0 : _item$response.result;
    }).filter(function (item) {
      return item;
    });
    setFileList(list.concat(fileList));
  };
  var onSave = /*#__PURE__*/function () {
    var _ref2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
      var pictures, _yield$addPicture, result;
      return _regeneratorRuntime().wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            if (companyId) {
              _context.next = 3;
              break;
            }
            dist/* default */.cp.error("先填写项目/团队/公司/基本信息");
            return _context.abrupt("return");
          case 3:
            pictures = fileList.map(function (item) {
              return {
                url: item === null || item === void 0 ? void 0 : item.url,
                companyId: companyId
              };
            });
            _context.next = 6;
            return (0,company/* addPicture */.MN)(companyId, {
              pictures: pictures
            });
          case 6:
            _yield$addPicture = _context.sent;
            result = _yield$addPicture.result;
            setIsEdit(false);
          case 9:
          case "end":
            return _context.stop();
        }
      }, _callee);
    }));
    return function onSave() {
      return _ref2.apply(this, arguments);
    };
  }();
  var handleGetPicture = /*#__PURE__*/function () {
    var _ref3 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
      var _yield$getPicture, result;
      return _regeneratorRuntime().wrap(function _callee2$(_context2) {
        while (1) switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return (0,company/* getPicture */.kT)(companyId);
          case 2:
            _yield$getPicture = _context2.sent;
            result = _yield$getPicture.result;
            setFileList(result.list);
          case 5:
          case "end":
            return _context2.stop();
        }
      }, _callee2);
    }));
    return function handleGetPicture() {
      return _ref3.apply(this, arguments);
    };
  }();
  (0,react.useEffect)(function () {
    if (companyId) {
      handleGetPicture();
    }
  }, [companyId]);
  return /*#__PURE__*/react.createElement(EditPannel/* EditPannel */.Q, {
    onEdit: function onEdit() {
      if (!companyId) {
        (0,dist/* default */.cp)("先要完善项目/团队/公司信息", {
          icon: "😬",
          duration: 5000
        });
        return;
      }
      setIsEdit(true);
    },
    isEdit: isEdit,
    onClose: function onClose() {
      setIsEdit(false);
    },
    onSave: onSave,
    showEdit: id === userId || !companyId,
    className: components_Picture.edit__picture
  }, /*#__PURE__*/react.createElement("div", {
    className: components_Picture.picture
  }, /*#__PURE__*/react.createElement(react_photo_view_module/* PhotoProvider */.SQ, null, fileList.map(function (item) {
    // console.log(item?.response.result.url);
    return /*#__PURE__*/react.createElement(react_photo_view_module/* PhotoView */.cJ, {
      src: item === null || item === void 0 ? void 0 : item.url,
      key: item === null || item === void 0 ? void 0 : item.id
    }, /*#__PURE__*/react.createElement("div", {
      className: components_Picture.image
    }, isEdit && /*#__PURE__*/react.createElement("div", {
      className: components_Picture["delete"],
      onClick: function onClick(event) {
        event.stopPropagation();
        var newFileList = fileList.filter(function (v) {
          return v.id !== item.id;
        });
        setFileList(newFileList);
      }
    }, /*#__PURE__*/react.createElement("i", {
      className: "iconfont icon-shanchu1"
    })), /*#__PURE__*/react.createElement(Image/* Image */.W, {
      src: item === null || item === void 0 ? void 0 : item.url,
      alt: "",
      className: components_Picture.preview__image
    })));
  })), isEdit && fileList.length < 6 ? /*#__PURE__*/react.createElement(upload/* default */.c
  // className={styles.upload}
  , {
    action: "".concat(constant/* BASE_URL */.yk, "/common/upload"),
    listType: "picture-card",
    showUploadList: false,
    onChange: handleChange,
    beforeUpload: function beforeUpload() {
      if (fileList.length === 6) {
        dist/* default */.cp.error("目前最多支持6张图片");
        return;
      }
    },
    headers: {
      Authorization: "Bearer ".concat(localStorage.getItem("token"))
    }
  }, /*#__PURE__*/react.createElement("div", {
    className: components_Picture.upload
  })) : /*#__PURE__*/react.createElement(react.Fragment, null, (fileList === null || fileList === void 0 ? void 0 : fileList.length) === 0 && /*#__PURE__*/react.createElement("div", {
    className: components_Picture.no__data
  }, /*#__PURE__*/react.createElement("img", {
    src: no_list
  }), /*#__PURE__*/react.createElement("span", null, "\u8D76\u5FEB\u53BB\u4E0A\u4F20\u56FE\u7247\u5427")))));
};

/***/ })

}]);