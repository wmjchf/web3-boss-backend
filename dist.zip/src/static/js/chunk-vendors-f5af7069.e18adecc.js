(self["webpackChunkweb3_design_style"] = self["webpackChunkweb3_design_style"] || []).push([[396],{

/***/ 75056:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* module decorator */ module = __webpack_require__.nmd(module);
(function(module) {
    'use strict';

    module.exports.is_uri = is_iri;
    module.exports.is_http_uri = is_http_iri;
    module.exports.is_https_uri = is_https_iri;
    module.exports.is_web_uri = is_web_iri;
    // Create aliases
    module.exports.isUri = is_iri;
    module.exports.isHttpUri = is_http_iri;
    module.exports.isHttpsUri = is_https_iri;
    module.exports.isWebUri = is_web_iri;


    // private function
    // internal URI spitter method - direct from RFC 3986
    var splitUri = function(uri) {
        var splitted = uri.match(/(?:([^:\/?#]+):)?(?:\/\/([^\/?#]*))?([^?#]*)(?:\?([^#]*))?(?:#(.*))?/);
        return splitted;
    };

    function is_iri(value) {
        if (!value) {
            return;
        }

        // check for illegal characters
        if (/[^a-z0-9\:\/\?\#\[\]\@\!\$\&\'\(\)\*\+\,\;\=\.\-\_\~\%]/i.test(value)) return;

        // check for hex escapes that aren't complete
        if (/%[^0-9a-f]/i.test(value)) return;
        if (/%[0-9a-f](:?[^0-9a-f]|$)/i.test(value)) return;

        var splitted = [];
        var scheme = '';
        var authority = '';
        var path = '';
        var query = '';
        var fragment = '';
        var out = '';

        // from RFC 3986
        splitted = splitUri(value);
        scheme = splitted[1]; 
        authority = splitted[2];
        path = splitted[3];
        query = splitted[4];
        fragment = splitted[5];

        // scheme and path are required, though the path can be empty
        if (!(scheme && scheme.length && path.length >= 0)) return;

        // if authority is present, the path must be empty or begin with a /
        if (authority && authority.length) {
            if (!(path.length === 0 || /^\//.test(path))) return;
        } else {
            // if authority is not present, the path must not start with //
            if (/^\/\//.test(path)) return;
        }

        // scheme must begin with a letter, then consist of letters, digits, +, ., or -
        if (!/^[a-z][a-z0-9\+\-\.]*$/.test(scheme.toLowerCase()))  return;

        // re-assemble the URL per section 5.3 in RFC 3986
        out += scheme + ':';
        if (authority && authority.length) {
            out += '//' + authority;
        }

        out += path;

        if (query && query.length) {
            out += '?' + query;
        }

        if (fragment && fragment.length) {
            out += '#' + fragment;
        }

        return out;
    }

    function is_http_iri(value, allowHttps) {
        if (!is_iri(value)) {
            return;
        }

        var splitted = [];
        var scheme = '';
        var authority = '';
        var path = '';
        var port = '';
        var query = '';
        var fragment = '';
        var out = '';

        // from RFC 3986
        splitted = splitUri(value);
        scheme = splitted[1]; 
        authority = splitted[2];
        path = splitted[3];
        query = splitted[4];
        fragment = splitted[5];

        if (!scheme)  return;

        if(allowHttps) {
            if (scheme.toLowerCase() != 'https') return;
        } else {
            if (scheme.toLowerCase() != 'http') return;
        }

        // fully-qualified URIs must have an authority section that is
        // a valid host
        if (!authority) {
            return;
        }

        // enable port component
        if (/:(\d+)$/.test(authority)) {
            port = authority.match(/:(\d+)$/)[0];
            authority = authority.replace(/:\d+$/, '');
        }

        out += scheme + ':';
        out += '//' + authority;
        
        if (port) {
            out += port;
        }
        
        out += path;
        
        if(query && query.length){
            out += '?' + query;
        }

        if(fragment && fragment.length){
            out += '#' + fragment;
        }
        
        return out;
    }

    function is_https_iri(value) {
        return is_http_iri(value, true);
    }

    function is_web_iri(value) {
        return (is_http_iri(value) || is_https_iri(value));
    }

})(module);


/***/ }),

/***/ 47292:
/***/ ((module) => {

"use strict";
/**
 * Copyright (c) 2014-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



/**
 * Similar to invariant but only logs a warning if the condition is not met.
 * This can be used to log issues in development environments in critical
 * paths. Removing the logging code for production environments will keep the
 * same logic and follow the same code paths.
 */

var __DEV__ = "production" !== 'production';

var warning = function() {};

if (__DEV__) {
  var printWarning = function printWarning(format, args) {
    var len = arguments.length;
    args = new Array(len > 1 ? len - 1 : 0);
    for (var key = 1; key < len; key++) {
      args[key - 1] = arguments[key];
    }
    var argIndex = 0;
    var message = 'Warning: ' +
      format.replace(/%s/g, function() {
        return args[argIndex++];
      });
    if (typeof console !== 'undefined') {
      console.error(message);
    }
    try {
      // --- Welcome to debugging React ---
      // This error was thrown as a convenience so that you can use this stack
      // to find the callsite that caused this warning to fire.
      throw new Error(message);
    } catch (x) {}
  }

  warning = function(condition, format, args) {
    var len = arguments.length;
    args = new Array(len > 2 ? len - 2 : 0);
    for (var key = 2; key < len; key++) {
      args[key - 2] = arguments[key];
    }
    if (format === undefined) {
      throw new Error(
          '`warning(condition, format, ...args)` requires a warning ' +
          'message argument'
      );
    }
    if (!condition) {
      printWarning.apply(null, [format].concat(args));
    }
  };
}

module.exports = warning;


/***/ }),

/***/ 79728:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  U: () => (/* binding */ injected)
});

// EXTERNAL MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/errors/base.js
var base = __webpack_require__(8696);
;// CONCATENATED MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/errors/address.js

class InvalidAddressError extends base/* BaseError */.k {
    constructor({ address }) {
        super(`Address "${address}" is invalid.`);
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'InvalidAddressError'
        });
    }
}
//# sourceMappingURL=address.js.map
// EXTERNAL MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/utils/data/isHex.js
var isHex = __webpack_require__(34984);
// EXTERNAL MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/utils/data/pad.js + 1 modules
var pad = __webpack_require__(34762);
// EXTERNAL MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/utils/encoding/fromHex.js + 1 modules
var fromHex = __webpack_require__(5888);
// EXTERNAL MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/utils/encoding/toHex.js
var toHex = __webpack_require__(71220);
;// CONCATENATED MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/utils/encoding/toBytes.js





const encoder = /*#__PURE__*/ new TextEncoder();
/**
 * Encodes a UTF-8 string, hex value, bigint, number or boolean to a byte array.
 *
 * - Docs: https://viem.sh/docs/utilities/toBytes
 * - Example: https://viem.sh/docs/utilities/toBytes#usage
 *
 * @param value Value to encode.
 * @param opts Options.
 * @returns Byte array value.
 *
 * @example
 * import { toBytes } from 'viem'
 * const data = toBytes('Hello world')
 * // Uint8Array([72, 101, 108, 108, 111, 32, 87, 111, 114, 108, 100, 33])
 *
 * @example
 * import { toBytes } from 'viem'
 * const data = toBytes(420)
 * // Uint8Array([1, 164])
 *
 * @example
 * import { toBytes } from 'viem'
 * const data = toBytes(420, { size: 4 })
 * // Uint8Array([0, 0, 1, 164])
 */
function toBytes(value, opts = {}) {
    if (typeof value === 'number' || typeof value === 'bigint')
        return numberToBytes(value, opts);
    if (typeof value === 'boolean')
        return boolToBytes(value, opts);
    if ((0,isHex/* isHex */.a)(value))
        return hexToBytes(value, opts);
    return stringToBytes(value, opts);
}
/**
 * Encodes a boolean into a byte array.
 *
 * - Docs: https://viem.sh/docs/utilities/toBytes#booltobytes
 *
 * @param value Boolean value to encode.
 * @param opts Options.
 * @returns Byte array value.
 *
 * @example
 * import { boolToBytes } from 'viem'
 * const data = boolToBytes(true)
 * // Uint8Array([1])
 *
 * @example
 * import { boolToBytes } from 'viem'
 * const data = boolToBytes(true, { size: 32 })
 * // Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1])
 */
function boolToBytes(value, opts = {}) {
    const bytes = new Uint8Array(1);
    bytes[0] = Number(value);
    if (typeof opts.size === 'number') {
        (0,fromHex/* assertSize */.OO)(bytes, { size: opts.size });
        return (0,pad/* pad */.eu)(bytes, { size: opts.size });
    }
    return bytes;
}
// We use very optimized technique to convert hex string to byte array
const charCodeMap = {
    zero: 48,
    nine: 57,
    A: 65,
    F: 70,
    a: 97,
    f: 102,
};
function charCodeToBase16(char) {
    if (char >= charCodeMap.zero && char <= charCodeMap.nine)
        return char - charCodeMap.zero;
    if (char >= charCodeMap.A && char <= charCodeMap.F)
        return char - (charCodeMap.A - 10);
    if (char >= charCodeMap.a && char <= charCodeMap.f)
        return char - (charCodeMap.a - 10);
    return undefined;
}
/**
 * Encodes a hex string into a byte array.
 *
 * - Docs: https://viem.sh/docs/utilities/toBytes#hextobytes
 *
 * @param hex Hex string to encode.
 * @param opts Options.
 * @returns Byte array value.
 *
 * @example
 * import { hexToBytes } from 'viem'
 * const data = hexToBytes('0x48656c6c6f20776f726c6421')
 * // Uint8Array([72, 101, 108, 108, 111, 32, 87, 111, 114, 108, 100, 33])
 *
 * @example
 * import { hexToBytes } from 'viem'
 * const data = hexToBytes('0x48656c6c6f20776f726c6421', { size: 32 })
 * // Uint8Array([72, 101, 108, 108, 111, 32, 87, 111, 114, 108, 100, 33, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
 */
function hexToBytes(hex_, opts = {}) {
    let hex = hex_;
    if (opts.size) {
        (0,fromHex/* assertSize */.OO)(hex, { size: opts.size });
        hex = (0,pad/* pad */.eu)(hex, { dir: 'right', size: opts.size });
    }
    let hexString = hex.slice(2);
    if (hexString.length % 2)
        hexString = `0${hexString}`;
    const length = hexString.length / 2;
    const bytes = new Uint8Array(length);
    for (let index = 0, j = 0; index < length; index++) {
        const nibbleLeft = charCodeToBase16(hexString.charCodeAt(j++));
        const nibbleRight = charCodeToBase16(hexString.charCodeAt(j++));
        if (nibbleLeft === undefined || nibbleRight === undefined) {
            throw new base/* BaseError */.k(`Invalid byte sequence ("${hexString[j - 2]}${hexString[j - 1]}" in "${hexString}").`);
        }
        bytes[index] = nibbleLeft * 16 + nibbleRight;
    }
    return bytes;
}
/**
 * Encodes a number into a byte array.
 *
 * - Docs: https://viem.sh/docs/utilities/toBytes#numbertobytes
 *
 * @param value Number to encode.
 * @param opts Options.
 * @returns Byte array value.
 *
 * @example
 * import { numberToBytes } from 'viem'
 * const data = numberToBytes(420)
 * // Uint8Array([1, 164])
 *
 * @example
 * import { numberToBytes } from 'viem'
 * const data = numberToBytes(420, { size: 4 })
 * // Uint8Array([0, 0, 1, 164])
 */
function numberToBytes(value, opts) {
    const hex = (0,toHex/* numberToHex */.c1)(value, opts);
    return hexToBytes(hex);
}
/**
 * Encodes a UTF-8 string into a byte array.
 *
 * - Docs: https://viem.sh/docs/utilities/toBytes#stringtobytes
 *
 * @param value String to encode.
 * @param opts Options.
 * @returns Byte array value.
 *
 * @example
 * import { stringToBytes } from 'viem'
 * const data = stringToBytes('Hello world!')
 * // Uint8Array([72, 101, 108, 108, 111, 32, 119, 111, 114, 108, 100, 33])
 *
 * @example
 * import { stringToBytes } from 'viem'
 * const data = stringToBytes('Hello world!', { size: 32 })
 * // Uint8Array([72, 101, 108, 108, 111, 32, 87, 111, 114, 108, 100, 33, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
 */
function stringToBytes(value, opts = {}) {
    const bytes = encoder.encode(value);
    if (typeof opts.size === 'number') {
        (0,fromHex/* assertSize */.OO)(bytes, { size: opts.size });
        return (0,pad/* pad */.eu)(bytes, { dir: 'right', size: opts.size });
    }
    return bytes;
}
//# sourceMappingURL=toBytes.js.map
// EXTERNAL MODULE: ./node_modules/.pnpm/@noble+hashes@1.3.2/node_modules/@noble/hashes/esm/sha3.js + 3 modules
var sha3 = __webpack_require__(3226);
;// CONCATENATED MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/utils/hash/keccak256.js




function keccak256(value, to_) {
    const to = to_ || 'hex';
    const bytes = (0,sha3/* keccak_256 */.ug)((0,isHex/* isHex */.a)(value, { strict: false }) ? toBytes(value) : value);
    if (to === 'bytes')
        return bytes;
    return (0,toHex/* toHex */.Sm)(bytes);
}
//# sourceMappingURL=keccak256.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/utils/address/isAddress.js
const addressRegex = /^0x[a-fA-F0-9]{40}$/;
function isAddress(address) {
    return addressRegex.test(address);
}
//# sourceMappingURL=isAddress.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/utils/address/getAddress.js




function checksumAddress(address_, chainId) {
    const hexAddress = chainId
        ? `${chainId}${address_.toLowerCase()}`
        : address_.substring(2).toLowerCase();
    const hash = keccak256(stringToBytes(hexAddress), 'bytes');
    const address = (chainId ? hexAddress.substring(`${chainId}0x`.length) : hexAddress).split('');
    for (let i = 0; i < 40; i += 2) {
        if (hash[i >> 1] >> 4 >= 8 && address[i]) {
            address[i] = address[i].toUpperCase();
        }
        if ((hash[i >> 1] & 0x0f) >= 8 && address[i + 1]) {
            address[i + 1] = address[i + 1].toUpperCase();
        }
    }
    return `0x${address.join('')}`;
}
function getAddress(address, chainId) {
    if (!isAddress(address))
        throw new InvalidAddressError({ address });
    return checksumAddress(address, chainId);
}
//# sourceMappingURL=getAddress.js.map
// EXTERNAL MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/errors/rpc.js
var rpc = __webpack_require__(24652);
// EXTERNAL MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/utils/promise/withRetry.js + 1 modules
var withRetry = __webpack_require__(19744);
// EXTERNAL MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/utils/promise/withTimeout.js
var withTimeout = __webpack_require__(68088);
// EXTERNAL MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/errors/config.js
var errors_config = __webpack_require__(3500);
// EXTERNAL MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/errors/base.js + 1 modules
var errors_base = __webpack_require__(54428);
;// CONCATENATED MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/errors/connector.js

class ProviderNotFoundError extends errors_base/* BaseError */.k {
    constructor() {
        super('Provider not found.');
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'ProviderNotFoundError'
        });
    }
}
class SwitchChainNotSupportedError extends errors_base/* BaseError */.k {
    constructor({ connector }) {
        super(`"${connector.name}" does not support programmatic chain switching.`);
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'SwitchChainNotSupportedError'
        });
    }
}
//# sourceMappingURL=connector.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/utils/normalizeChainId.js
function normalizeChainId(chainId) {
    if (typeof chainId === 'string')
        return Number.parseInt(chainId, chainId.trim().substring(0, 2) === '0x' ? 16 : 10);
    if (typeof chainId === 'bigint')
        return Number(chainId);
    if (typeof chainId === 'number')
        return chainId;
    throw new Error(`Cannot normalize chainId "${chainId}" of type "${typeof chainId}"`);
}
//# sourceMappingURL=normalizeChainId.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/connectors/createConnector.js




function createConnector(createConnectorFn) {
    return createConnectorFn;
}
//# sourceMappingURL=createConnector.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/connectors/injected.js






const targetMap = {
    coinbaseWallet: {
        id: 'coinbaseWallet',
        name: 'Coinbase Wallet',
        provider(window) {
            if (window?.coinbaseWalletExtension)
                return window.coinbaseWalletExtension;
            return findProvider(window, 'isCoinbaseWallet');
        },
    },
    metaMask: {
        id: 'metaMask',
        name: 'MetaMask',
        provider(window) {
            return findProvider(window, (provider) => {
                if (!provider.isMetaMask)
                    return false;
                // Brave tries to make itself look like MetaMask
                // Could also try RPC `web3_clientVersion` if following is unreliable
                if (provider.isBraveWallet && !provider._events && !provider._state)
                    return false;
                // Other wallets that try to look like MetaMask
                const flags = [
                    'isApexWallet',
                    'isAvalanche',
                    'isBitKeep',
                    'isBlockWallet',
                    'isKuCoinWallet',
                    'isMathWallet',
                    'isOkxWallet',
                    'isOKExWallet',
                    'isOneInchIOSWallet',
                    'isOneInchAndroidWallet',
                    'isOpera',
                    'isPortal',
                    'isRabby',
                    'isTokenPocket',
                    'isTokenary',
                    'isZerion',
                ];
                for (const flag of flags)
                    if (provider[flag])
                        return false;
                return true;
            });
        },
    },
    phantom: {
        id: 'phantom',
        name: 'Phantom',
        provider(window) {
            if (window?.phantom?.ethereum)
                return window.phantom?.ethereum;
            return findProvider(window, 'isPhantom');
        },
    },
};
injected.type = 'injected';
function injected(parameters = {}) {
    const { shimDisconnect = true, unstable_shimAsyncInject } = parameters;
    function getTarget() {
        const target = parameters.target;
        if (typeof target === 'function') {
            const result = target();
            if (result)
                return result;
        }
        if (typeof target === 'object')
            return target;
        if (typeof target === 'string')
            return {
                ...(targetMap[target] ?? {
                    id: target,
                    name: `${target[0].toUpperCase()}${target.slice(1)}`,
                    provider: `is${target[0].toUpperCase()}${target.slice(1)}`,
                }),
            };
        return {
            id: 'injected',
            name: 'Injected',
            provider(window) {
                return window?.ethereum;
            },
        };
    }
    return createConnector((config) => ({
        get icon() {
            return getTarget().icon;
        },
        get id() {
            return getTarget().id;
        },
        get name() {
            return getTarget().name;
        },
        type: injected.type,
        async setup() {
            const provider = await this.getProvider();
            // Only start listening for events if `target` is set, otherwise `injected()` will also receive events
            if (provider && parameters.target)
                provider.on('connect', this.onConnect.bind(this));
        },
        async connect({ chainId, isReconnecting } = {}) {
            const provider = await this.getProvider();
            if (!provider)
                throw new ProviderNotFoundError();
            let accounts = null;
            if (!isReconnecting) {
                accounts = await this.getAccounts().catch(() => null);
                const isAuthorized = !!accounts?.length;
                if (isAuthorized)
                    // Attempt to show another prompt for selecting account if already connected
                    try {
                        const permissions = await provider.request({
                            method: 'wallet_requestPermissions',
                            params: [{ eth_accounts: {} }],
                        });
                        accounts = permissions[0]?.caveats?.[0]?.value?.map((x) => getAddress(x));
                    }
                    catch (err) {
                        const error = err;
                        // Not all injected providers support `wallet_requestPermissions` (e.g. MetaMask iOS).
                        // Only bubble up error if user rejects request
                        if (error.code === rpc/* UserRejectedRequestError */.qW.code)
                            throw new rpc/* UserRejectedRequestError */.qW(error);
                        // Or prompt is already open
                        if (error.code === rpc/* ResourceUnavailableRpcError */.yW.code)
                            throw error;
                    }
            }
            try {
                if (!accounts?.length) {
                    const requestedAccounts = await provider.request({
                        method: 'eth_requestAccounts',
                    });
                    accounts = requestedAccounts.map((x) => getAddress(x));
                }
                provider.removeListener('connect', this.onConnect.bind(this));
                provider.on('accountsChanged', this.onAccountsChanged.bind(this));
                provider.on('chainChanged', this.onChainChanged);
                provider.on('disconnect', this.onDisconnect.bind(this));
                // Switch to chain if provided
                let currentChainId = await this.getChainId();
                if (chainId && currentChainId !== chainId) {
                    const chain = await this.switchChain({ chainId }).catch((error) => {
                        if (error.code === rpc/* UserRejectedRequestError */.qW.code)
                            throw error;
                        return { id: currentChainId };
                    });
                    currentChainId = chain?.id ?? currentChainId;
                }
                if (shimDisconnect) {
                    // Remove disconnected shim if it exists
                    await config.storage?.removeItem(`${this.id}.disconnected`);
                    // Add connected shim if no target exists
                    if (!parameters.target)
                        await config.storage?.setItem('injected.connected', true);
                }
                return { accounts, chainId: currentChainId };
            }
            catch (err) {
                const error = err;
                if (error.code === rpc/* UserRejectedRequestError */.qW.code)
                    throw new rpc/* UserRejectedRequestError */.qW(error);
                if (error.code === rpc/* ResourceUnavailableRpcError */.yW.code)
                    throw new rpc/* ResourceUnavailableRpcError */.yW(error);
                throw error;
            }
        },
        async disconnect() {
            const provider = await this.getProvider();
            if (!provider)
                throw new ProviderNotFoundError();
            provider.removeListener('accountsChanged', this.onAccountsChanged.bind(this));
            provider.removeListener('chainChanged', this.onChainChanged);
            provider.removeListener('disconnect', this.onDisconnect.bind(this));
            provider.on('connect', this.onConnect.bind(this));
            // Add shim signalling connector is disconnected
            if (shimDisconnect) {
                await config.storage?.setItem(`${this.id}.disconnected`, true);
                if (!parameters.target)
                    await config.storage?.removeItem('injected.connected');
            }
        },
        async getAccounts() {
            const provider = await this.getProvider();
            if (!provider)
                throw new ProviderNotFoundError();
            const accounts = await provider.request({ method: 'eth_accounts' });
            return accounts.map((x) => getAddress(x));
        },
        async getChainId() {
            const provider = await this.getProvider();
            if (!provider)
                throw new ProviderNotFoundError();
            const hexChainId = await provider.request({ method: 'eth_chainId' });
            return normalizeChainId(hexChainId);
        },
        async getProvider() {
            if (typeof window === 'undefined')
                return undefined;
            let provider;
            const target = getTarget();
            if (typeof target.provider === 'function')
                provider = target.provider(window);
            else if (typeof target.provider === 'string')
                provider = findProvider(window, target.provider);
            else
                provider = target.provider;
            // Some wallets do not conform to EIP-1193 (e.g. Trust Wallet)
            // https://github.com/wevm/wagmi/issues/3526#issuecomment-1912683002
            if (provider && !provider.removeListener) {
                // Try using `off` handler if it exists, otherwise noop
                if ('off' in provider && typeof provider.off === 'function')
                    provider.removeListener =
                        provider.off;
                else
                    provider.removeListener = () => { };
            }
            return provider;
        },
        async isAuthorized() {
            try {
                const isDisconnected = shimDisconnect &&
                    // If shim exists in storage, connector is disconnected
                    (await config.storage?.getItem(`${this.id}.disconnected`));
                if (isDisconnected)
                    return false;
                // Don't allow injected connector to connect if no target is set and it hasn't already connected
                // (e.g. flag in storage is not set). This prevents a targetless injected connector from connecting
                // automatically whenever there is a targeted connector configured.
                if (!parameters.target) {
                    const connected = await config.storage?.getItem('injected.connected');
                    if (!connected)
                        return false;
                }
                const provider = await this.getProvider();
                if (!provider) {
                    if (unstable_shimAsyncInject !== undefined &&
                        unstable_shimAsyncInject !== false) {
                        // If no provider is found, check for async injection
                        // https://github.com/wevm/references/issues/167
                        // https://github.com/MetaMask/detect-provider
                        const handleEthereum = async () => {
                            if (typeof window !== 'undefined')
                                window.removeEventListener('ethereum#initialized', handleEthereum);
                            const provider = await this.getProvider();
                            return !!provider;
                        };
                        const timeout = typeof unstable_shimAsyncInject === 'number'
                            ? unstable_shimAsyncInject
                            : 1000;
                        const res = await Promise.race([
                            ...(typeof window !== 'undefined'
                                ? [
                                    new Promise((resolve) => window.addEventListener('ethereum#initialized', () => resolve(handleEthereum()), { once: true })),
                                ]
                                : []),
                            new Promise((resolve) => setTimeout(() => resolve(handleEthereum()), timeout)),
                        ]);
                        if (res)
                            return true;
                    }
                    throw new ProviderNotFoundError();
                }
                // We are applying a retry & timeout strategy here as some injected wallets (e.g. MetaMask) fail to
                // immediately resolve a JSON-RPC request on page load.
                const accounts = await (0,withRetry/* withRetry */.e)(() => (0,withTimeout/* withTimeout */.i)(() => this.getAccounts(), {
                    timeout: 100,
                }));
                return !!accounts.length;
            }
            catch {
                return false;
            }
        },
        async switchChain({ chainId }) {
            const provider = await this.getProvider();
            if (!provider)
                throw new ProviderNotFoundError();
            const chain = config.chains.find((x) => x.id === chainId);
            if (!chain)
                throw new rpc/* SwitchChainError */.M3(new errors_config/* ChainNotConfiguredError */.Cw());
            try {
                await Promise.all([
                    provider.request({
                        method: 'wallet_switchEthereumChain',
                        params: [{ chainId: (0,toHex/* numberToHex */.c1)(chainId) }],
                    }),
                    new Promise((resolve) => config.emitter.once('change', ({ chainId: currentChainId }) => {
                        if (currentChainId === chainId)
                            resolve();
                    })),
                ]);
                return chain;
            }
            catch (err) {
                const error = err;
                // Indicates chain is not added to provider
                if (error.code === 4902 ||
                    // Unwrapping for MetaMask Mobile
                    // https://github.com/MetaMask/metamask-mobile/issues/2944#issuecomment-976988719
                    error
                        ?.data?.originalError?.code === 4902) {
                    try {
                        const { default: blockExplorer, ...blockExplorers } = chain.blockExplorers ?? {};
                        let blockExplorerUrls = [];
                        if (blockExplorer)
                            blockExplorerUrls = [
                                blockExplorer.url,
                                ...Object.values(blockExplorers).map((x) => x.url),
                            ];
                        await provider.request({
                            method: 'wallet_addEthereumChain',
                            params: [
                                {
                                    chainId: (0,toHex/* numberToHex */.c1)(chainId),
                                    chainName: chain.name,
                                    nativeCurrency: chain.nativeCurrency,
                                    rpcUrls: [chain.rpcUrls.default?.http[0] ?? ''],
                                    blockExplorerUrls,
                                },
                            ],
                        });
                        const currentChainId = await this.getChainId();
                        if (currentChainId !== chainId)
                            throw new rpc/* UserRejectedRequestError */.qW(new Error('User rejected switch after adding network.'));
                        return chain;
                    }
                    catch (error) {
                        throw new rpc/* UserRejectedRequestError */.qW(error);
                    }
                }
                if (error.code === rpc/* UserRejectedRequestError */.qW.code)
                    throw new rpc/* UserRejectedRequestError */.qW(error);
                throw new rpc/* SwitchChainError */.M3(error);
            }
        },
        async onAccountsChanged(accounts) {
            // Disconnect if there are no accounts
            if (accounts.length === 0)
                this.onDisconnect();
            // Connect if emitter is listening for connect event (e.g. is disconnected and connects through wallet interface)
            else if (config.emitter.listenerCount('connect')) {
                const chainId = (await this.getChainId()).toString();
                this.onConnect({ chainId });
                // Remove disconnected shim if it exists
                if (shimDisconnect)
                    await config.storage?.removeItem(`${this.id}.disconnected`);
            }
            // Regular change event
            else
                config.emitter.emit('change', {
                    accounts: accounts.map((x) => getAddress(x)),
                });
        },
        onChainChanged(chain) {
            const chainId = normalizeChainId(chain);
            config.emitter.emit('change', { chainId });
        },
        async onConnect(connectInfo) {
            const accounts = await this.getAccounts();
            if (accounts.length === 0)
                return;
            const chainId = normalizeChainId(connectInfo.chainId);
            config.emitter.emit('connect', { accounts, chainId });
            const provider = await this.getProvider();
            if (provider) {
                provider.removeListener('connect', this.onConnect.bind(this));
                provider.on('accountsChanged', this.onAccountsChanged.bind(this));
                provider.on('chainChanged', this.onChainChanged);
                provider.on('disconnect', this.onDisconnect.bind(this));
            }
        },
        async onDisconnect(error) {
            const provider = await this.getProvider();
            // If MetaMask emits a `code: 1013` error, wait for reconnection before disconnecting
            // https://github.com/MetaMask/providers/pull/120
            if (error && error.code === 1013) {
                if (provider && !!(await this.getAccounts()).length)
                    return;
            }
            // No need to remove `${this.id}.disconnected` from storage because `onDisconnect` is typically
            // only called when the wallet is disconnected through the wallet's interface, meaning the wallet
            // actually disconnected and we don't need to simulate it.
            config.emitter.emit('disconnect');
            if (provider) {
                provider.removeListener('accountsChanged', this.onAccountsChanged.bind(this));
                provider.removeListener('chainChanged', this.onChainChanged);
                provider.removeListener('disconnect', this.onDisconnect.bind(this));
                provider.on('connect', this.onConnect.bind(this));
            }
        },
    }));
}
function findProvider(window, select) {
    function isProvider(provider) {
        if (typeof select === 'function')
            return select(provider);
        if (typeof select === 'string')
            return provider[select];
        return true;
    }
    const ethereum = window.ethereum;
    if (ethereum?.providers)
        return ethereum.providers.find((provider) => isProvider(provider));
    if (ethereum && isProvider(ethereum))
        return ethereum;
    return undefined;
}
//# sourceMappingURL=injected.js.map

/***/ }),

/***/ 45606:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  U: () => (/* binding */ createConfig)
});

// EXTERNAL MODULE: ./node_modules/.pnpm/mipd@0.0.5_typescript@5.3.3/node_modules/mipd/dist/esm/store.js + 1 modules
var esm_store = __webpack_require__(10032);
// EXTERNAL MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/clients/createClient.js + 1 modules
var createClient = __webpack_require__(5460);
;// CONCATENATED MODULE: ./node_modules/.pnpm/zustand@4.4.1_immer@10.0.4_react@18.2.0/node_modules/zustand/esm/middleware.mjs
const reduxImpl = (reducer, initial) => (set, _get, api) => {
  api.dispatch = (action) => {
    set((state) => reducer(state, action), false, action);
    return action;
  };
  api.dispatchFromDevtools = true;
  return { dispatch: (...a) => api.dispatch(...a), ...initial };
};
const redux = (/* unused pure expression or super */ null && (reduxImpl));

const trackedConnections = /* @__PURE__ */ new Map();
const getTrackedConnectionState = (name) => {
  const api = trackedConnections.get(name);
  if (!api)
    return {};
  return Object.fromEntries(
    Object.entries(api.stores).map(([key, api2]) => [key, api2.getState()])
  );
};
const extractConnectionInformation = (store, extensionConnector, options) => {
  if (store === void 0) {
    return {
      type: "untracked",
      connection: extensionConnector.connect(options)
    };
  }
  const existingConnection = trackedConnections.get(options.name);
  if (existingConnection) {
    return { type: "tracked", store, ...existingConnection };
  }
  const newConnection = {
    connection: extensionConnector.connect(options),
    stores: {}
  };
  trackedConnections.set(options.name, newConnection);
  return { type: "tracked", store, ...newConnection };
};
const devtoolsImpl = (fn, devtoolsOptions = {}) => (set, get, api) => {
  const { enabled, anonymousActionType, store, ...options } = devtoolsOptions;
  let extensionConnector;
  try {
    extensionConnector = (enabled != null ? enabled : ( false ? 0 : void 0) !== "production") && window.__REDUX_DEVTOOLS_EXTENSION__;
  } catch (e) {
  }
  if (!extensionConnector) {
    if (( false ? 0 : void 0) !== "production" && enabled) {
      console.warn(
        "[zustand devtools middleware] Please install/enable Redux devtools extension"
      );
    }
    return fn(set, get, api);
  }
  const { connection, ...connectionInformation } = extractConnectionInformation(store, extensionConnector, options);
  let isRecording = true;
  api.setState = (state, replace, nameOrAction) => {
    const r = set(state, replace);
    if (!isRecording)
      return r;
    const action = nameOrAction === void 0 ? { type: anonymousActionType || "anonymous" } : typeof nameOrAction === "string" ? { type: nameOrAction } : nameOrAction;
    if (store === void 0) {
      connection == null ? void 0 : connection.send(action, get());
      return r;
    }
    connection == null ? void 0 : connection.send(
      {
        ...action,
        type: `${store}/${action.type}`
      },
      {
        ...getTrackedConnectionState(options.name),
        [store]: api.getState()
      }
    );
    return r;
  };
  const setStateFromDevtools = (...a) => {
    const originalIsRecording = isRecording;
    isRecording = false;
    set(...a);
    isRecording = originalIsRecording;
  };
  const initialState = fn(api.setState, get, api);
  if (connectionInformation.type === "untracked") {
    connection == null ? void 0 : connection.init(initialState);
  } else {
    connectionInformation.stores[connectionInformation.store] = api;
    connection == null ? void 0 : connection.init(
      Object.fromEntries(
        Object.entries(connectionInformation.stores).map(([key, store2]) => [
          key,
          key === connectionInformation.store ? initialState : store2.getState()
        ])
      )
    );
  }
  if (api.dispatchFromDevtools && typeof api.dispatch === "function") {
    let didWarnAboutReservedActionType = false;
    const originalDispatch = api.dispatch;
    api.dispatch = (...a) => {
      if (( false ? 0 : void 0) !== "production" && a[0].type === "__setState" && !didWarnAboutReservedActionType) {
        console.warn(
          '[zustand devtools middleware] "__setState" action type is reserved to set state from the devtools. Avoid using it.'
        );
        didWarnAboutReservedActionType = true;
      }
      originalDispatch(...a);
    };
  }
  connection.subscribe((message) => {
    var _a;
    switch (message.type) {
      case "ACTION":
        if (typeof message.payload !== "string") {
          console.error(
            "[zustand devtools middleware] Unsupported action format"
          );
          return;
        }
        return parseJsonThen(
          message.payload,
          (action) => {
            if (action.type === "__setState") {
              if (store === void 0) {
                setStateFromDevtools(action.state);
                return;
              }
              if (Object.keys(action.state).length !== 1) {
                console.error(
                  `
                    [zustand devtools middleware] Unsupported __setState action format. 
                    When using 'store' option in devtools(), the 'state' should have only one key, which is a value of 'store' that was passed in devtools(),
                    and value of this only key should be a state object. Example: { "type": "__setState", "state": { "abc123Store": { "foo": "bar" } } }
                    `
                );
              }
              const stateFromDevtools = action.state[store];
              if (stateFromDevtools === void 0 || stateFromDevtools === null) {
                return;
              }
              if (JSON.stringify(api.getState()) !== JSON.stringify(stateFromDevtools)) {
                setStateFromDevtools(stateFromDevtools);
              }
              return;
            }
            if (!api.dispatchFromDevtools)
              return;
            if (typeof api.dispatch !== "function")
              return;
            api.dispatch(action);
          }
        );
      case "DISPATCH":
        switch (message.payload.type) {
          case "RESET":
            setStateFromDevtools(initialState);
            if (store === void 0) {
              return connection == null ? void 0 : connection.init(api.getState());
            }
            return connection == null ? void 0 : connection.init(getTrackedConnectionState(options.name));
          case "COMMIT":
            if (store === void 0) {
              connection == null ? void 0 : connection.init(api.getState());
              return;
            }
            return connection == null ? void 0 : connection.init(getTrackedConnectionState(options.name));
          case "ROLLBACK":
            return parseJsonThen(message.state, (state) => {
              if (store === void 0) {
                setStateFromDevtools(state);
                connection == null ? void 0 : connection.init(api.getState());
                return;
              }
              setStateFromDevtools(state[store]);
              connection == null ? void 0 : connection.init(getTrackedConnectionState(options.name));
            });
          case "JUMP_TO_STATE":
          case "JUMP_TO_ACTION":
            return parseJsonThen(message.state, (state) => {
              if (store === void 0) {
                setStateFromDevtools(state);
                return;
              }
              if (JSON.stringify(api.getState()) !== JSON.stringify(state[store])) {
                setStateFromDevtools(state[store]);
              }
            });
          case "IMPORT_STATE": {
            const { nextLiftedState } = message.payload;
            const lastComputedState = (_a = nextLiftedState.computedStates.slice(-1)[0]) == null ? void 0 : _a.state;
            if (!lastComputedState)
              return;
            if (store === void 0) {
              setStateFromDevtools(lastComputedState);
            } else {
              setStateFromDevtools(lastComputedState[store]);
            }
            connection == null ? void 0 : connection.send(
              null,
              // FIXME no-any
              nextLiftedState
            );
            return;
          }
          case "PAUSE_RECORDING":
            return isRecording = !isRecording;
        }
        return;
    }
  });
  return initialState;
};
const devtools = (/* unused pure expression or super */ null && (devtoolsImpl));
const parseJsonThen = (stringified, f) => {
  let parsed;
  try {
    parsed = JSON.parse(stringified);
  } catch (e) {
    console.error(
      "[zustand devtools middleware] Could not parse the received json",
      e
    );
  }
  if (parsed !== void 0)
    f(parsed);
};

const subscribeWithSelectorImpl = (fn) => (set, get, api) => {
  const origSubscribe = api.subscribe;
  api.subscribe = (selector, optListener, options) => {
    let listener = selector;
    if (optListener) {
      const equalityFn = (options == null ? void 0 : options.equalityFn) || Object.is;
      let currentSlice = selector(api.getState());
      listener = (state) => {
        const nextSlice = selector(state);
        if (!equalityFn(currentSlice, nextSlice)) {
          const previousSlice = currentSlice;
          optListener(currentSlice = nextSlice, previousSlice);
        }
      };
      if (options == null ? void 0 : options.fireImmediately) {
        optListener(currentSlice, currentSlice);
      }
    }
    return origSubscribe(listener);
  };
  const initialState = fn(set, get, api);
  return initialState;
};
const subscribeWithSelector = subscribeWithSelectorImpl;

const combine = (initialState, create) => (...a) => Object.assign({}, initialState, create(...a));

function createJSONStorage(getStorage, options) {
  let storage;
  try {
    storage = getStorage();
  } catch (e) {
    return;
  }
  const persistStorage = {
    getItem: (name) => {
      var _a;
      const parse = (str2) => {
        if (str2 === null) {
          return null;
        }
        return JSON.parse(str2, options == null ? void 0 : options.reviver);
      };
      const str = (_a = storage.getItem(name)) != null ? _a : null;
      if (str instanceof Promise) {
        return str.then(parse);
      }
      return parse(str);
    },
    setItem: (name, newValue) => storage.setItem(
      name,
      JSON.stringify(newValue, options == null ? void 0 : options.replacer)
    ),
    removeItem: (name) => storage.removeItem(name)
  };
  return persistStorage;
}
const toThenable = (fn) => (input) => {
  try {
    const result = fn(input);
    if (result instanceof Promise) {
      return result;
    }
    return {
      then(onFulfilled) {
        return toThenable(onFulfilled)(result);
      },
      catch(_onRejected) {
        return this;
      }
    };
  } catch (e) {
    return {
      then(_onFulfilled) {
        return this;
      },
      catch(onRejected) {
        return toThenable(onRejected)(e);
      }
    };
  }
};
const oldImpl = (config, baseOptions) => (set, get, api) => {
  let options = {
    getStorage: () => localStorage,
    serialize: JSON.stringify,
    deserialize: JSON.parse,
    partialize: (state) => state,
    version: 0,
    merge: (persistedState, currentState) => ({
      ...currentState,
      ...persistedState
    }),
    ...baseOptions
  };
  let hasHydrated = false;
  const hydrationListeners = /* @__PURE__ */ new Set();
  const finishHydrationListeners = /* @__PURE__ */ new Set();
  let storage;
  try {
    storage = options.getStorage();
  } catch (e) {
  }
  if (!storage) {
    return config(
      (...args) => {
        console.warn(
          `[zustand persist middleware] Unable to update item '${options.name}', the given storage is currently unavailable.`
        );
        set(...args);
      },
      get,
      api
    );
  }
  const thenableSerialize = toThenable(options.serialize);
  const setItem = () => {
    const state = options.partialize({ ...get() });
    let errorInSync;
    const thenable = thenableSerialize({ state, version: options.version }).then(
      (serializedValue) => storage.setItem(options.name, serializedValue)
    ).catch((e) => {
      errorInSync = e;
    });
    if (errorInSync) {
      throw errorInSync;
    }
    return thenable;
  };
  const savedSetState = api.setState;
  api.setState = (state, replace) => {
    savedSetState(state, replace);
    void setItem();
  };
  const configResult = config(
    (...args) => {
      set(...args);
      void setItem();
    },
    get,
    api
  );
  let stateFromStorage;
  const hydrate = () => {
    var _a;
    if (!storage)
      return;
    hasHydrated = false;
    hydrationListeners.forEach((cb) => cb(get()));
    const postRehydrationCallback = ((_a = options.onRehydrateStorage) == null ? void 0 : _a.call(options, get())) || void 0;
    return toThenable(storage.getItem.bind(storage))(options.name).then((storageValue) => {
      if (storageValue) {
        return options.deserialize(storageValue);
      }
    }).then((deserializedStorageValue) => {
      if (deserializedStorageValue) {
        if (typeof deserializedStorageValue.version === "number" && deserializedStorageValue.version !== options.version) {
          if (options.migrate) {
            return options.migrate(
              deserializedStorageValue.state,
              deserializedStorageValue.version
            );
          }
          console.error(
            `State loaded from storage couldn't be migrated since no migrate function was provided`
          );
        } else {
          return deserializedStorageValue.state;
        }
      }
    }).then((migratedState) => {
      var _a2;
      stateFromStorage = options.merge(
        migratedState,
        (_a2 = get()) != null ? _a2 : configResult
      );
      set(stateFromStorage, true);
      return setItem();
    }).then(() => {
      postRehydrationCallback == null ? void 0 : postRehydrationCallback(stateFromStorage, void 0);
      hasHydrated = true;
      finishHydrationListeners.forEach((cb) => cb(stateFromStorage));
    }).catch((e) => {
      postRehydrationCallback == null ? void 0 : postRehydrationCallback(void 0, e);
    });
  };
  api.persist = {
    setOptions: (newOptions) => {
      options = {
        ...options,
        ...newOptions
      };
      if (newOptions.getStorage) {
        storage = newOptions.getStorage();
      }
    },
    clearStorage: () => {
      storage == null ? void 0 : storage.removeItem(options.name);
    },
    getOptions: () => options,
    rehydrate: () => hydrate(),
    hasHydrated: () => hasHydrated,
    onHydrate: (cb) => {
      hydrationListeners.add(cb);
      return () => {
        hydrationListeners.delete(cb);
      };
    },
    onFinishHydration: (cb) => {
      finishHydrationListeners.add(cb);
      return () => {
        finishHydrationListeners.delete(cb);
      };
    }
  };
  hydrate();
  return stateFromStorage || configResult;
};
const newImpl = (config, baseOptions) => (set, get, api) => {
  let options = {
    storage: createJSONStorage(() => localStorage),
    partialize: (state) => state,
    version: 0,
    merge: (persistedState, currentState) => ({
      ...currentState,
      ...persistedState
    }),
    ...baseOptions
  };
  let hasHydrated = false;
  const hydrationListeners = /* @__PURE__ */ new Set();
  const finishHydrationListeners = /* @__PURE__ */ new Set();
  let storage = options.storage;
  if (!storage) {
    return config(
      (...args) => {
        console.warn(
          `[zustand persist middleware] Unable to update item '${options.name}', the given storage is currently unavailable.`
        );
        set(...args);
      },
      get,
      api
    );
  }
  const setItem = () => {
    const state = options.partialize({ ...get() });
    return storage.setItem(options.name, {
      state,
      version: options.version
    });
  };
  const savedSetState = api.setState;
  api.setState = (state, replace) => {
    savedSetState(state, replace);
    void setItem();
  };
  const configResult = config(
    (...args) => {
      set(...args);
      void setItem();
    },
    get,
    api
  );
  let stateFromStorage;
  const hydrate = () => {
    var _a, _b;
    if (!storage)
      return;
    hasHydrated = false;
    hydrationListeners.forEach((cb) => {
      var _a2;
      return cb((_a2 = get()) != null ? _a2 : configResult);
    });
    const postRehydrationCallback = ((_b = options.onRehydrateStorage) == null ? void 0 : _b.call(options, (_a = get()) != null ? _a : configResult)) || void 0;
    return toThenable(storage.getItem.bind(storage))(options.name).then((deserializedStorageValue) => {
      if (deserializedStorageValue) {
        if (typeof deserializedStorageValue.version === "number" && deserializedStorageValue.version !== options.version) {
          if (options.migrate) {
            return options.migrate(
              deserializedStorageValue.state,
              deserializedStorageValue.version
            );
          }
          console.error(
            `State loaded from storage couldn't be migrated since no migrate function was provided`
          );
        } else {
          return deserializedStorageValue.state;
        }
      }
    }).then((migratedState) => {
      var _a2;
      stateFromStorage = options.merge(
        migratedState,
        (_a2 = get()) != null ? _a2 : configResult
      );
      set(stateFromStorage, true);
      return setItem();
    }).then(() => {
      postRehydrationCallback == null ? void 0 : postRehydrationCallback(stateFromStorage, void 0);
      stateFromStorage = get();
      hasHydrated = true;
      finishHydrationListeners.forEach((cb) => cb(stateFromStorage));
    }).catch((e) => {
      postRehydrationCallback == null ? void 0 : postRehydrationCallback(void 0, e);
    });
  };
  api.persist = {
    setOptions: (newOptions) => {
      options = {
        ...options,
        ...newOptions
      };
      if (newOptions.storage) {
        storage = newOptions.storage;
      }
    },
    clearStorage: () => {
      storage == null ? void 0 : storage.removeItem(options.name);
    },
    getOptions: () => options,
    rehydrate: () => hydrate(),
    hasHydrated: () => hasHydrated,
    onHydrate: (cb) => {
      hydrationListeners.add(cb);
      return () => {
        hydrationListeners.delete(cb);
      };
    },
    onFinishHydration: (cb) => {
      finishHydrationListeners.add(cb);
      return () => {
        finishHydrationListeners.delete(cb);
      };
    }
  };
  if (!options.skipHydration) {
    hydrate();
  }
  return stateFromStorage || configResult;
};
const persistImpl = (config, baseOptions) => {
  if ("getStorage" in baseOptions || "serialize" in baseOptions || "deserialize" in baseOptions) {
    if (( false ? 0 : void 0) !== "production") {
      console.warn(
        "[DEPRECATED] `getStorage`, `serialize` and `deserialize` options are deprecated. Use `storage` option instead."
      );
    }
    return oldImpl(config, baseOptions);
  }
  return newImpl(config, baseOptions);
};
const persist = persistImpl;



;// CONCATENATED MODULE: ./node_modules/.pnpm/zustand@4.4.1_immer@10.0.4_react@18.2.0/node_modules/zustand/esm/vanilla.mjs
const createStoreImpl = (createState) => {
  let state;
  const listeners = /* @__PURE__ */ new Set();
  const setState = (partial, replace) => {
    const nextState = typeof partial === "function" ? partial(state) : partial;
    if (!Object.is(nextState, state)) {
      const previousState = state;
      state = (replace != null ? replace : typeof nextState !== "object") ? nextState : Object.assign({}, state, nextState);
      listeners.forEach((listener) => listener(state, previousState));
    }
  };
  const getState = () => state;
  const subscribe = (listener) => {
    listeners.add(listener);
    return () => listeners.delete(listener);
  };
  const destroy = () => {
    if (( false ? 0 : void 0) !== "production") {
      console.warn(
        "[DEPRECATED] The `destroy` method will be unsupported in a future version. Instead use unsubscribe function returned by subscribe. Everything will be garbage-collected if store is garbage-collected."
      );
    }
    listeners.clear();
  };
  const api = { setState, getState, subscribe, destroy };
  state = createState(setState, getState, api);
  return api;
};
const createStore = (createState) => createState ? createStoreImpl(createState) : createStoreImpl;
var vanilla = (createState) => {
  if (( false ? 0 : void 0) !== "production") {
    console.warn(
      "[DEPRECATED] Default export is deprecated. Instead use import { createStore } from 'zustand/vanilla'."
    );
  }
  return createStore(createState);
};



// EXTERNAL MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/connectors/injected.js + 8 modules
var injected = __webpack_require__(79728);
// EXTERNAL MODULE: ./node_modules/.pnpm/eventemitter3@5.0.1/node_modules/eventemitter3/index.mjs
var eventemitter3 = __webpack_require__(13212);
;// CONCATENATED MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/createEmitter.js
var __classPrivateFieldGet = (undefined && undefined.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _Emitter_emitter;

class Emitter {
    constructor(uid) {
        Object.defineProperty(this, "uid", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: uid
        });
        _Emitter_emitter.set(this, new eventemitter3/* EventEmitter */._());
    }
    on(eventName, fn) {
        __classPrivateFieldGet(this, _Emitter_emitter, "f").on(eventName, fn);
    }
    once(eventName, fn) {
        __classPrivateFieldGet(this, _Emitter_emitter, "f").once(eventName, fn);
    }
    off(eventName, fn) {
        __classPrivateFieldGet(this, _Emitter_emitter, "f").off(eventName, fn);
    }
    emit(eventName, ...params) {
        const data = params[0];
        __classPrivateFieldGet(this, _Emitter_emitter, "f").emit(eventName, { uid: this.uid, ...data });
    }
    listenerCount(eventName) {
        return __classPrivateFieldGet(this, _Emitter_emitter, "f").listenerCount(eventName);
    }
}
_Emitter_emitter = new WeakMap();
function createEmitter(uid) {
    return new Emitter(uid);
}
//# sourceMappingURL=createEmitter.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/utils/deserialize.js
function deserialize_deserialize(value, reviver) {
    return JSON.parse(value, (key, value_) => {
        let value = value_;
        if (value?.__type === 'bigint')
            value = BigInt(value.value);
        if (value?.__type === 'Map')
            value = new Map(value.value);
        return reviver?.(key, value) ?? value;
    });
}
//# sourceMappingURL=deserialize.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/utils/serialize.js
/**
 * Get the reference key for the circular value
 *
 * @param keys the keys to build the reference key from
 * @param cutoff the maximum number of keys to include
 * @returns the reference key
 */
function getReferenceKey(keys, cutoff) {
    return keys.slice(0, cutoff).join('.') || '.';
}
/**
 * Faster `Array.prototype.indexOf` implementation build for slicing / splicing
 *
 * @param array the array to match the value in
 * @param value the value to match
 * @returns the matching index, or -1
 */
function getCutoff(array, value) {
    const { length } = array;
    for (let index = 0; index < length; ++index) {
        if (array[index] === value) {
            return index + 1;
        }
    }
    return 0;
}
/**
 * Create a replacer method that handles circular values
 *
 * @param [replacer] a custom replacer to use for non-circular values
 * @param [circularReplacer] a custom replacer to use for circular methods
 * @returns the value to stringify
 */
function createReplacer(replacer, circularReplacer) {
    const hasReplacer = typeof replacer === 'function';
    const hasCircularReplacer = typeof circularReplacer === 'function';
    const cache = [];
    const keys = [];
    return function replace(key, value) {
        if (typeof value === 'object') {
            if (cache.length) {
                const thisCutoff = getCutoff(cache, this);
                if (thisCutoff === 0) {
                    cache[cache.length] = this;
                }
                else {
                    cache.splice(thisCutoff);
                    keys.splice(thisCutoff);
                }
                keys[keys.length] = key;
                const valueCutoff = getCutoff(cache, value);
                if (valueCutoff !== 0) {
                    return hasCircularReplacer
                        ? circularReplacer.call(this, key, value, getReferenceKey(keys, valueCutoff))
                        : `[ref=${getReferenceKey(keys, valueCutoff)}]`;
                }
            }
            else {
                cache[0] = value;
                keys[0] = key;
            }
        }
        return hasReplacer ? replacer.call(this, key, value) : value;
    };
}
/**
 * Stringifier that handles circular values
 *
 * Forked from https://github.com/planttheidea/fast-stringify
 *
 * @param value to stringify
 * @param [replacer] a custom replacer function for handling standard values
 * @param [indent] the number of spaces to indent the output by
 * @param [circularReplacer] a custom replacer function for handling circular values
 * @returns the stringified output
 */
function serialize_serialize(value, replacer, indent, circularReplacer) {
    return JSON.stringify(value, createReplacer((key, value_) => {
        let value = value_;
        if (typeof value === 'bigint')
            value = { __type: 'bigint', value: value_.toString() };
        if (value instanceof Map)
            value = { __type: 'Map', value: Array.from(value_.entries()) };
        return replacer?.(key, value) ?? value;
    }, circularReplacer), indent ?? undefined);
}
//# sourceMappingURL=serialize.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/createStorage.js




function createStorage(parameters) {
    const { deserialize = deserialize_deserialize, key: prefix = 'wagmi', serialize = serialize_serialize, storage = noopStorage, } = parameters;
    function unwrap(value) {
        if (value instanceof Promise)
            return value.then((x) => x).catch(() => null);
        return value;
    }
    return {
        ...storage,
        key: prefix,
        async getItem(key, defaultValue) {
            const value = storage.getItem(`${prefix}.${key}`);
            const unwrapped = await unwrap(value);
            if (unwrapped)
                return deserialize(unwrapped) ?? null;
            return (defaultValue ?? null);
        },
        async setItem(key, value) {
            const storageKey = `${prefix}.${key}`;
            if (value === null)
                await unwrap(storage.removeItem(storageKey));
            else
                await unwrap(storage.setItem(storageKey, serialize(value)));
        },
        async removeItem(key) {
            await unwrap(storage.removeItem(`${prefix}.${key}`));
        },
    };
}
const noopStorage = {
    getItem: () => null,
    setItem: () => { },
    removeItem: () => { },
};
//# sourceMappingURL=createStorage.js.map
// EXTERNAL MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/errors/config.js
var errors_config = __webpack_require__(3500);
;// CONCATENATED MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/utils/uid.js
const size = 256;
let index = size;
let buffer;
function uid(length = 11) {
    if (!buffer || index + length > size * 2) {
        buffer = '';
        index = 0;
        for (let i = 0; i < size; i++) {
            buffer += ((256 + Math.random() * 256) | 0).toString(16).substring(1);
        }
    }
    return buffer.substring(index, index++ + length);
}
//# sourceMappingURL=uid.js.map
// EXTERNAL MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/version.js
var version = __webpack_require__(280);
;// CONCATENATED MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/createConfig.js











function createConfig(parameters) {
    const { chains, multiInjectedProviderDiscovery = true, storage = createStorage({
        storage: typeof window !== 'undefined' && window.localStorage
            ? window.localStorage
            : noopStorage,
    }), syncConnectedChain = true, ssr, ...rest } = parameters;
    /////////////////////////////////////////////////////////////////////////////////////////////////
    // Set up connectors, clients, etc.
    /////////////////////////////////////////////////////////////////////////////////////////////////
    const mipd = typeof window !== 'undefined' && multiInjectedProviderDiscovery
        ? (0,esm_store/* createStore */.e)()
        : undefined;
    const connectors = createStore(() => [
        ...(rest.connectors ?? []),
        ...(!ssr
            ? mipd?.getProviders().map(providerDetailToConnector) ?? []
            : []),
    ].map(setup));
    function setup(connectorFn) {
        // Set up emitter with uid and add to connector so they are "linked" together.
        const emitter = createEmitter(uid());
        const connector = {
            ...connectorFn({ emitter, chains, storage }),
            emitter,
            uid: emitter.uid,
        };
        // Start listening for `connect` events on connector setup
        // This allows connectors to "connect" themselves without user interaction (e.g. MetaMask's "Manually connect to current site")
        emitter.on('connect', connect);
        connector.setup?.();
        return connector;
    }
    function providerDetailToConnector(providerDetail) {
        const { info } = providerDetail;
        const provider = providerDetail.provider;
        return (0,injected/* injected */.U)({ target: { ...info, id: info.rdns, provider } });
    }
    const clients = new Map();
    function getClient(config = {}) {
        const chainId = config.chainId ?? store.getState().chainId;
        const chain = chains.find((x) => x.id === chainId);
        // chainId specified and not configured
        if (config.chainId && !chain)
            throw new errors_config/* ChainNotConfiguredError */.Cw();
        {
            const client = clients.get(store.getState().chainId);
            if (client && !chain)
                return client;
            else if (!chain)
                throw new errors_config/* ChainNotConfiguredError */.Cw();
        }
        // If a memoized client exists for a chain id, use that.
        {
            const client = clients.get(chainId);
            if (client)
                return client;
        }
        let client;
        if (rest.client)
            client = rest.client({ chain });
        else {
            const chainId = chain.id;
            // Grab all properties off `rest` and resolve for use in `createClient`
            const properties = {};
            const entries = Object.entries(rest);
            for (const [key, value] of entries) {
                if (key === 'client' || key === 'connectors' || key === 'transports')
                    continue;
                else {
                    if (typeof value === 'object')
                        properties[key] = value[chainId];
                    else
                        properties[key] = value;
                }
            }
            client = (0,createClient/* createClient */.M)({
                ...properties,
                chain,
                batch: properties.batch ?? { multicall: true },
                transport: (parameters) => rest.transports[chainId]({ ...parameters, connectors }),
            });
        }
        clients.set(chainId, client);
        return client;
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////
    // Create store
    /////////////////////////////////////////////////////////////////////////////////////////////////
    const initialState = {
        chainId: chains[0].id,
        connections: new Map(),
        current: undefined,
        status: 'disconnected',
    };
    let currentVersion;
    const prefix = '0.0.0-canary-';
    if (version/* version */.W.startsWith(prefix))
        currentVersion = parseInt(version/* version */.W.replace(prefix, ''));
    else
        currentVersion = parseInt(version/* version */.W.split('.')[0] ?? '0');
    const store = createStore(subscribeWithSelector(
    // only use persist middleware if storage exists
    storage
        ? persist(() => initialState, {
            migrate(persistedState, version) {
                if (version === currentVersion)
                    return persistedState;
                const chainId = persistedState &&
                    typeof persistedState === 'object' &&
                    'chainId' in persistedState &&
                    typeof persistedState.chainId === 'number'
                    ? persistedState.chainId
                    : initialState.chainId;
                return { ...initialState, chainId };
            },
            name: 'store',
            partialize(state) {
                // Only persist "critical" store properties to preserve storage size.
                return {
                    connections: {
                        __type: 'Map',
                        value: Array.from(state.connections.entries()).map(([key, connection]) => {
                            const { id, name, type, uid } = connection.connector;
                            const connector = { id, name, type, uid };
                            return [key, { ...connection, connector }];
                        }),
                    },
                    chainId: state.chainId,
                    current: state.current,
                };
            },
            skipHydration: ssr,
            storage: storage,
            version: currentVersion,
        })
        : () => initialState));
    /////////////////////////////////////////////////////////////////////////////////////////////////
    // Subscribe to changes
    /////////////////////////////////////////////////////////////////////////////////////////////////
    // Update default chain when connector chain changes
    if (syncConnectedChain)
        store.subscribe(({ connections, current }) => current ? connections.get(current)?.chainId : undefined, (chainId) => {
            // If chain is not configured, then don't switch over to it.
            const isChainConfigured = chains.some((x) => x.id === chainId);
            if (!isChainConfigured)
                return;
            return store.setState((x) => ({
                ...x,
                chainId: chainId ?? x.chainId,
            }));
        });
    // EIP-6963 subscribe for new wallet providers
    mipd?.subscribe((providerDetails) => {
        const currentConnectorIds = new Map();
        for (const connector of connectors.getState()) {
            currentConnectorIds.set(connector.id, true);
        }
        const newConnectors = [];
        for (const providerDetail of providerDetails) {
            const connector = setup(providerDetailToConnector(providerDetail));
            if (currentConnectorIds.has(connector.id))
                continue;
            newConnectors.push(connector);
        }
        connectors.setState((x) => [...x, ...newConnectors], true);
    });
    /////////////////////////////////////////////////////////////////////////////////////////////////
    // Emitter listeners
    /////////////////////////////////////////////////////////////////////////////////////////////////
    function change(data) {
        store.setState((x) => {
            const connection = x.connections.get(data.uid);
            return {
                ...x,
                connections: new Map(x.connections).set(data.uid, {
                    accounts: data.accounts ??
                        connection.accounts,
                    chainId: data.chainId ?? connection.chainId,
                    connector: connection.connector,
                }),
            };
        });
    }
    function connect(data) {
        // Disable handling if reconnecting/connecting
        if (store.getState().status === 'connecting' ||
            store.getState().status === 'reconnecting')
            return;
        store.setState((x) => {
            const connector = connectors.getState().find((x) => x.uid === data.uid);
            if (!connector)
                return x;
            return {
                ...x,
                connections: new Map(x.connections).set(data.uid, {
                    accounts: data.accounts,
                    chainId: data.chainId,
                    connector: connector,
                }),
                current: data.uid,
                status: 'connected',
            };
        });
    }
    function disconnect(data) {
        store.setState((x) => {
            const connection = x.connections.get(data.uid);
            if (connection) {
                connection.connector.emitter.off('change', change);
                connection.connector.emitter.off('disconnect', disconnect);
                connection.connector.emitter.on('connect', connect);
            }
            x.connections.delete(data.uid);
            if (x.connections.size === 0)
                return {
                    ...x,
                    connections: new Map(),
                    current: undefined,
                    status: 'disconnected',
                };
            const nextConnection = x.connections.values().next().value;
            return {
                ...x,
                connections: new Map(x.connections),
                current: nextConnection.connector.uid,
            };
        });
    }
    return {
        chains: chains,
        get connectors() {
            return connectors.getState();
        },
        storage,
        getClient,
        get state() {
            return store.getState();
        },
        setState(value) {
            let newState;
            if (typeof value === 'function')
                newState = value(store.getState());
            else
                newState = value;
            // Reset state if it got set to something not matching the base state
            if (typeof newState !== 'object')
                newState = initialState;
            const isCorrupt = Object.keys(initialState).some((x) => !(x in newState));
            if (isCorrupt)
                newState = initialState;
            store.setState(newState, true);
        },
        subscribe(selector, listener, options) {
            return store.subscribe(selector, listener, options
                ? { ...options, fireImmediately: options.emitImmediately }
                : undefined);
        },
        _internal: {
            mipd,
            store,
            ssr: Boolean(ssr),
            syncConnectedChain,
            transports: rest.transports,
            connectors: {
                providerDetailToConnector,
                setup,
                setState: (value) => connectors.setState(typeof value === 'function' ? value(connectors.getState()) : value, true),
                subscribe: (listener) => connectors.subscribe(listener),
            },
            events: { change, connect, disconnect },
        },
    };
}
//# sourceMappingURL=createConfig.js.map

/***/ }),

/***/ 54428:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  k: () => (/* binding */ BaseError)
});

// EXTERNAL MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/version.js
var version = __webpack_require__(280);
;// CONCATENATED MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/utils/getVersion.js

const getVersion = () => `@wagmi/core@${version/* version */.W}`;
//# sourceMappingURL=getVersion.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/errors/base.js
var __classPrivateFieldGet = (undefined && undefined.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _BaseError_instances, _BaseError_walk;

class BaseError extends Error {
    get docsBaseUrl() {
        return 'https://wagmi.sh/core';
    }
    get version() {
        return getVersion();
    }
    constructor(shortMessage, options = {}) {
        super();
        _BaseError_instances.add(this);
        Object.defineProperty(this, "details", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "docsPath", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "metaMessages", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "shortMessage", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'WagmiCoreError'
        });
        const details = options.cause instanceof BaseError
            ? options.cause.details
            : options.cause?.message
                ? options.cause.message
                : options.details;
        const docsPath = options.cause instanceof BaseError
            ? options.cause.docsPath || options.docsPath
            : options.docsPath;
        this.message = [
            shortMessage || 'An error occurred.',
            '',
            ...(options.metaMessages ? [...options.metaMessages, ''] : []),
            ...(docsPath
                ? [
                    `Docs: ${this.docsBaseUrl}${docsPath}.html${options.docsSlug ? `#${options.docsSlug}` : ''}`,
                ]
                : []),
            ...(details ? [`Details: ${details}`] : []),
            `Version: ${this.version}`,
        ].join('\n');
        if (options.cause)
            this.cause = options.cause;
        this.details = details;
        this.docsPath = docsPath;
        this.metaMessages = options.metaMessages;
        this.shortMessage = shortMessage;
    }
    walk(fn) {
        return __classPrivateFieldGet(this, _BaseError_instances, "m", _BaseError_walk).call(this, this, fn);
    }
}
_BaseError_instances = new WeakSet(), _BaseError_walk = function _BaseError_walk(err, fn) {
    if (fn?.(err))
        return err;
    if (err.cause)
        return __classPrivateFieldGet(this, _BaseError_instances, "m", _BaseError_walk).call(this, err.cause, fn);
    return err;
};
//# sourceMappingURL=base.js.map

/***/ }),

/***/ 3500:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Cw: () => (/* binding */ ChainNotConfiguredError),
/* harmony export */   E3: () => (/* binding */ ConnectorNotConnectedError),
/* harmony export */   TT: () => (/* binding */ ConnectorAccountNotFoundError),
/* harmony export */   gB: () => (/* binding */ ConnectorAlreadyConnectedError)
/* harmony export */ });
/* unused harmony export ConnectorNotFoundError */
/* harmony import */ var _base_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(54428);


class ChainNotConfiguredError extends _base_js__WEBPACK_IMPORTED_MODULE_0__/* .BaseError */ .k {
    constructor() {
        super('Chain not configured.');
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'ChainNotConfiguredError'
        });
    }
}
class ConnectorAlreadyConnectedError extends _base_js__WEBPACK_IMPORTED_MODULE_0__/* .BaseError */ .k {
    constructor() {
        super('Connector already connected.');
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'ConnectorAlreadyConnectedError'
        });
    }
}
class ConnectorNotConnectedError extends _base_js__WEBPACK_IMPORTED_MODULE_0__/* .BaseError */ .k {
    constructor() {
        super('Connector not connected.');
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'ConnectorNotConnectedError'
        });
    }
}
class ConnectorNotFoundError extends _base_js__WEBPACK_IMPORTED_MODULE_0__/* .BaseError */ .k {
    constructor() {
        super('Connector not found.');
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'ConnectorNotFoundError'
        });
    }
}
class ConnectorAccountNotFoundError extends _base_js__WEBPACK_IMPORTED_MODULE_0__/* .BaseError */ .k {
    constructor({ address, connector, }) {
        super(`Account "${address}" not found for connector "${connector.name}".`);
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'ConnectorAccountNotFoundError'
        });
    }
}
//# sourceMappingURL=config.js.map

/***/ }),

/***/ 52668:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   I: () => (/* binding */ deepEqual)
/* harmony export */ });
/** Forked from https://github.com/epoberezkin/fast-deep-equal */
function deepEqual(a, b) {
    if (a === b)
        return true;
    if (a && b && typeof a === 'object' && typeof b === 'object') {
        if (a.constructor !== b.constructor)
            return false;
        let length;
        let i;
        if (Array.isArray(a) && Array.isArray(b)) {
            length = a.length;
            if (length !== b.length)
                return false;
            for (i = length; i-- !== 0;)
                if (!deepEqual(a[i], b[i]))
                    return false;
            return true;
        }
        if (a.valueOf !== Object.prototype.valueOf)
            return a.valueOf() === b.valueOf();
        if (a.toString !== Object.prototype.toString)
            return a.toString() === b.toString();
        const keys = Object.keys(a);
        length = keys.length;
        if (length !== Object.keys(b).length)
            return false;
        for (i = length; i-- !== 0;)
            if (!Object.prototype.hasOwnProperty.call(b, keys[i]))
                return false;
        for (i = length; i-- !== 0;) {
            const key = keys[i];
            if (key && !deepEqual(a[key], b[key]))
                return false;
        }
        return true;
    }
    // true if both NaN, false otherwise
    // biome-ignore lint/suspicious/noSelfCompare: <explanation>
    return a !== a && b !== b;
}
//# sourceMappingURL=deepEqual.js.map

/***/ }),

/***/ 280:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   W: () => (/* binding */ version)
/* harmony export */ });
const version = '2.6.3';
//# sourceMappingURL=version.js.map

/***/ }),

/***/ 81728:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   o: () => (/* binding */ parseAccount)
/* harmony export */ });
function parseAccount(account) {
    if (typeof account === 'string')
        return { address: account, type: 'json-rpc' };
    return account;
}
//# sourceMappingURL=parseAccount.js.map

/***/ }),

/***/ 37026:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  y: () => (/* binding */ mainnet)
});

;// CONCATENATED MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/utils/chain/defineChain.js
function defineChain(chain) {
    return {
        formatters: undefined,
        fees: undefined,
        serializers: undefined,
        ...chain,
    };
}
//# sourceMappingURL=defineChain.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/chains/definitions/mainnet.js

const mainnet = /*#__PURE__*/ defineChain({
    id: 1,
    name: 'Ethereum',
    nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
    rpcUrls: {
        default: {
            http: ['https://cloudflare-eth.com'],
        },
    },
    blockExplorers: {
        default: {
            name: 'Etherscan',
            url: 'https://etherscan.io',
            apiUrl: 'https://api.etherscan.io/api',
        },
    },
    contracts: {
        ensRegistry: {
            address: '0x00000000000C2E074eC69A0dFb2997BA6C7d2e1e',
        },
        ensUniversalResolver: {
            address: '0x8cab227b1162f03b8338331adaad7aadc83b895e',
            blockCreated: 18958930,
        },
        multicall3: {
            address: '0xca11bde05977b3631167028862be2a173976ca11',
            blockCreated: 14353601,
        },
    },
});
//# sourceMappingURL=mainnet.js.map

/***/ }),

/***/ 5460:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  M: () => (/* binding */ createClient)
});

// EXTERNAL MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/accounts/utils/parseAccount.js
var parseAccount = __webpack_require__(81728);
;// CONCATENATED MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/utils/uid.js
const size = 256;
let index = size;
let buffer;
function uid(length = 11) {
    if (!buffer || index + length > size * 2) {
        buffer = '';
        index = 0;
        for (let i = 0; i < size; i++) {
            buffer += ((256 + Math.random() * 256) | 0).toString(16).substring(1);
        }
    }
    return buffer.substring(index, index++ + length);
}
//# sourceMappingURL=uid.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/clients/createClient.js


function createClient(parameters) {
    const { batch, cacheTime = parameters.pollingInterval ?? 4000, key = 'base', name = 'Base Client', pollingInterval = 4000, type = 'base', } = parameters;
    const chain = parameters.chain;
    const account = parameters.account
        ? (0,parseAccount/* parseAccount */.o)(parameters.account)
        : undefined;
    const { config, request, value } = parameters.transport({
        chain,
        pollingInterval,
    });
    const transport = { ...config, ...value };
    const client = {
        account,
        batch,
        cacheTime,
        chain,
        key,
        name,
        pollingInterval,
        request,
        transport,
        type,
        uid: uid(),
    };
    function extend(base) {
        return (extendFn) => {
            const extended = extendFn(base);
            for (const key in client)
                delete extended[key];
            const combined = { ...base, ...extended };
            return Object.assign(combined, { extend: extend(combined) });
        };
    }
    return Object.assign(client, { extend: extend(client) });
}
//# sourceMappingURL=createClient.js.map

/***/ }),

/***/ 66652:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  i: () => (/* binding */ createTransport)
});

// EXTERNAL MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/errors/base.js
var base = __webpack_require__(8696);
// EXTERNAL MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/errors/request.js
var errors_request = __webpack_require__(46424);
// EXTERNAL MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/errors/rpc.js
var rpc = __webpack_require__(24652);
// EXTERNAL MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/utils/promise/withRetry.js + 1 modules
var withRetry = __webpack_require__(19744);
;// CONCATENATED MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/utils/buildRequest.js




function buildRequest(request, options = {}) {
    return async (args, overrideOptions = {}) => {
        const { retryDelay = 150, retryCount = 3 } = {
            ...options,
            ...overrideOptions,
        };
        return (0,withRetry/* withRetry */.e)(async () => {
            try {
                return await request(args);
            }
            catch (err_) {
                const err = err_;
                switch (err.code) {
                    // -32700
                    case rpc/* ParseRpcError */.KI.code:
                        throw new rpc/* ParseRpcError */.KI(err);
                    // -32600
                    case rpc/* InvalidRequestRpcError */.wV.code:
                        throw new rpc/* InvalidRequestRpcError */.wV(err);
                    // -32601
                    case rpc/* MethodNotFoundRpcError */.yb.code:
                        throw new rpc/* MethodNotFoundRpcError */.yb(err);
                    // -32602
                    case rpc/* InvalidParamsRpcError */.AX.code:
                        throw new rpc/* InvalidParamsRpcError */.AX(err);
                    // -32603
                    case rpc/* InternalRpcError */.Kk.code:
                        throw new rpc/* InternalRpcError */.Kk(err);
                    // -32000
                    case rpc/* InvalidInputRpcError */.Kl.code:
                        throw new rpc/* InvalidInputRpcError */.Kl(err);
                    // -32001
                    case rpc/* ResourceNotFoundRpcError */.KE.code:
                        throw new rpc/* ResourceNotFoundRpcError */.KE(err);
                    // -32002
                    case rpc/* ResourceUnavailableRpcError */.yW.code:
                        throw new rpc/* ResourceUnavailableRpcError */.yW(err);
                    // -32003
                    case rpc/* TransactionRejectedRpcError */.gd.code:
                        throw new rpc/* TransactionRejectedRpcError */.gd(err);
                    // -32004
                    case rpc/* MethodNotSupportedRpcError */.Uj.code:
                        throw new rpc/* MethodNotSupportedRpcError */.Uj(err);
                    // -32005
                    case rpc/* LimitExceededRpcError */.kr.code:
                        throw new rpc/* LimitExceededRpcError */.kr(err);
                    // -32006
                    case rpc/* JsonRpcVersionUnsupportedError */._g.code:
                        throw new rpc/* JsonRpcVersionUnsupportedError */._g(err);
                    // 4001
                    case rpc/* UserRejectedRequestError */.qW.code:
                        throw new rpc/* UserRejectedRequestError */.qW(err);
                    // 4100
                    case rpc/* UnauthorizedProviderError */.Ep.code:
                        throw new rpc/* UnauthorizedProviderError */.Ep(err);
                    // 4200
                    case rpc/* UnsupportedProviderMethodError */.Eh.code:
                        throw new rpc/* UnsupportedProviderMethodError */.Eh(err);
                    // 4900
                    case rpc/* ProviderDisconnectedError */.yi.code:
                        throw new rpc/* ProviderDisconnectedError */.yi(err);
                    // 4901
                    case rpc/* ChainDisconnectedError */.uq.code:
                        throw new rpc/* ChainDisconnectedError */.uq(err);
                    // 4902
                    case rpc/* SwitchChainError */.M3.code:
                        throw new rpc/* SwitchChainError */.M3(err);
                    // CAIP-25: User Rejected Error
                    // https://docs.walletconnect.com/2.0/specs/clients/sign/error-codes#rejected-caip-25
                    case 5000:
                        throw new rpc/* UserRejectedRequestError */.qW(err);
                    default:
                        if (err_ instanceof base/* BaseError */.k)
                            throw err_;
                        throw new rpc/* UnknownRpcError */.SQ(err);
                }
            }
        }, {
            delay: ({ count, error }) => {
                // If we find a Retry-After header, let's retry after the given time.
                if (error && error instanceof errors_request/* HttpRequestError */.G8) {
                    const retryAfter = error?.headers?.get('Retry-After');
                    if (retryAfter?.match(/\d/))
                        return parseInt(retryAfter) * 1000;
                }
                // Otherwise, let's retry with an exponential backoff.
                return ~~(1 << count) * retryDelay;
            },
            retryCount,
            shouldRetry: ({ error }) => shouldRetry(error),
        });
    };
}
function shouldRetry(error) {
    if ('code' in error && typeof error.code === 'number') {
        if (error.code === -1)
            return true; // Unknown error
        if (error.code === rpc/* LimitExceededRpcError */.kr.code)
            return true;
        if (error.code === rpc/* InternalRpcError */.Kk.code)
            return true;
        return false;
    }
    if (error instanceof errors_request/* HttpRequestError */.G8 && error.status) {
        // Forbidden
        if (error.status === 403)
            return true;
        // Request Timeout
        if (error.status === 408)
            return true;
        // Request Entity Too Large
        if (error.status === 413)
            return true;
        // Too Many Requests
        if (error.status === 429)
            return true;
        // Internal Server Error
        if (error.status === 500)
            return true;
        // Bad Gateway
        if (error.status === 502)
            return true;
        // Service Unavailable
        if (error.status === 503)
            return true;
        // Gateway Timeout
        if (error.status === 504)
            return true;
        return false;
    }
    return true;
}
//# sourceMappingURL=buildRequest.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/clients/transports/createTransport.js

/**
 * @description Creates an transport intended to be used with a client.
 */
function createTransport({ key, name, request, retryCount = 3, retryDelay = 150, timeout, type, }, value) {
    return {
        config: { key, name, request, retryCount, retryDelay, timeout, type },
        request: buildRequest(request, { retryCount, retryDelay }),
        value,
    };
}
//# sourceMappingURL=createTransport.js.map

/***/ }),

/***/ 45590:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  K: () => (/* binding */ http)
});

// EXTERNAL MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/errors/request.js
var request = __webpack_require__(46424);
// EXTERNAL MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/errors/base.js
var base = __webpack_require__(8696);
;// CONCATENATED MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/errors/transport.js

class UrlRequiredError extends base/* BaseError */.k {
    constructor() {
        super('No URL was provided to the Transport. Please provide a valid RPC URL to the Transport.', {
            docsPath: '/docs/clients/intro',
        });
    }
}
//# sourceMappingURL=transport.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/utils/promise/createBatchScheduler.js
const schedulerCache = /*#__PURE__*/ new Map();
function createBatchScheduler({ fn, id, shouldSplitBatch, wait = 0, sort, }) {
    const exec = async () => {
        const scheduler = getScheduler();
        flush();
        const args = scheduler.map(({ args }) => args);
        if (args.length === 0)
            return;
        fn(args)
            .then((data) => {
            if (sort && Array.isArray(data))
                data.sort(sort);
            for (let i = 0; i < scheduler.length; i++) {
                const { pendingPromise } = scheduler[i];
                pendingPromise.resolve?.([data[i], data]);
            }
        })
            .catch((err) => {
            for (let i = 0; i < scheduler.length; i++) {
                const { pendingPromise } = scheduler[i];
                pendingPromise.reject?.(err);
            }
        });
    };
    const flush = () => schedulerCache.delete(id);
    const getBatchedArgs = () => getScheduler().map(({ args }) => args);
    const getScheduler = () => schedulerCache.get(id) || [];
    const setScheduler = (item) => schedulerCache.set(id, [...getScheduler(), item]);
    return {
        flush,
        async schedule(args) {
            const pendingPromise = {};
            const promise = new Promise((resolve, reject) => {
                pendingPromise.resolve = resolve;
                pendingPromise.reject = reject;
            });
            const split = shouldSplitBatch?.([...getBatchedArgs(), args]);
            if (split)
                exec();
            const hasActiveScheduler = getScheduler().length > 0;
            if (hasActiveScheduler) {
                setScheduler({ args, pendingPromise });
                return promise;
            }
            setScheduler({ args, pendingPromise });
            setTimeout(exec, wait);
            return promise;
        },
    };
}
//# sourceMappingURL=createBatchScheduler.js.map
// EXTERNAL MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/utils/promise/withTimeout.js
var withTimeout = __webpack_require__(68088);
// EXTERNAL MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/utils/stringify.js
var stringify = __webpack_require__(83424);
;// CONCATENATED MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/utils/rpc/id.js
function createIdStore() {
    return {
        current: 0,
        take() {
            return this.current++;
        },
        reset() {
            this.current = 0;
        },
    };
}
const idCache = /*#__PURE__*/ createIdStore();
//# sourceMappingURL=id.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/utils/rpc/http.js




function getHttpRpcClient(url, options = {}) {
    return {
        async request(params) {
            const { body, fetchOptions = {}, timeout = options.timeout ?? 10000, } = params;
            const { headers, method, signal: signal_, } = { ...options.fetchOptions, ...fetchOptions };
            try {
                const response = await (0,withTimeout/* withTimeout */.i)(async ({ signal }) => {
                    const response = await fetch(url, {
                        ...fetchOptions,
                        body: Array.isArray(body)
                            ? (0,stringify/* stringify */.i)(body.map((body) => ({
                                jsonrpc: '2.0',
                                id: body.id ?? idCache.take(),
                                ...body,
                            })))
                            : (0,stringify/* stringify */.i)({
                                jsonrpc: '2.0',
                                id: body.id ?? idCache.take(),
                                ...body,
                            }),
                        headers: {
                            ...headers,
                            'Content-Type': 'application/json',
                        },
                        method: method || 'POST',
                        signal: signal_ || (timeout > 0 ? signal : undefined),
                    });
                    return response;
                }, {
                    errorInstance: new request/* TimeoutError */.ol({ body, url }),
                    timeout,
                    signal: true,
                });
                let data;
                if (response.headers.get('Content-Type')?.startsWith('application/json')) {
                    data = await response.json();
                }
                else {
                    data = await response.text();
                }
                if (!response.ok) {
                    throw new request/* HttpRequestError */.G8({
                        body,
                        details: (0,stringify/* stringify */.i)(data.error) || response.statusText,
                        headers: response.headers,
                        status: response.status,
                        url,
                    });
                }
                return data;
            }
            catch (err) {
                if (err instanceof request/* HttpRequestError */.G8)
                    throw err;
                if (err instanceof request/* TimeoutError */.ol)
                    throw err;
                throw new request/* HttpRequestError */.G8({
                    body,
                    details: err.message,
                    url,
                });
            }
        },
    };
}
//# sourceMappingURL=http.js.map
// EXTERNAL MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/clients/transports/createTransport.js + 1 modules
var createTransport = __webpack_require__(66652);
;// CONCATENATED MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/clients/transports/http.js





/**
 * @description Creates a HTTP transport that connects to a JSON-RPC API.
 */
function http(
/** URL of the JSON-RPC API. Defaults to the chain's public RPC URL. */
url, config = {}) {
    const { batch, fetchOptions, key = 'http', name = 'HTTP JSON-RPC', retryDelay, } = config;
    return ({ chain, retryCount: retryCount_, timeout: timeout_ }) => {
        const { batchSize = 1000, wait = 0 } = typeof batch === 'object' ? batch : {};
        const retryCount = config.retryCount ?? retryCount_;
        const timeout = timeout_ ?? config.timeout ?? 10000;
        const url_ = url || chain?.rpcUrls.default.http[0];
        if (!url_)
            throw new UrlRequiredError();
        const rpcClient = getHttpRpcClient(url_, { fetchOptions, timeout });
        return (0,createTransport/* createTransport */.i)({
            key,
            name,
            async request({ method, params }) {
                const body = { method, params };
                const { schedule } = createBatchScheduler({
                    id: `${url}`,
                    wait,
                    shouldSplitBatch(requests) {
                        return requests.length > batchSize;
                    },
                    fn: (body) => rpcClient.request({
                        body,
                    }),
                    sort: (a, b) => a.id - b.id,
                });
                const fn = async (body) => batch
                    ? schedule(body)
                    : [
                        await rpcClient.request({
                            body,
                        }),
                    ];
                const [{ error, result }] = await fn(body);
                if (error)
                    throw new request/* RpcRequestError */.YP({
                        body,
                        error,
                        url: url_,
                    });
                return result;
            },
            retryCount,
            retryDelay,
            timeout,
            type: 'http',
        }, {
            fetchOptions,
            url: url_,
        });
    };
}
//# sourceMappingURL=http.js.map

/***/ }),

/***/ 8696:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   k: () => (/* binding */ BaseError)
/* harmony export */ });
/* harmony import */ var _utils_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2384);

class BaseError extends Error {
    constructor(shortMessage, args = {}) {
        super();
        Object.defineProperty(this, "details", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "docsPath", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "metaMessages", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "shortMessage", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'ViemError'
        });
        Object.defineProperty(this, "version", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: (0,_utils_js__WEBPACK_IMPORTED_MODULE_0__/* .getVersion */ .ct)()
        });
        const details = args.cause instanceof BaseError
            ? args.cause.details
            : args.cause?.message
                ? args.cause.message
                : args.details;
        const docsPath = args.cause instanceof BaseError
            ? args.cause.docsPath || args.docsPath
            : args.docsPath;
        this.message = [
            shortMessage || 'An error occurred.',
            '',
            ...(args.metaMessages ? [...args.metaMessages, ''] : []),
            ...(docsPath
                ? [
                    `Docs: https://viem.sh${docsPath}${args.docsSlug ? `#${args.docsSlug}` : ''}`,
                ]
                : []),
            ...(details ? [`Details: ${details}`] : []),
            `Version: ${this.version}`,
        ].join('\n');
        if (args.cause)
            this.cause = args.cause;
        this.details = details;
        this.docsPath = docsPath;
        this.metaMessages = args.metaMessages;
        this.shortMessage = shortMessage;
    }
    walk(fn) {
        return walk(this, fn);
    }
}
function walk(err, fn) {
    if (fn?.(err))
        return err;
    if (err && typeof err === 'object' && 'cause' in err)
        return walk(err.cause, fn);
    return fn ? null : err;
}
//# sourceMappingURL=base.js.map

/***/ }),

/***/ 6468:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   E9: () => (/* binding */ SizeOverflowError),
/* harmony export */   cI: () => (/* binding */ IntegerOutOfRangeError)
/* harmony export */ });
/* unused harmony exports InvalidBytesBooleanError, InvalidHexBooleanError, InvalidHexValueError */
/* harmony import */ var _base_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8696);

class IntegerOutOfRangeError extends _base_js__WEBPACK_IMPORTED_MODULE_0__/* .BaseError */ .k {
    constructor({ max, min, signed, size, value, }) {
        super(`Number "${value}" is not in safe ${size ? `${size * 8}-bit ${signed ? 'signed' : 'unsigned'} ` : ''}integer range ${max ? `(${min} to ${max})` : `(above ${min})`}`);
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'IntegerOutOfRangeError'
        });
    }
}
class InvalidBytesBooleanError extends _base_js__WEBPACK_IMPORTED_MODULE_0__/* .BaseError */ .k {
    constructor(bytes) {
        super(`Bytes value "${bytes}" is not a valid boolean. The bytes array must contain a single byte of either a 0 or 1 value.`);
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'InvalidBytesBooleanError'
        });
    }
}
class InvalidHexBooleanError extends _base_js__WEBPACK_IMPORTED_MODULE_0__/* .BaseError */ .k {
    constructor(hex) {
        super(`Hex value "${hex}" is not a valid boolean. The hex value must be "0x0" (false) or "0x1" (true).`);
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'InvalidHexBooleanError'
        });
    }
}
class InvalidHexValueError extends _base_js__WEBPACK_IMPORTED_MODULE_0__/* .BaseError */ .k {
    constructor(value) {
        super(`Hex value "${value}" is an odd length (${value.length}). It must be an even length.`);
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'InvalidHexValueError'
        });
    }
}
class SizeOverflowError extends _base_js__WEBPACK_IMPORTED_MODULE_0__/* .BaseError */ .k {
    constructor({ givenSize, maxSize }) {
        super(`Size cannot exceed ${maxSize} bytes. Given size: ${givenSize} bytes.`);
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'SizeOverflowError'
        });
    }
}
//# sourceMappingURL=encoding.js.map

/***/ }),

/***/ 46424:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   G8: () => (/* binding */ HttpRequestError),
/* harmony export */   YP: () => (/* binding */ RpcRequestError),
/* harmony export */   ol: () => (/* binding */ TimeoutError)
/* harmony export */ });
/* unused harmony export WebSocketRequestError */
/* harmony import */ var _utils_stringify_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(83424);
/* harmony import */ var _base_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8696);
/* harmony import */ var _utils_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2384);



class HttpRequestError extends _base_js__WEBPACK_IMPORTED_MODULE_0__/* .BaseError */ .k {
    constructor({ body, details, headers, status, url, }) {
        super('HTTP request failed.', {
            details,
            metaMessages: [
                status && `Status: ${status}`,
                `URL: ${(0,_utils_js__WEBPACK_IMPORTED_MODULE_1__/* .getUrl */ .YV)(url)}`,
                body && `Request body: ${(0,_utils_stringify_js__WEBPACK_IMPORTED_MODULE_2__/* .stringify */ .i)(body)}`,
            ].filter(Boolean),
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'HttpRequestError'
        });
        Object.defineProperty(this, "body", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "headers", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "status", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "url", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.body = body;
        this.headers = headers;
        this.status = status;
        this.url = url;
    }
}
class WebSocketRequestError extends _base_js__WEBPACK_IMPORTED_MODULE_0__/* .BaseError */ .k {
    constructor({ body, details, url, }) {
        super('WebSocket request failed.', {
            details,
            metaMessages: [`URL: ${(0,_utils_js__WEBPACK_IMPORTED_MODULE_1__/* .getUrl */ .YV)(url)}`, `Request body: ${(0,_utils_stringify_js__WEBPACK_IMPORTED_MODULE_2__/* .stringify */ .i)(body)}`],
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'WebSocketRequestError'
        });
    }
}
class RpcRequestError extends _base_js__WEBPACK_IMPORTED_MODULE_0__/* .BaseError */ .k {
    constructor({ body, error, url, }) {
        super('RPC Request failed.', {
            cause: error,
            details: error.message,
            metaMessages: [`URL: ${(0,_utils_js__WEBPACK_IMPORTED_MODULE_1__/* .getUrl */ .YV)(url)}`, `Request body: ${(0,_utils_stringify_js__WEBPACK_IMPORTED_MODULE_2__/* .stringify */ .i)(body)}`],
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'RpcRequestError'
        });
        Object.defineProperty(this, "code", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.code = error.code;
    }
}
class TimeoutError extends _base_js__WEBPACK_IMPORTED_MODULE_0__/* .BaseError */ .k {
    constructor({ body, url, }) {
        super('The request took too long to respond.', {
            details: 'The request timed out.',
            metaMessages: [`URL: ${(0,_utils_js__WEBPACK_IMPORTED_MODULE_1__/* .getUrl */ .YV)(url)}`, `Request body: ${(0,_utils_stringify_js__WEBPACK_IMPORTED_MODULE_2__/* .stringify */ .i)(body)}`],
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'TimeoutError'
        });
    }
}
//# sourceMappingURL=request.js.map

/***/ }),

/***/ 24652:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AX: () => (/* binding */ InvalidParamsRpcError),
/* harmony export */   Eh: () => (/* binding */ UnsupportedProviderMethodError),
/* harmony export */   Ep: () => (/* binding */ UnauthorizedProviderError),
/* harmony export */   KE: () => (/* binding */ ResourceNotFoundRpcError),
/* harmony export */   KI: () => (/* binding */ ParseRpcError),
/* harmony export */   Kk: () => (/* binding */ InternalRpcError),
/* harmony export */   Kl: () => (/* binding */ InvalidInputRpcError),
/* harmony export */   M3: () => (/* binding */ SwitchChainError),
/* harmony export */   SQ: () => (/* binding */ UnknownRpcError),
/* harmony export */   Uj: () => (/* binding */ MethodNotSupportedRpcError),
/* harmony export */   _g: () => (/* binding */ JsonRpcVersionUnsupportedError),
/* harmony export */   gd: () => (/* binding */ TransactionRejectedRpcError),
/* harmony export */   kr: () => (/* binding */ LimitExceededRpcError),
/* harmony export */   qW: () => (/* binding */ UserRejectedRequestError),
/* harmony export */   uq: () => (/* binding */ ChainDisconnectedError),
/* harmony export */   wV: () => (/* binding */ InvalidRequestRpcError),
/* harmony export */   yW: () => (/* binding */ ResourceUnavailableRpcError),
/* harmony export */   yb: () => (/* binding */ MethodNotFoundRpcError),
/* harmony export */   yi: () => (/* binding */ ProviderDisconnectedError)
/* harmony export */ });
/* unused harmony exports RpcError, ProviderRpcError */
/* harmony import */ var _base_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8696);
/* harmony import */ var _request_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(46424);


const unknownErrorCode = -1;
class RpcError extends _base_js__WEBPACK_IMPORTED_MODULE_0__/* .BaseError */ .k {
    constructor(cause, { code, docsPath, metaMessages, shortMessage }) {
        super(shortMessage, {
            cause,
            docsPath,
            metaMessages: metaMessages || cause?.metaMessages,
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'RpcError'
        });
        Object.defineProperty(this, "code", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.name = cause.name;
        this.code = (cause instanceof _request_js__WEBPACK_IMPORTED_MODULE_1__/* .RpcRequestError */ .YP ? cause.code : code ?? unknownErrorCode);
    }
}
class ProviderRpcError extends RpcError {
    constructor(cause, options) {
        super(cause, options);
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'ProviderRpcError'
        });
        Object.defineProperty(this, "data", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.data = options.data;
    }
}
class ParseRpcError extends RpcError {
    constructor(cause) {
        super(cause, {
            code: ParseRpcError.code,
            shortMessage: 'Invalid JSON was received by the server. An error occurred on the server while parsing the JSON text.',
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'ParseRpcError'
        });
    }
}
Object.defineProperty(ParseRpcError, "code", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: -32700
});
class InvalidRequestRpcError extends RpcError {
    constructor(cause) {
        super(cause, {
            code: InvalidRequestRpcError.code,
            shortMessage: 'JSON is not a valid request object.',
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'InvalidRequestRpcError'
        });
    }
}
Object.defineProperty(InvalidRequestRpcError, "code", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: -32600
});
class MethodNotFoundRpcError extends RpcError {
    constructor(cause) {
        super(cause, {
            code: MethodNotFoundRpcError.code,
            shortMessage: 'The method does not exist / is not available.',
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'MethodNotFoundRpcError'
        });
    }
}
Object.defineProperty(MethodNotFoundRpcError, "code", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: -32601
});
class InvalidParamsRpcError extends RpcError {
    constructor(cause) {
        super(cause, {
            code: InvalidParamsRpcError.code,
            shortMessage: [
                'Invalid parameters were provided to the RPC method.',
                'Double check you have provided the correct parameters.',
            ].join('\n'),
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'InvalidParamsRpcError'
        });
    }
}
Object.defineProperty(InvalidParamsRpcError, "code", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: -32602
});
class InternalRpcError extends RpcError {
    constructor(cause) {
        super(cause, {
            code: InternalRpcError.code,
            shortMessage: 'An internal error was received.',
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'InternalRpcError'
        });
    }
}
Object.defineProperty(InternalRpcError, "code", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: -32603
});
class InvalidInputRpcError extends RpcError {
    constructor(cause) {
        super(cause, {
            code: InvalidInputRpcError.code,
            shortMessage: [
                'Missing or invalid parameters.',
                'Double check you have provided the correct parameters.',
            ].join('\n'),
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'InvalidInputRpcError'
        });
    }
}
Object.defineProperty(InvalidInputRpcError, "code", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: -32000
});
class ResourceNotFoundRpcError extends RpcError {
    constructor(cause) {
        super(cause, {
            code: ResourceNotFoundRpcError.code,
            shortMessage: 'Requested resource not found.',
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'ResourceNotFoundRpcError'
        });
    }
}
Object.defineProperty(ResourceNotFoundRpcError, "code", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: -32001
});
class ResourceUnavailableRpcError extends RpcError {
    constructor(cause) {
        super(cause, {
            code: ResourceUnavailableRpcError.code,
            shortMessage: 'Requested resource not available.',
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'ResourceUnavailableRpcError'
        });
    }
}
Object.defineProperty(ResourceUnavailableRpcError, "code", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: -32002
});
class TransactionRejectedRpcError extends RpcError {
    constructor(cause) {
        super(cause, {
            code: TransactionRejectedRpcError.code,
            shortMessage: 'Transaction creation failed.',
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'TransactionRejectedRpcError'
        });
    }
}
Object.defineProperty(TransactionRejectedRpcError, "code", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: -32003
});
class MethodNotSupportedRpcError extends RpcError {
    constructor(cause) {
        super(cause, {
            code: MethodNotSupportedRpcError.code,
            shortMessage: 'Method is not implemented.',
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'MethodNotSupportedRpcError'
        });
    }
}
Object.defineProperty(MethodNotSupportedRpcError, "code", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: -32004
});
class LimitExceededRpcError extends RpcError {
    constructor(cause) {
        super(cause, {
            code: LimitExceededRpcError.code,
            shortMessage: 'Request exceeds defined limit.',
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'LimitExceededRpcError'
        });
    }
}
Object.defineProperty(LimitExceededRpcError, "code", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: -32005
});
class JsonRpcVersionUnsupportedError extends RpcError {
    constructor(cause) {
        super(cause, {
            code: JsonRpcVersionUnsupportedError.code,
            shortMessage: 'Version of JSON-RPC protocol is not supported.',
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'JsonRpcVersionUnsupportedError'
        });
    }
}
Object.defineProperty(JsonRpcVersionUnsupportedError, "code", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: -32006
});
class UserRejectedRequestError extends ProviderRpcError {
    constructor(cause) {
        super(cause, {
            code: UserRejectedRequestError.code,
            shortMessage: 'User rejected the request.',
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'UserRejectedRequestError'
        });
    }
}
Object.defineProperty(UserRejectedRequestError, "code", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: 4001
});
class UnauthorizedProviderError extends ProviderRpcError {
    constructor(cause) {
        super(cause, {
            code: UnauthorizedProviderError.code,
            shortMessage: 'The requested method and/or account has not been authorized by the user.',
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'UnauthorizedProviderError'
        });
    }
}
Object.defineProperty(UnauthorizedProviderError, "code", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: 4100
});
class UnsupportedProviderMethodError extends ProviderRpcError {
    constructor(cause) {
        super(cause, {
            code: UnsupportedProviderMethodError.code,
            shortMessage: 'The Provider does not support the requested method.',
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'UnsupportedProviderMethodError'
        });
    }
}
Object.defineProperty(UnsupportedProviderMethodError, "code", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: 4200
});
class ProviderDisconnectedError extends ProviderRpcError {
    constructor(cause) {
        super(cause, {
            code: ProviderDisconnectedError.code,
            shortMessage: 'The Provider is disconnected from all chains.',
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'ProviderDisconnectedError'
        });
    }
}
Object.defineProperty(ProviderDisconnectedError, "code", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: 4900
});
class ChainDisconnectedError extends ProviderRpcError {
    constructor(cause) {
        super(cause, {
            code: ChainDisconnectedError.code,
            shortMessage: 'The Provider is not connected to the requested chain.',
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'ChainDisconnectedError'
        });
    }
}
Object.defineProperty(ChainDisconnectedError, "code", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: 4901
});
class SwitchChainError extends ProviderRpcError {
    constructor(cause) {
        super(cause, {
            code: SwitchChainError.code,
            shortMessage: 'An error occurred when attempting to switch chain.',
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'SwitchChainError'
        });
    }
}
Object.defineProperty(SwitchChainError, "code", {
    enumerable: true,
    configurable: true,
    writable: true,
    value: 4902
});
class UnknownRpcError extends RpcError {
    constructor(cause) {
        super(cause, {
            shortMessage: 'An unknown RPC error occurred.',
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'UnknownRpcError'
        });
    }
}
//# sourceMappingURL=rpc.js.map

/***/ }),

/***/ 2384:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  YV: () => (/* binding */ getUrl),
  ct: () => (/* binding */ getVersion)
});

// UNUSED EXPORTS: getContractAddress

;// CONCATENATED MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/errors/version.js
const version = '2.7.6';
//# sourceMappingURL=version.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/errors/utils.js

const getContractAddress = (address) => address;
const getUrl = (url) => url;
const getVersion = () => `viem@${version}`;
//# sourceMappingURL=utils.js.map

/***/ }),

/***/ 34984:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ isHex)
/* harmony export */ });
function isHex(value, { strict = true } = {}) {
    if (!value)
        return false;
    if (typeof value !== 'string')
        return false;
    return strict ? /^0x[0-9a-fA-F]*$/.test(value) : value.startsWith('0x');
}
//# sourceMappingURL=isHex.js.map

/***/ }),

/***/ 34762:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  eu: () => (/* binding */ pad)
});

// UNUSED EXPORTS: padBytes, padHex

// EXTERNAL MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/errors/base.js
var base = __webpack_require__(8696);
;// CONCATENATED MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/errors/data.js

class SliceOffsetOutOfBoundsError extends base/* BaseError */.k {
    constructor({ offset, position, size, }) {
        super(`Slice ${position === 'start' ? 'starting' : 'ending'} at offset "${offset}" is out-of-bounds (size: ${size}).`);
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'SliceOffsetOutOfBoundsError'
        });
    }
}
class SizeExceedsPaddingSizeError extends base/* BaseError */.k {
    constructor({ size, targetSize, type, }) {
        super(`${type.charAt(0).toUpperCase()}${type
            .slice(1)
            .toLowerCase()} size (${size}) exceeds padding size (${targetSize}).`);
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'SizeExceedsPaddingSizeError'
        });
    }
}
class InvalidBytesLengthError extends base/* BaseError */.k {
    constructor({ size, targetSize, type, }) {
        super(`${type.charAt(0).toUpperCase()}${type
            .slice(1)
            .toLowerCase()} is expected to be ${targetSize} ${type} long, but is ${size} ${type} long.`);
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'InvalidBytesLengthError'
        });
    }
}
//# sourceMappingURL=data.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/utils/data/pad.js

function pad(hexOrBytes, { dir, size = 32 } = {}) {
    if (typeof hexOrBytes === 'string')
        return padHex(hexOrBytes, { dir, size });
    return padBytes(hexOrBytes, { dir, size });
}
function padHex(hex_, { dir, size = 32 } = {}) {
    if (size === null)
        return hex_;
    const hex = hex_.replace('0x', '');
    if (hex.length > size * 2)
        throw new SizeExceedsPaddingSizeError({
            size: Math.ceil(hex.length / 2),
            targetSize: size,
            type: 'hex',
        });
    return `0x${hex[dir === 'right' ? 'padEnd' : 'padStart'](size * 2, '0')}`;
}
function padBytes(bytes, { dir, size = 32 } = {}) {
    if (size === null)
        return bytes;
    if (bytes.length > size)
        throw new SizeExceedsPaddingSizeError({
            size: bytes.length,
            targetSize: size,
            type: 'bytes',
        });
    const paddedBytes = new Uint8Array(size);
    for (let i = 0; i < size; i++) {
        const padEnd = dir === 'right';
        paddedBytes[padEnd ? i : size - i - 1] =
            bytes[padEnd ? i : bytes.length - i - 1];
    }
    return paddedBytes;
}
//# sourceMappingURL=pad.js.map

/***/ }),

/***/ 5888:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  OO: () => (/* binding */ assertSize)
});

// UNUSED EXPORTS: fromHex, hexToBigInt, hexToBool, hexToNumber, hexToString

// EXTERNAL MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/errors/encoding.js
var encoding = __webpack_require__(6468);
// EXTERNAL MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/utils/data/isHex.js
var isHex = __webpack_require__(34984);
;// CONCATENATED MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/utils/data/size.js

/**
 * @description Retrieves the size of the value (in bytes).
 *
 * @param value The value (hex or byte array) to retrieve the size of.
 * @returns The size of the value (in bytes).
 */
function size_size(value) {
    if ((0,isHex/* isHex */.a)(value, { strict: false }))
        return Math.ceil((value.length - 2) / 2);
    return value.length;
}
//# sourceMappingURL=size.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/utils/encoding/fromHex.js




function assertSize(hexOrBytes, { size }) {
    if (size_size(hexOrBytes) > size)
        throw new encoding/* SizeOverflowError */.E9({
            givenSize: size_size(hexOrBytes),
            maxSize: size,
        });
}
/**
 * Decodes a hex string into a string, number, bigint, boolean, or byte array.
 *
 * - Docs: https://viem.sh/docs/utilities/fromHex
 * - Example: https://viem.sh/docs/utilities/fromHex#usage
 *
 * @param hex Hex string to decode.
 * @param toOrOpts Type to convert to or options.
 * @returns Decoded value.
 *
 * @example
 * import { fromHex } from 'viem'
 * const data = fromHex('0x1a4', 'number')
 * // 420
 *
 * @example
 * import { fromHex } from 'viem'
 * const data = fromHex('0x48656c6c6f20576f726c6421', 'string')
 * // 'Hello world'
 *
 * @example
 * import { fromHex } from 'viem'
 * const data = fromHex('0x48656c6c6f20576f726c64210000000000000000000000000000000000000000', {
 *   size: 32,
 *   to: 'string'
 * })
 * // 'Hello world'
 */
function fromHex(hex, toOrOpts) {
    const opts = typeof toOrOpts === 'string' ? { to: toOrOpts } : toOrOpts;
    const to = opts.to;
    if (to === 'number')
        return hexToNumber(hex, opts);
    if (to === 'bigint')
        return hexToBigInt(hex, opts);
    if (to === 'string')
        return hexToString(hex, opts);
    if (to === 'boolean')
        return hexToBool(hex, opts);
    return hexToBytes(hex, opts);
}
/**
 * Decodes a hex value into a bigint.
 *
 * - Docs: https://viem.sh/docs/utilities/fromHex#hextobigint
 *
 * @param hex Hex value to decode.
 * @param opts Options.
 * @returns BigInt value.
 *
 * @example
 * import { hexToBigInt } from 'viem'
 * const data = hexToBigInt('0x1a4', { signed: true })
 * // 420n
 *
 * @example
 * import { hexToBigInt } from 'viem'
 * const data = hexToBigInt('0x00000000000000000000000000000000000000000000000000000000000001a4', { size: 32 })
 * // 420n
 */
function hexToBigInt(hex, opts = {}) {
    const { signed } = opts;
    if (opts.size)
        assertSize(hex, { size: opts.size });
    const value = BigInt(hex);
    if (!signed)
        return value;
    const size = (hex.length - 2) / 2;
    const max = (1n << (BigInt(size) * 8n - 1n)) - 1n;
    if (value <= max)
        return value;
    return value - BigInt(`0x${'f'.padStart(size * 2, 'f')}`) - 1n;
}
/**
 * Decodes a hex value into a boolean.
 *
 * - Docs: https://viem.sh/docs/utilities/fromHex#hextobool
 *
 * @param hex Hex value to decode.
 * @param opts Options.
 * @returns Boolean value.
 *
 * @example
 * import { hexToBool } from 'viem'
 * const data = hexToBool('0x01')
 * // true
 *
 * @example
 * import { hexToBool } from 'viem'
 * const data = hexToBool('0x0000000000000000000000000000000000000000000000000000000000000001', { size: 32 })
 * // true
 */
function hexToBool(hex_, opts = {}) {
    let hex = hex_;
    if (opts.size) {
        assertSize(hex, { size: opts.size });
        hex = trim(hex);
    }
    if (trim(hex) === '0x00')
        return false;
    if (trim(hex) === '0x01')
        return true;
    throw new InvalidHexBooleanError(hex);
}
/**
 * Decodes a hex string into a number.
 *
 * - Docs: https://viem.sh/docs/utilities/fromHex#hextonumber
 *
 * @param hex Hex value to decode.
 * @param opts Options.
 * @returns Number value.
 *
 * @example
 * import { hexToNumber } from 'viem'
 * const data = hexToNumber('0x1a4')
 * // 420
 *
 * @example
 * import { hexToNumber } from 'viem'
 * const data = hexToBigInt('0x00000000000000000000000000000000000000000000000000000000000001a4', { size: 32 })
 * // 420
 */
function hexToNumber(hex, opts = {}) {
    return Number(hexToBigInt(hex, opts));
}
/**
 * Decodes a hex value into a UTF-8 string.
 *
 * - Docs: https://viem.sh/docs/utilities/fromHex#hextostring
 *
 * @param hex Hex value to decode.
 * @param opts Options.
 * @returns String value.
 *
 * @example
 * import { hexToString } from 'viem'
 * const data = hexToString('0x48656c6c6f20576f726c6421')
 * // 'Hello world!'
 *
 * @example
 * import { hexToString } from 'viem'
 * const data = hexToString('0x48656c6c6f20576f726c64210000000000000000000000000000000000000000', {
 *  size: 32,
 * })
 * // 'Hello world'
 */
function hexToString(hex, opts = {}) {
    let bytes = hexToBytes(hex);
    if (opts.size) {
        assertSize(bytes, { size: opts.size });
        bytes = trim(bytes, { dir: 'right' });
    }
    return new TextDecoder().decode(bytes);
}
//# sourceMappingURL=fromHex.js.map

/***/ }),

/***/ 71220:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Sm: () => (/* binding */ toHex),
/* harmony export */   c1: () => (/* binding */ numberToHex),
/* harmony export */   mi: () => (/* binding */ stringToHex)
/* harmony export */ });
/* unused harmony exports boolToHex, bytesToHex */
/* harmony import */ var _errors_encoding_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6468);
/* harmony import */ var _data_pad_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(34762);
/* harmony import */ var _fromHex_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5888);



const hexes = /*#__PURE__*/ Array.from({ length: 256 }, (_v, i) => i.toString(16).padStart(2, '0'));
/**
 * Encodes a string, number, bigint, or ByteArray into a hex string
 *
 * - Docs: https://viem.sh/docs/utilities/toHex
 * - Example: https://viem.sh/docs/utilities/toHex#usage
 *
 * @param value Value to encode.
 * @param opts Options.
 * @returns Hex value.
 *
 * @example
 * import { toHex } from 'viem'
 * const data = toHex('Hello world')
 * // '0x48656c6c6f20776f726c6421'
 *
 * @example
 * import { toHex } from 'viem'
 * const data = toHex(420)
 * // '0x1a4'
 *
 * @example
 * import { toHex } from 'viem'
 * const data = toHex('Hello world', { size: 32 })
 * // '0x48656c6c6f20776f726c64210000000000000000000000000000000000000000'
 */
function toHex(value, opts = {}) {
    if (typeof value === 'number' || typeof value === 'bigint')
        return numberToHex(value, opts);
    if (typeof value === 'string') {
        return stringToHex(value, opts);
    }
    if (typeof value === 'boolean')
        return boolToHex(value, opts);
    return bytesToHex(value, opts);
}
/**
 * Encodes a boolean into a hex string
 *
 * - Docs: https://viem.sh/docs/utilities/toHex#booltohex
 *
 * @param value Value to encode.
 * @param opts Options.
 * @returns Hex value.
 *
 * @example
 * import { boolToHex } from 'viem'
 * const data = boolToHex(true)
 * // '0x1'
 *
 * @example
 * import { boolToHex } from 'viem'
 * const data = boolToHex(false)
 * // '0x0'
 *
 * @example
 * import { boolToHex } from 'viem'
 * const data = boolToHex(true, { size: 32 })
 * // '0x0000000000000000000000000000000000000000000000000000000000000001'
 */
function boolToHex(value, opts = {}) {
    const hex = `0x${Number(value)}`;
    if (typeof opts.size === 'number') {
        (0,_fromHex_js__WEBPACK_IMPORTED_MODULE_0__/* .assertSize */ .OO)(hex, { size: opts.size });
        return (0,_data_pad_js__WEBPACK_IMPORTED_MODULE_1__/* .pad */ .eu)(hex, { size: opts.size });
    }
    return hex;
}
/**
 * Encodes a bytes array into a hex string
 *
 * - Docs: https://viem.sh/docs/utilities/toHex#bytestohex
 *
 * @param value Value to encode.
 * @param opts Options.
 * @returns Hex value.
 *
 * @example
 * import { bytesToHex } from 'viem'
 * const data = bytesToHex(Uint8Array.from([72, 101, 108, 108, 111, 32, 87, 111, 114, 108, 100, 33])
 * // '0x48656c6c6f20576f726c6421'
 *
 * @example
 * import { bytesToHex } from 'viem'
 * const data = bytesToHex(Uint8Array.from([72, 101, 108, 108, 111, 32, 87, 111, 114, 108, 100, 33]), { size: 32 })
 * // '0x48656c6c6f20576f726c64210000000000000000000000000000000000000000'
 */
function bytesToHex(value, opts = {}) {
    let string = '';
    for (let i = 0; i < value.length; i++) {
        string += hexes[value[i]];
    }
    const hex = `0x${string}`;
    if (typeof opts.size === 'number') {
        (0,_fromHex_js__WEBPACK_IMPORTED_MODULE_0__/* .assertSize */ .OO)(hex, { size: opts.size });
        return (0,_data_pad_js__WEBPACK_IMPORTED_MODULE_1__/* .pad */ .eu)(hex, { dir: 'right', size: opts.size });
    }
    return hex;
}
/**
 * Encodes a number or bigint into a hex string
 *
 * - Docs: https://viem.sh/docs/utilities/toHex#numbertohex
 *
 * @param value Value to encode.
 * @param opts Options.
 * @returns Hex value.
 *
 * @example
 * import { numberToHex } from 'viem'
 * const data = numberToHex(420)
 * // '0x1a4'
 *
 * @example
 * import { numberToHex } from 'viem'
 * const data = numberToHex(420, { size: 32 })
 * // '0x00000000000000000000000000000000000000000000000000000000000001a4'
 */
function numberToHex(value_, opts = {}) {
    const { signed, size } = opts;
    const value = BigInt(value_);
    let maxValue;
    if (size) {
        if (signed)
            maxValue = (1n << (BigInt(size) * 8n - 1n)) - 1n;
        else
            maxValue = 2n ** (BigInt(size) * 8n) - 1n;
    }
    else if (typeof value_ === 'number') {
        maxValue = BigInt(Number.MAX_SAFE_INTEGER);
    }
    const minValue = typeof maxValue === 'bigint' && signed ? -maxValue - 1n : 0;
    if ((maxValue && value > maxValue) || value < minValue) {
        const suffix = typeof value_ === 'bigint' ? 'n' : '';
        throw new _errors_encoding_js__WEBPACK_IMPORTED_MODULE_2__/* .IntegerOutOfRangeError */ .cI({
            max: maxValue ? `${maxValue}${suffix}` : undefined,
            min: `${minValue}${suffix}`,
            signed,
            size,
            value: `${value_}${suffix}`,
        });
    }
    const hex = `0x${(signed && value < 0
        ? (1n << BigInt(size * 8)) + BigInt(value)
        : value).toString(16)}`;
    if (size)
        return (0,_data_pad_js__WEBPACK_IMPORTED_MODULE_1__/* .pad */ .eu)(hex, { size });
    return hex;
}
const encoder = /*#__PURE__*/ new TextEncoder();
/**
 * Encodes a UTF-8 string into a hex string
 *
 * - Docs: https://viem.sh/docs/utilities/toHex#stringtohex
 *
 * @param value Value to encode.
 * @param opts Options.
 * @returns Hex value.
 *
 * @example
 * import { stringToHex } from 'viem'
 * const data = stringToHex('Hello World!')
 * // '0x48656c6c6f20576f726c6421'
 *
 * @example
 * import { stringToHex } from 'viem'
 * const data = stringToHex('Hello World!', { size: 32 })
 * // '0x48656c6c6f20576f726c64210000000000000000000000000000000000000000'
 */
function stringToHex(value_, opts = {}) {
    const value = encoder.encode(value_);
    return bytesToHex(value, opts);
}
//# sourceMappingURL=toHex.js.map

/***/ }),

/***/ 19744:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  e: () => (/* binding */ withRetry)
});

;// CONCATENATED MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/utils/wait.js
async function wait(time) {
    return new Promise((res) => setTimeout(res, time));
}
//# sourceMappingURL=wait.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/utils/promise/withRetry.js

function withRetry(fn, { delay: delay_ = 100, retryCount = 2, shouldRetry = () => true, } = {}) {
    return new Promise((resolve, reject) => {
        const attemptRetry = async ({ count = 0 } = {}) => {
            const retry = async ({ error }) => {
                const delay = typeof delay_ === 'function' ? delay_({ count, error }) : delay_;
                if (delay)
                    await wait(delay);
                attemptRetry({ count: count + 1 });
            };
            try {
                const data = await fn();
                resolve(data);
            }
            catch (err) {
                if (count < retryCount &&
                    (await shouldRetry({ count, error: err })))
                    return retry({ error: err });
                reject(err);
            }
        };
        attemptRetry();
    });
}
//# sourceMappingURL=withRetry.js.map

/***/ }),

/***/ 68088:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   i: () => (/* binding */ withTimeout)
/* harmony export */ });
function withTimeout(fn, { errorInstance = new Error('timed out'), timeout, signal, }) {
    return new Promise((resolve, reject) => {
        ;
        (async () => {
            let timeoutId;
            try {
                const controller = new AbortController();
                if (timeout > 0) {
                    timeoutId = setTimeout(() => {
                        if (signal) {
                            controller.abort();
                        }
                        else {
                            reject(errorInstance);
                        }
                    }, timeout);
                }
                resolve(await fn({ signal: controller?.signal }));
            }
            catch (err) {
                if (err.name === 'AbortError')
                    reject(errorInstance);
                reject(err);
            }
            finally {
                clearTimeout(timeoutId);
            }
        })();
    });
}
//# sourceMappingURL=withTimeout.js.map

/***/ }),

/***/ 83424:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   i: () => (/* binding */ stringify)
/* harmony export */ });
const stringify = (value, replacer, space) => JSON.stringify(value, (key, value_) => {
    const value = typeof value_ === 'bigint' ? value_.toString() : value_;
    return typeof replacer === 'function' ? replacer(key, value) : value;
}, space);
//# sourceMappingURL=stringify.js.map

/***/ }),

/***/ 52200:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  e: () => (/* binding */ WagmiContext),
  Q: () => (/* binding */ WagmiProvider)
});

// EXTERNAL MODULE: ./node_modules/.pnpm/react@18.2.0/node_modules/react/index.js
var react = __webpack_require__(96651);
;// CONCATENATED MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/actions/reconnect.js



let isReconnecting = false;
/** https://wagmi.sh/core/api/actions/reconnect */
async function reconnect(config, parameters = {}) {
    // If already reconnecting, do nothing
    if (isReconnecting)
        return [];
    isReconnecting = true;
    config.setState((x) => ({
        ...x,
        status: x.current ? 'reconnecting' : 'connecting',
    }));
    const connectors = [];
    if (parameters.connectors?.length) {
        for (const connector_ of parameters.connectors) {
            let connector;
            // "Register" connector if not already created
            if (typeof connector_ === 'function')
                connector = config._internal.connectors.setup(connector_);
            else
                connector = connector_;
            connectors.push(connector);
        }
    }
    else
        connectors.push(...config.connectors);
    // Try recently-used connectors first
    const recentConnectorId = await config.storage?.getItem('recentConnectorId');
    const scores = {};
    for (const [, connection] of config.state.connections) {
        scores[connection.connector.id] = 1;
    }
    if (recentConnectorId)
        scores[recentConnectorId] = 0;
    const sorted = Object.keys(scores).length > 0
        ? // .toSorted()
            [...connectors].sort((a, b) => (scores[a.id] ?? 10) - (scores[b.id] ?? 10))
        : connectors;
    // Iterate through each connector and try to connect
    let connected = false;
    const connections = [];
    const providers = [];
    for (const connector of sorted) {
        const provider_ = await connector.getProvider();
        if (!provider_)
            continue;
        // If we already have an instance of this connector's provider,
        // then we have already checked it (ie. injected connectors can
        // share the same `window.ethereum` instance, so we don't want to
        // connect to it again).
        if (providers.some((provider) => provider === provider_))
            continue;
        const isAuthorized = await connector.isAuthorized();
        if (!isAuthorized)
            continue;
        const data = await connector
            .connect({ isReconnecting: true })
            .catch(() => null);
        if (!data)
            continue;
        connector.emitter.off('connect', config._internal.events.connect);
        connector.emitter.on('change', config._internal.events.change);
        connector.emitter.on('disconnect', config._internal.events.disconnect);
        config.setState((x) => {
            const connections = new Map(connected ? x.connections : new Map()).set(connector.uid, { accounts: data.accounts, chainId: data.chainId, connector });
            return {
                ...x,
                current: connected ? x.current : connector.uid,
                connections,
            };
        });
        connections.push({
            accounts: data.accounts,
            chainId: data.chainId,
            connector,
        });
        providers.push(provider_);
        connected = true;
    }
    // If connecting didn't succeed, set to disconnected
    if (!connected)
        config.setState((x) => ({
            ...x,
            connections: new Map(),
            current: undefined,
            status: 'disconnected',
        }));
    else
        config.setState((x) => ({ ...x, status: 'connected' }));
    isReconnecting = false;
    return connections;
}
//# sourceMappingURL=reconnect.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/hydrate.js

function hydrate(config, parameters) {
    const { initialState, reconnectOnMount } = parameters;
    if (initialState)
        config.setState({
            ...initialState,
            connections: reconnectOnMount ? initialState.connections : new Map(),
            status: reconnectOnMount ? 'reconnecting' : 'disconnected',
        });
    return {
        async onMount() {
            if (config._internal.ssr) {
                await config._internal.store.persist.rehydrate();
                const mipdConnectors = config._internal.mipd
                    ?.getProviders()
                    .map(config._internal.connectors.providerDetailToConnector)
                    .map(config._internal.connectors.setup);
                config._internal.connectors.setState((connectors) => [
                    ...connectors,
                    ...(mipdConnectors ?? []),
                ]);
            }
            if (reconnectOnMount)
                reconnect(config);
            else if (config.storage)
                // Reset connections that may have been hydrated from storage.
                config.setState((x) => ({
                    ...x,
                    connections: new Map(),
                }));
        },
    };
}
//# sourceMappingURL=hydrate.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/wagmi@2.5.5_@tanstack+react-query@5.18.1_immer@10.0.4_react-dom@18.2.0_react-native@0.73.4_re_v25ef47o4x2uzzylvfiqdsf7ny/node_modules/wagmi/dist/esm/hydrate.js
'use client';


function Hydrate(parameters) {
    const { children, config, initialState, reconnectOnMount = true } = parameters;
    const { onMount } = hydrate(config, {
        initialState,
        reconnectOnMount,
    });
    // Hydrate for non-SSR
    if (!config._internal.ssr)
        onMount();
    // Hydrate for SSR
    const active = (0,react.useRef)(true);
    // biome-ignore lint/nursery/useExhaustiveDependencies:
    (0,react.useEffect)(() => {
        if (!active.current)
            return;
        if (!config._internal.ssr)
            return;
        onMount();
        return () => {
            active.current = false;
        };
    }, []);
    return children;
}
//# sourceMappingURL=hydrate.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/wagmi@2.5.5_@tanstack+react-query@5.18.1_immer@10.0.4_react-dom@18.2.0_react-native@0.73.4_re_v25ef47o4x2uzzylvfiqdsf7ny/node_modules/wagmi/dist/esm/context.js
'use client';



const WagmiContext = (0,react.createContext)(undefined);
function WagmiProvider(parameters) {
    const { children, config } = parameters;
    const props = { value: config };
    return (0,react.createElement)(Hydrate, parameters, (0,react.createElement)(WagmiContext.Provider, props, children));
}
//# sourceMappingURL=context.js.map

/***/ }),

/***/ 79576:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  g: () => (/* binding */ useAccount)
});

// EXTERNAL MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/utils/deepEqual.js
var deepEqual = __webpack_require__(52668);
;// CONCATENATED MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/actions/getAccount.js


/** https://wagmi.sh/core/api/actions/getAccount */
function getAccount(config) {
    const uid = config.state.current;
    const connection = config.state.connections.get(uid);
    const addresses = connection?.accounts;
    const address = addresses?.[0];
    const chain = config.chains.find((chain) => chain.id === connection?.chainId);
    const status = config.state.status;
    switch (status) {
        case 'connected':
            return {
                address: address,
                addresses: addresses,
                chain,
                chainId: connection?.chainId,
                connector: connection?.connector,
                isConnected: true,
                isConnecting: false,
                isDisconnected: false,
                isReconnecting: false,
                status,
            };
        case 'reconnecting':
            return {
                address,
                addresses,
                chain,
                chainId: connection?.chainId,
                connector: connection?.connector,
                isConnected: !!address,
                isConnecting: false,
                isDisconnected: false,
                isReconnecting: true,
                status,
            };
        case 'connecting':
            return {
                address,
                addresses,
                chain,
                chainId: connection?.chainId,
                connector: connection?.connector,
                isConnected: false,
                isConnecting: true,
                isDisconnected: false,
                isReconnecting: false,
                status,
            };
        case 'disconnected':
            return {
                address: undefined,
                addresses: undefined,
                chain: undefined,
                chainId: undefined,
                connector: undefined,
                isConnected: false,
                isConnecting: false,
                isDisconnected: true,
                isReconnecting: false,
                status,
            };
    }
}
//# sourceMappingURL=getAccount.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/actions/watchAccount.js



/** https://wagmi.sh/core/api/actions/watchAccount */
function watchAccount(config, parameters) {
    const { onChange } = parameters;
    return config.subscribe(() => getAccount(config), onChange, {
        equalityFn(a, b) {
            const { connector: aConnector, ...aRest } = a;
            const { connector: bConnector, ...bRest } = b;
            return ((0,deepEqual/* deepEqual */.I)(aRest, bRest) &&
                // check connector separately
                aConnector?.id === bConnector?.id &&
                aConnector?.uid === bConnector?.uid);
        },
    });
}
//# sourceMappingURL=watchAccount.js.map
// EXTERNAL MODULE: ./node_modules/.pnpm/wagmi@2.5.5_@tanstack+react-query@5.18.1_immer@10.0.4_react-dom@18.2.0_react-native@0.73.4_re_v25ef47o4x2uzzylvfiqdsf7ny/node_modules/wagmi/dist/esm/hooks/useConfig.js + 4 modules
var useConfig = __webpack_require__(86788);
// EXTERNAL MODULE: ./node_modules/.pnpm/react@18.2.0/node_modules/react/index.js
var react = __webpack_require__(96651);
// EXTERNAL MODULE: ./node_modules/.pnpm/use-sync-external-store@1.2.0_react@18.2.0/node_modules/use-sync-external-store/shim/with-selector.js
var with_selector = __webpack_require__(7968);
;// CONCATENATED MODULE: ./node_modules/.pnpm/wagmi@2.5.5_@tanstack+react-query@5.18.1_immer@10.0.4_react-dom@18.2.0_react-native@0.73.4_re_v25ef47o4x2uzzylvfiqdsf7ny/node_modules/wagmi/dist/esm/hooks/useSyncExternalStoreWithTracked.js
'use client';



const isPlainObject = (obj) => typeof obj === 'object' && !Array.isArray(obj);
function useSyncExternalStoreWithTracked(subscribe, getSnapshot, getServerSnapshot = getSnapshot, isEqual = deepEqual/* deepEqual */.I) {
    const trackedKeys = (0,react.useRef)([]);
    const result = (0,with_selector.useSyncExternalStoreWithSelector)(subscribe, getSnapshot, getServerSnapshot, (x) => x, (a, b) => {
        if (isPlainObject(a) && isPlainObject(b) && trackedKeys.current.length) {
            for (const key of trackedKeys.current) {
                const equal = isEqual(a[key], b[key]);
                if (!equal)
                    return false;
            }
            return true;
        }
        return isEqual(a, b);
    });
    if (isPlainObject(result)) {
        const trackedResult = { ...result };
        Object.defineProperties(trackedResult, Object.entries(trackedResult).reduce((res, [key, value]) => {
            return {
                ...res,
                [key]: {
                    configurable: false,
                    enumerable: true,
                    get: () => {
                        if (!trackedKeys.current.includes(key)) {
                            trackedKeys.current.push(key);
                        }
                        return value;
                    },
                },
            };
        }, {}));
        return trackedResult;
    }
    return result;
}
//# sourceMappingURL=useSyncExternalStoreWithTracked.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/wagmi@2.5.5_@tanstack+react-query@5.18.1_immer@10.0.4_react-dom@18.2.0_react-native@0.73.4_re_v25ef47o4x2uzzylvfiqdsf7ny/node_modules/wagmi/dist/esm/hooks/useAccount.js
'use client';



/** https://wagmi.sh/react/api/hooks/useAccount */
function useAccount(parameters = {}) {
    const config = (0,useConfig/* useConfig */.E)(parameters);
    return useSyncExternalStoreWithTracked((onChange) => watchAccount(config, { onChange }), () => getAccount(config));
}
//# sourceMappingURL=useAccount.js.map

/***/ }),

/***/ 86788:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  E: () => (/* binding */ useConfig)
});

// EXTERNAL MODULE: ./node_modules/.pnpm/react@18.2.0/node_modules/react/index.js
var react = __webpack_require__(96651);
// EXTERNAL MODULE: ./node_modules/.pnpm/wagmi@2.5.5_@tanstack+react-query@5.18.1_immer@10.0.4_react-dom@18.2.0_react-native@0.73.4_re_v25ef47o4x2uzzylvfiqdsf7ny/node_modules/wagmi/dist/esm/context.js + 3 modules
var context = __webpack_require__(52200);
// EXTERNAL MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/errors/base.js + 1 modules
var base = __webpack_require__(54428);
;// CONCATENATED MODULE: ./node_modules/.pnpm/wagmi@2.5.5_@tanstack+react-query@5.18.1_immer@10.0.4_react-dom@18.2.0_react-native@0.73.4_re_v25ef47o4x2uzzylvfiqdsf7ny/node_modules/wagmi/dist/esm/version.js
const version = '2.5.5';
//# sourceMappingURL=version.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/wagmi@2.5.5_@tanstack+react-query@5.18.1_immer@10.0.4_react-dom@18.2.0_react-native@0.73.4_re_v25ef47o4x2uzzylvfiqdsf7ny/node_modules/wagmi/dist/esm/utils/getVersion.js

const getVersion = () => `wagmi@${version}`;
//# sourceMappingURL=getVersion.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/wagmi@2.5.5_@tanstack+react-query@5.18.1_immer@10.0.4_react-dom@18.2.0_react-native@0.73.4_re_v25ef47o4x2uzzylvfiqdsf7ny/node_modules/wagmi/dist/esm/errors/base.js


class BaseError extends base/* BaseError */.k {
    constructor() {
        super(...arguments);
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'WagmiError'
        });
    }
    get docsBaseUrl() {
        return 'https://wagmi.sh/react';
    }
    get version() {
        return getVersion();
    }
}
//# sourceMappingURL=base.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/wagmi@2.5.5_@tanstack+react-query@5.18.1_immer@10.0.4_react-dom@18.2.0_react-native@0.73.4_re_v25ef47o4x2uzzylvfiqdsf7ny/node_modules/wagmi/dist/esm/errors/context.js

class WagmiProviderNotFoundError extends BaseError {
    constructor() {
        super('`useConfig` must be used within `WagmiProvider`.', {
            docsPath: 'https://wagmi.sh/react/api/WagmiProvider',
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'WagmiProviderNotFoundError'
        });
    }
}
//# sourceMappingURL=context.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/wagmi@2.5.5_@tanstack+react-query@5.18.1_immer@10.0.4_react-dom@18.2.0_react-native@0.73.4_re_v25ef47o4x2uzzylvfiqdsf7ny/node_modules/wagmi/dist/esm/hooks/useConfig.js
'use client';




/** https://wagmi.sh/react/api/hooks/useConfig */
function useConfig(parameters = {}) {
    const config = parameters.config ?? (0,react.useContext)(context/* WagmiContext */.e);
    if (!config)
        throw new WagmiProviderNotFoundError();
    return config;
}
//# sourceMappingURL=useConfig.js.map

/***/ }),

/***/ 13480:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  i: () => (/* binding */ useConnect)
});

// EXTERNAL MODULE: ./node_modules/.pnpm/@tanstack+react-query@5.18.1_react@18.2.0/node_modules/@tanstack/react-query/build/modern/useMutation.js + 2 modules
var useMutation = __webpack_require__(89112);
// EXTERNAL MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/errors/config.js
var errors_config = __webpack_require__(3500);
;// CONCATENATED MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/actions/connect.js






/** https://wagmi.sh/core/api/actions/connect */
async function connect(config, parameters) {
    // "Register" connector if not already created
    let connector;
    if (typeof parameters.connector === 'function') {
        connector = config._internal.connectors.setup(parameters.connector);
    }
    else
        connector = parameters.connector;
    // Check if connector is already connected
    if (connector.uid === config.state.current)
        throw new errors_config/* ConnectorAlreadyConnectedError */.gB();
    try {
        config.setState((x) => ({ ...x, status: 'connecting' }));
        connector.emitter.emit('message', { type: 'connecting' });
        const data = await connector.connect({ chainId: parameters.chainId });
        const accounts = data.accounts;
        connector.emitter.off('connect', config._internal.events.connect);
        connector.emitter.on('change', config._internal.events.change);
        connector.emitter.on('disconnect', config._internal.events.disconnect);
        await config.storage?.setItem('recentConnectorId', connector.id);
        config.setState((x) => ({
            ...x,
            connections: new Map(x.connections).set(connector.uid, {
                accounts,
                chainId: data.chainId,
                connector: connector,
            }),
            current: connector.uid,
            status: 'connected',
        }));
        return { accounts, chainId: data.chainId };
    }
    catch (error) {
        config.setState((x) => ({
            ...x,
            // Keep existing connector connected in case of error
            status: x.current ? 'connected' : 'disconnected',
        }));
        throw error;
    }
}
//# sourceMappingURL=connect.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/query/connect.js


function connectMutationOptions(config) {
    return {
        mutationFn(variables) {
            return connect(config, variables);
        },
        mutationKey: ['connect'],
    };
}
//# sourceMappingURL=connect.js.map
// EXTERNAL MODULE: ./node_modules/.pnpm/react@18.2.0/node_modules/react/index.js
var react = __webpack_require__(96651);
// EXTERNAL MODULE: ./node_modules/.pnpm/wagmi@2.5.5_@tanstack+react-query@5.18.1_immer@10.0.4_react-dom@18.2.0_react-native@0.73.4_re_v25ef47o4x2uzzylvfiqdsf7ny/node_modules/wagmi/dist/esm/hooks/useConfig.js + 4 modules
var useConfig = __webpack_require__(86788);
;// CONCATENATED MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/actions/watchConnectors.js


/** https://wagmi.sh/core/api/actions/watchConnectors */
function watchConnectors(config, parameters) {
    const { onChange } = parameters;
    return config._internal.connectors.subscribe((connectors, prevConnectors) => {
        onChange(Object.values(connectors), prevConnectors);
    });
}
//# sourceMappingURL=watchConnectors.js.map
// EXTERNAL MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/utils/deepEqual.js
var deepEqual = __webpack_require__(52668);
;// CONCATENATED MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/actions/getConnectors.js

let previousConnectors = [];
/** https://wagmi.sh/core/api/actions/getConnectors */
function getConnectors(config) {
    const connectors = config.connectors;
    if ((0,deepEqual/* deepEqual */.I)(previousConnectors, connectors))
        return previousConnectors;
    previousConnectors = connectors;
    return connectors;
}
//# sourceMappingURL=getConnectors.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/wagmi@2.5.5_@tanstack+react-query@5.18.1_immer@10.0.4_react-dom@18.2.0_react-native@0.73.4_re_v25ef47o4x2uzzylvfiqdsf7ny/node_modules/wagmi/dist/esm/hooks/useConnectors.js
'use client';



/** https://wagmi.sh/react/api/hooks/useConnectors */
function useConnectors(parameters = {}) {
    const config = (0,useConfig/* useConfig */.E)(parameters);
    return (0,react.useSyncExternalStore)((onChange) => watchConnectors(config, { onChange }), () => getConnectors(config), () => getConnectors(config));
}
//# sourceMappingURL=useConnectors.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/wagmi@2.5.5_@tanstack+react-query@5.18.1_immer@10.0.4_react-dom@18.2.0_react-native@0.73.4_re_v25ef47o4x2uzzylvfiqdsf7ny/node_modules/wagmi/dist/esm/hooks/useConnect.js
'use client';






/** https://wagmi.sh/react/api/hooks/useConnect */
function useConnect(parameters = {}) {
    const { mutation } = parameters;
    const config = (0,useConfig/* useConfig */.E)(parameters);
    const connectors = useConnectors({ config });
    const mutationOptions = connectMutationOptions(config);
    const { mutate, mutateAsync, ...result } = (0,useMutation/* useMutation */.c)({
        ...mutation,
        ...mutationOptions,
    });
    // Reset mutation back to an idle state when the connector disconnects.
    (0,react.useEffect)(() => {
        return config.subscribe(({ status }) => status, (status, previousStatus) => {
            if (previousStatus === 'connected' && status === 'disconnected')
                result.reset();
        });
    }, [config, result]);
    return {
        ...result,
        connect: mutate,
        connectAsync: mutateAsync,
        connectors,
    };
}
//# sourceMappingURL=useConnect.js.map

/***/ }),

/***/ 31456:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  W: () => (/* binding */ useDisconnect)
});

// EXTERNAL MODULE: ./node_modules/.pnpm/@tanstack+react-query@5.18.1_react@18.2.0/node_modules/@tanstack/react-query/build/modern/useMutation.js + 2 modules
var useMutation = __webpack_require__(89112);
;// CONCATENATED MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/actions/disconnect.js
/** https://wagmi.sh/core/api/actions/disconnect */
async function disconnect(config, parameters = {}) {
    let connector;
    if (parameters.connector)
        connector = parameters.connector;
    else {
        const { connections, current } = config.state;
        const connection = connections.get(current);
        connector = connection?.connector;
    }
    const connections = config.state.connections;
    if (connector) {
        await connector.disconnect();
        connector.emitter.off('change', config._internal.events.change);
        connector.emitter.off('disconnect', config._internal.events.disconnect);
        connector.emitter.on('connect', config._internal.events.connect);
        connections.delete(connector.uid);
    }
    config.setState((x) => {
        // if no connections exist, move to disconnected state
        if (connections.size === 0)
            return {
                ...x,
                connections: new Map(),
                current: undefined,
                status: 'disconnected',
            };
        // switch over to another connection
        const nextConnection = connections.values().next().value;
        return {
            ...x,
            connections: new Map(connections),
            current: nextConnection.connector.uid,
        };
    });
    // Set recent connector if exists
    {
        const current = config.state.current;
        if (!current)
            return;
        const connector = config.state.connections.get(current)?.connector;
        if (!connector)
            return;
        await config.storage?.setItem('recentConnectorId', connector.id);
    }
}
//# sourceMappingURL=disconnect.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/query/disconnect.js


function disconnectMutationOptions(config) {
    return {
        mutationFn(variables) {
            return disconnect(config, variables);
        },
        mutationKey: ['disconnect'],
    };
}
//# sourceMappingURL=disconnect.js.map
// EXTERNAL MODULE: ./node_modules/.pnpm/wagmi@2.5.5_@tanstack+react-query@5.18.1_immer@10.0.4_react-dom@18.2.0_react-native@0.73.4_re_v25ef47o4x2uzzylvfiqdsf7ny/node_modules/wagmi/dist/esm/hooks/useConfig.js + 4 modules
var useConfig = __webpack_require__(86788);
// EXTERNAL MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/utils/deepEqual.js
var deepEqual = __webpack_require__(52668);
;// CONCATENATED MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/actions/getConnections.js


let previousConnections = [];
/** https://wagmi.sh/core/api/actions/getConnections */
function getConnections(config) {
    const connections = [...config.state.connections.values()];
    if (config.state.status === 'reconnecting')
        return previousConnections;
    if ((0,deepEqual/* deepEqual */.I)(previousConnections, connections))
        return previousConnections;
    previousConnections = connections;
    return connections;
}
//# sourceMappingURL=getConnections.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/actions/watchConnections.js



/** https://wagmi.sh/core/api/actions/watchConnections */
function watchConnections(config, parameters) {
    const { onChange } = parameters;
    return config.subscribe(() => getConnections(config), onChange, {
        equalityFn: deepEqual/* deepEqual */.I,
    });
}
//# sourceMappingURL=watchConnections.js.map
// EXTERNAL MODULE: ./node_modules/.pnpm/react@18.2.0/node_modules/react/index.js
var react = __webpack_require__(96651);
;// CONCATENATED MODULE: ./node_modules/.pnpm/wagmi@2.5.5_@tanstack+react-query@5.18.1_immer@10.0.4_react-dom@18.2.0_react-native@0.73.4_re_v25ef47o4x2uzzylvfiqdsf7ny/node_modules/wagmi/dist/esm/hooks/useConnections.js
'use client';



/** https://wagmi.sh/react/api/hooks/useConnections */
function useConnections(parameters = {}) {
    const config = (0,useConfig/* useConfig */.E)(parameters);
    return (0,react.useSyncExternalStore)((onChange) => watchConnections(config, { onChange }), () => getConnections(config), () => getConnections(config));
}
//# sourceMappingURL=useConnections.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/wagmi@2.5.5_@tanstack+react-query@5.18.1_immer@10.0.4_react-dom@18.2.0_react-native@0.73.4_re_v25ef47o4x2uzzylvfiqdsf7ny/node_modules/wagmi/dist/esm/hooks/useDisconnect.js
'use client';





/** https://wagmi.sh/react/api/hooks/useDisconnect */
function useDisconnect(parameters = {}) {
    const { mutation } = parameters;
    const config = (0,useConfig/* useConfig */.E)(parameters);
    const mutationOptions = disconnectMutationOptions(config);
    const { mutate, mutateAsync, ...result } = (0,useMutation/* useMutation */.c)({
        ...mutation,
        ...mutationOptions,
    });
    return {
        ...result,
        connectors: useConnections().map((connection) => connection.connector),
        disconnect: mutate,
        disconnectAsync: mutateAsync,
    };
}
//# sourceMappingURL=useDisconnect.js.map

/***/ }),

/***/ 12984:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  S: () => (/* binding */ useSignMessage)
});

// EXTERNAL MODULE: ./node_modules/.pnpm/@tanstack+react-query@5.18.1_react@18.2.0/node_modules/@tanstack/react-query/build/modern/useMutation.js + 2 modules
var useMutation = __webpack_require__(89112);
// EXTERNAL MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/accounts/utils/parseAccount.js
var parseAccount = __webpack_require__(81728);
// EXTERNAL MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/errors/base.js
var base = __webpack_require__(8696);
;// CONCATENATED MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/errors/account.js

class AccountNotFoundError extends base/* BaseError */.k {
    constructor({ docsPath } = {}) {
        super([
            'Could not find an Account to execute with this Action.',
            'Please provide an Account with the `account` argument on the Action, or by supplying an `account` to the WalletClient.',
        ].join('\n'), {
            docsPath,
            docsSlug: 'account',
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'AccountNotFoundError'
        });
    }
}
//# sourceMappingURL=account.js.map
// EXTERNAL MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/utils/encoding/toHex.js
var toHex = __webpack_require__(71220);
;// CONCATENATED MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/actions/wallet/signMessage.js



/**
 * Calculates an Ethereum-specific signature in [EIP-191 format](https://eips.ethereum.org/EIPS/eip-191): `keccak256("\x19Ethereum Signed Message:\n" + len(message) + message))`.
 *
 * - Docs: https://viem.sh/docs/actions/wallet/signMessage
 * - JSON-RPC Methods:
 *   - JSON-RPC Accounts: [`personal_sign`](https://docs.metamask.io/guide/signing-data#personal-sign)
 *   - Local Accounts: Signs locally. No JSON-RPC request.
 *
 * With the calculated signature, you can:
 * - use [`verifyMessage`](https://viem.sh/docs/utilities/verifyMessage) to verify the signature,
 * - use [`recoverMessageAddress`](https://viem.sh/docs/utilities/recoverMessageAddress) to recover the signing address from a signature.
 *
 * @param client - Client to use
 * @param parameters - {@link SignMessageParameters}
 * @returns The signed message. {@link SignMessageReturnType}
 *
 * @example
 * import { createWalletClient, custom } from 'viem'
 * import { mainnet } from 'viem/chains'
 * import { signMessage } from 'viem/wallet'
 *
 * const client = createWalletClient({
 *   chain: mainnet,
 *   transport: custom(window.ethereum),
 * })
 * const signature = await signMessage(client, {
 *   account: '0xA0Cf798816D4b9b9866b5330EEa46a18382f251e',
 *   message: 'hello world',
 * })
 *
 * @example
 * // Account Hoisting
 * import { createWalletClient, custom } from 'viem'
 * import { privateKeyToAccount } from 'viem/accounts'
 * import { mainnet } from 'viem/chains'
 * import { signMessage } from 'viem/wallet'
 *
 * const client = createWalletClient({
 *   account: privateKeyToAccount('0x…'),
 *   chain: mainnet,
 *   transport: custom(window.ethereum),
 * })
 * const signature = await signMessage(client, {
 *   message: 'hello world',
 * })
 */
async function signMessage(client, { account: account_ = client.account, message, }) {
    if (!account_)
        throw new AccountNotFoundError({
            docsPath: '/docs/actions/wallet/signMessage',
        });
    const account = (0,parseAccount/* parseAccount */.o)(account_);
    if (account.type === 'local')
        return account.signMessage({ message });
    const message_ = (() => {
        if (typeof message === 'string')
            return (0,toHex/* stringToHex */.mi)(message);
        if (message.raw instanceof Uint8Array)
            return (0,toHex/* toHex */.Sm)(message.raw);
        return message.raw;
    })();
    return client.request({
        method: 'personal_sign',
        params: [message_, account.address],
    }, { retryCount: 0 });
}
//# sourceMappingURL=signMessage.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/utils/getAction.js

/**
 * Retrieves and returns an action from the client (if exists), and falls
 * back to the tree-shakable action.
 *
 * Useful for extracting overridden actions from a client (ie. if a consumer
 * wants to override the `sendTransaction` implementation).
 */
function getAction(client, actionFn, 
// Some minifiers drop `Function.prototype.name`, meaning that `action.name`
// will not work. For that case, the consumer needs to pass the name explicitly.
name) {
    const action = client[actionFn.name ?? name];
    if (typeof action === 'function')
        return action;
    return (params) => actionFn(client, params);
}
//# sourceMappingURL=getAction.js.map
// EXTERNAL MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/clients/createClient.js + 1 modules
var createClient = __webpack_require__(5460);
// EXTERNAL MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/clients/transports/createTransport.js + 1 modules
var createTransport = __webpack_require__(66652);
;// CONCATENATED MODULE: ./node_modules/.pnpm/viem@2.7.6_typescript@5.3.3/node_modules/viem/_esm/clients/transports/custom.js

/**
 * @description Creates a custom transport given an EIP-1193 compliant `request` attribute.
 */
function custom(provider, config = {}) {
    const { key = 'custom', name = 'Custom Provider', retryDelay } = config;
    return ({ retryCount: defaultRetryCount }) => (0,createTransport/* createTransport */.i)({
        key,
        name,
        request: provider.request.bind(provider),
        retryCount: config.retryCount ?? defaultRetryCount,
        retryDelay,
        type: 'custom',
    });
}
//# sourceMappingURL=custom.js.map
// EXTERNAL MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/errors/config.js
var errors_config = __webpack_require__(3500);
;// CONCATENATED MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/actions/getConnectorClient.js




/** https://wagmi.sh/core/api/actions/getConnectorClient */
async function getConnectorClient(config, parameters = {}) {
    // Get connection
    let connection;
    if (parameters.connector) {
        const { connector } = parameters;
        const [accounts, chainId] = await Promise.all([
            connector.getAccounts(),
            connector.getChainId(),
        ]);
        connection = {
            accounts: accounts,
            chainId,
            connector,
        };
    }
    else
        connection = config.state.connections.get(config.state.current);
    if (!connection)
        throw new errors_config/* ConnectorNotConnectedError */.E3();
    const chainId = parameters.chainId ?? connection.chainId;
    const connector = connection.connector;
    if (connector.getClient)
        return connector.getClient({ chainId: chainId });
    // Default using `custom` transport
    const account = (0,parseAccount/* parseAccount */.o)(parameters.account ?? connection.accounts[0]);
    const chain = config.chains.find((chain) => chain.id === chainId);
    const provider = (await connection.connector.getProvider({ chainId }));
    // if account was provided, check that it exists on the connector
    if (parameters.account && !connection.accounts.includes(account.address))
        throw new errors_config/* ConnectorAccountNotFoundError */.TT({
            address: account.address,
            connector,
        });
    return (0,createClient/* createClient */.M)({
        account,
        chain,
        name: 'Connector Client',
        transport: (opts) => custom(provider)({ ...opts, retryCount: 0 }),
    });
}
//# sourceMappingURL=getConnectorClient.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/actions/signMessage.js








/** https://wagmi.sh/core/api/actions/signMessage */
async function signMessage_signMessage(config, parameters) {
    const { account, connector, ...rest } = parameters;
    let client;
    if (typeof account === 'object' && account.type === 'local')
        client = config.getClient();
    else
        client = await getConnectorClient(config, { account, connector });
    const action = getAction(client, signMessage, 'signMessage');
    return action({
        ...rest,
        ...(account ? { account } : {}),
    });
}
//# sourceMappingURL=signMessage.js.map
;// CONCATENATED MODULE: ./node_modules/.pnpm/@wagmi+core@2.6.3_immer@10.0.4_react@18.2.0_typescript@5.3.3_viem@2.7.6/node_modules/@wagmi/core/dist/esm/query/signMessage.js




function signMessageMutationOptions(config) {
    return {
        mutationFn(variables) {
            return signMessage_signMessage(config, variables);
        },
        mutationKey: ['signMessage'],
    };
}
//# sourceMappingURL=signMessage.js.map
// EXTERNAL MODULE: ./node_modules/.pnpm/wagmi@2.5.5_@tanstack+react-query@5.18.1_immer@10.0.4_react-dom@18.2.0_react-native@0.73.4_re_v25ef47o4x2uzzylvfiqdsf7ny/node_modules/wagmi/dist/esm/hooks/useConfig.js + 4 modules
var useConfig = __webpack_require__(86788);
;// CONCATENATED MODULE: ./node_modules/.pnpm/wagmi@2.5.5_@tanstack+react-query@5.18.1_immer@10.0.4_react-dom@18.2.0_react-native@0.73.4_re_v25ef47o4x2uzzylvfiqdsf7ny/node_modules/wagmi/dist/esm/hooks/useSignMessage.js
'use client';




/** https://wagmi.sh/react/api/hooks/useSignMessage */
function useSignMessage(parameters = {}) {
    const { mutation } = parameters;
    const config = (0,useConfig/* useConfig */.E)(parameters);
    const mutationOptions = signMessageMutationOptions(config);
    const { mutate, mutateAsync, ...result } = (0,useMutation/* useMutation */.c)({
        ...mutation,
        ...mutationOptions,
    });
    return {
        ...result,
        signMessage: mutate,
        signMessageAsync: mutateAsync,
    };
}
//# sourceMappingURL=useSignMessage.js.map

/***/ }),

/***/ 78308:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Su: () => (/* binding */ create)
});

// UNUSED EXPORTS: createStore, default, useStore

;// CONCATENATED MODULE: ./node_modules/.pnpm/zustand@4.5.2_immer@10.0.4_react@18.2.0/node_modules/zustand/esm/vanilla.mjs
const createStoreImpl = (createState) => {
  let state;
  const listeners = /* @__PURE__ */ new Set();
  const setState = (partial, replace) => {
    const nextState = typeof partial === "function" ? partial(state) : partial;
    if (!Object.is(nextState, state)) {
      const previousState = state;
      state = (replace != null ? replace : typeof nextState !== "object" || nextState === null) ? nextState : Object.assign({}, state, nextState);
      listeners.forEach((listener) => listener(state, previousState));
    }
  };
  const getState = () => state;
  const getInitialState = () => initialState;
  const subscribe = (listener) => {
    listeners.add(listener);
    return () => listeners.delete(listener);
  };
  const destroy = () => {
    if (( false ? 0 : void 0) !== "production") {
      console.warn(
        "[DEPRECATED] The `destroy` method will be unsupported in a future version. Instead use unsubscribe function returned by subscribe. Everything will be garbage-collected if store is garbage-collected."
      );
    }
    listeners.clear();
  };
  const api = { setState, getState, getInitialState, subscribe, destroy };
  const initialState = state = createState(setState, getState, api);
  return api;
};
const createStore = (createState) => createState ? createStoreImpl(createState) : createStoreImpl;
var vanilla = (createState) => {
  if (( false ? 0 : void 0) !== "production") {
    console.warn(
      "[DEPRECATED] Default export is deprecated. Instead use import { createStore } from 'zustand/vanilla'."
    );
  }
  return createStore(createState);
};



// EXTERNAL MODULE: ./node_modules/.pnpm/react@18.2.0/node_modules/react/index.js
var react = __webpack_require__(96651);
// EXTERNAL MODULE: ./node_modules/.pnpm/use-sync-external-store@1.2.0_react@18.2.0/node_modules/use-sync-external-store/shim/with-selector.js
var with_selector = __webpack_require__(7968);
;// CONCATENATED MODULE: ./node_modules/.pnpm/zustand@4.5.2_immer@10.0.4_react@18.2.0/node_modules/zustand/esm/index.mjs





const { useDebugValue } = react;
const { useSyncExternalStoreWithSelector } = with_selector;
let didWarnAboutEqualityFn = false;
const identity = (arg) => arg;
function useStore(api, selector = identity, equalityFn) {
  if (( false ? 0 : void 0) !== "production" && equalityFn && !didWarnAboutEqualityFn) {
    console.warn(
      "[DEPRECATED] Use `createWithEqualityFn` instead of `create` or use `useStoreWithEqualityFn` instead of `useStore`. They can be imported from 'zustand/traditional'. https://github.com/pmndrs/zustand/discussions/1937"
    );
    didWarnAboutEqualityFn = true;
  }
  const slice = useSyncExternalStoreWithSelector(
    api.subscribe,
    api.getState,
    api.getServerState || api.getInitialState,
    selector,
    equalityFn
  );
  useDebugValue(slice);
  return slice;
}
const createImpl = (createState) => {
  if (( false ? 0 : void 0) !== "production" && typeof createState !== "function") {
    console.warn(
      "[DEPRECATED] Passing a vanilla store will be unsupported in a future version. Instead use `import { useStore } from 'zustand'`."
    );
  }
  const api = typeof createState === "function" ? createStore(createState) : createState;
  const useBoundStore = (selector, equalityFn) => useStore(api, selector, equalityFn);
  Object.assign(useBoundStore, api);
  return useBoundStore;
};
const create = (createState) => createState ? createImpl(createState) : createImpl;
var esm_react = (createState) => {
  if (( false ? 0 : void 0) !== "production") {
    console.warn(
      "[DEPRECATED] Default export is deprecated. Instead use `import { create } from 'zustand'`."
    );
  }
  return create(createState);
};




/***/ }),

/***/ 31140:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   s: () => (/* binding */ immer)
/* harmony export */ });
/* harmony import */ var immer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56416);


const immerImpl = (initializer) => (set, get, store) => {
  store.setState = (updater, replace, ...a) => {
    const nextState = typeof updater === "function" ? (0,immer__WEBPACK_IMPORTED_MODULE_0__/* .produce */ .Ut)(updater) : updater;
    return set(nextState, replace, ...a);
  };
  return initializer(store.setState, get, store);
};
const immer = immerImpl;




/***/ })

}]);