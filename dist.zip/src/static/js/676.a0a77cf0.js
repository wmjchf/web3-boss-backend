"use strict";
(self["webpackChunkweb3_design_style"] = self["webpackChunkweb3_design_style"] || []).push([[676],{

/***/ 5245:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  c: () => (/* binding */ Typography_Typography)
});

// UNUSED EXPORTS: TypographyRoot

// EXTERNAL MODULE: ./node_modules/.pnpm/@babel+runtime@7.24.4/node_modules/@babel/runtime/helpers/esm/objectWithoutPropertiesLoose.js
var objectWithoutPropertiesLoose = __webpack_require__(90076);
// EXTERNAL MODULE: ./node_modules/.pnpm/@babel+runtime@7.24.4/node_modules/@babel/runtime/helpers/esm/extends.js
var esm_extends = __webpack_require__(36968);
// EXTERNAL MODULE: ./node_modules/.pnpm/react@18.2.0/node_modules/react/index.js
var react = __webpack_require__(96651);
// EXTERNAL MODULE: ./node_modules/.pnpm/clsx@2.1.0/node_modules/clsx/dist/clsx.mjs
var clsx = __webpack_require__(66548);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+system@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react@18.2.0/node_modules/@mui/system/esm/styleFunctionSx/extendSxProp.js
var extendSxProp = __webpack_require__(32448);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+utils@5.15.14_react@18.2.0/node_modules/@mui/utils/composeClasses/composeClasses.js
var composeClasses = __webpack_require__(58652);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/styles/styled.js
var styled = __webpack_require__(10024);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/styles/useThemeProps.js
var useThemeProps = __webpack_require__(39031);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/utils/capitalize.js
var capitalize = __webpack_require__(61332);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+utils@5.15.14_react@18.2.0/node_modules/@mui/utils/generateUtilityClasses/generateUtilityClasses.js
var generateUtilityClasses = __webpack_require__(83260);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+utils@5.15.14_react@18.2.0/node_modules/@mui/utils/generateUtilityClass/generateUtilityClass.js + 1 modules
var generateUtilityClass = __webpack_require__(58524);
;// CONCATENATED MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/Typography/typographyClasses.js


function getTypographyUtilityClass(slot) {
  return (0,generateUtilityClass/* default */.cp)('MuiTypography', slot);
}
const typographyClasses = (0,generateUtilityClasses/* default */.c)('MuiTypography', ['root', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'subtitle1', 'subtitle2', 'body1', 'body2', 'inherit', 'button', 'caption', 'overline', 'alignLeft', 'alignRight', 'alignCenter', 'alignJustify', 'noWrap', 'gutterBottom', 'paragraph']);
/* harmony default export */ const Typography_typographyClasses = ((/* unused pure expression or super */ null && (typographyClasses)));
// EXTERNAL MODULE: ./node_modules/.pnpm/react@18.2.0/node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(2488);
;// CONCATENATED MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/Typography/Typography.js
'use client';



const _excluded = ["align", "className", "component", "gutterBottom", "noWrap", "paragraph", "variant", "variantMapping"];










const useUtilityClasses = ownerState => {
  const {
    align,
    gutterBottom,
    noWrap,
    paragraph,
    variant,
    classes
  } = ownerState;
  const slots = {
    root: ['root', variant, ownerState.align !== 'inherit' && `align${(0,capitalize/* default */.c)(align)}`, gutterBottom && 'gutterBottom', noWrap && 'noWrap', paragraph && 'paragraph']
  };
  return (0,composeClasses/* default */.c)(slots, getTypographyUtilityClass, classes);
};
const TypographyRoot = (0,styled/* default */.cp)('span', {
  name: 'MuiTypography',
  slot: 'Root',
  overridesResolver: (props, styles) => {
    const {
      ownerState
    } = props;
    return [styles.root, ownerState.variant && styles[ownerState.variant], ownerState.align !== 'inherit' && styles[`align${(0,capitalize/* default */.c)(ownerState.align)}`], ownerState.noWrap && styles.noWrap, ownerState.gutterBottom && styles.gutterBottom, ownerState.paragraph && styles.paragraph];
  }
})(({
  theme,
  ownerState
}) => (0,esm_extends/* default */.c)({
  margin: 0
}, ownerState.variant === 'inherit' && {
  // Some elements, like <button> on Chrome have default font that doesn't inherit, reset this.
  font: 'inherit'
}, ownerState.variant !== 'inherit' && theme.typography[ownerState.variant], ownerState.align !== 'inherit' && {
  textAlign: ownerState.align
}, ownerState.noWrap && {
  overflow: 'hidden',
  textOverflow: 'ellipsis',
  whiteSpace: 'nowrap'
}, ownerState.gutterBottom && {
  marginBottom: '0.35em'
}, ownerState.paragraph && {
  marginBottom: 16
}));
const defaultVariantMapping = {
  h1: 'h1',
  h2: 'h2',
  h3: 'h3',
  h4: 'h4',
  h5: 'h5',
  h6: 'h6',
  subtitle1: 'h6',
  subtitle2: 'h6',
  body1: 'p',
  body2: 'p',
  inherit: 'p'
};

// TODO v6: deprecate these color values in v5.x and remove the transformation in v6
const colorTransformations = {
  primary: 'primary.main',
  textPrimary: 'text.primary',
  secondary: 'secondary.main',
  textSecondary: 'text.secondary',
  error: 'error.main'
};
const transformDeprecatedColors = color => {
  return colorTransformations[color] || color;
};
const Typography = /*#__PURE__*/react.forwardRef(function Typography(inProps, ref) {
  const themeProps = (0,useThemeProps/* default */.c)({
    props: inProps,
    name: 'MuiTypography'
  });
  const color = transformDeprecatedColors(themeProps.color);
  const props = (0,extendSxProp/* default */.c)((0,esm_extends/* default */.c)({}, themeProps, {
    color
  }));
  const {
      align = 'inherit',
      className,
      component,
      gutterBottom = false,
      noWrap = false,
      paragraph = false,
      variant = 'body1',
      variantMapping = defaultVariantMapping
    } = props,
    other = (0,objectWithoutPropertiesLoose/* default */.c)(props, _excluded);
  const ownerState = (0,esm_extends/* default */.c)({}, props, {
    align,
    color,
    className,
    component,
    gutterBottom,
    noWrap,
    paragraph,
    variant,
    variantMapping
  });
  const Component = component || (paragraph ? 'p' : variantMapping[variant] || defaultVariantMapping[variant]) || 'span';
  const classes = useUtilityClasses(ownerState);
  return /*#__PURE__*/(0,jsx_runtime.jsx)(TypographyRoot, (0,esm_extends/* default */.c)({
    as: Component,
    ref: ref,
    ownerState: ownerState,
    className: (0,clsx/* default */.c)(classes.root, className)
  }, other));
});
 false ? 0 : void 0;
/* harmony default export */ const Typography_Typography = (Typography);

/***/ }),

/***/ 49848:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  c: () => (/* binding */ internal_SwitchBase)
});

// EXTERNAL MODULE: ./node_modules/.pnpm/@babel+runtime@7.24.4/node_modules/@babel/runtime/helpers/esm/objectWithoutPropertiesLoose.js
var objectWithoutPropertiesLoose = __webpack_require__(90076);
// EXTERNAL MODULE: ./node_modules/.pnpm/@babel+runtime@7.24.4/node_modules/@babel/runtime/helpers/esm/extends.js
var esm_extends = __webpack_require__(36968);
// EXTERNAL MODULE: ./node_modules/.pnpm/react@18.2.0/node_modules/react/index.js
var react = __webpack_require__(96651);
// EXTERNAL MODULE: ./node_modules/.pnpm/clsx@2.1.0/node_modules/clsx/dist/clsx.mjs
var clsx = __webpack_require__(66548);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+utils@5.15.14_react@18.2.0/node_modules/@mui/utils/composeClasses/composeClasses.js
var composeClasses = __webpack_require__(58652);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/utils/capitalize.js
var capitalize = __webpack_require__(61332);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/styles/styled.js
var styled = __webpack_require__(10024);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/styles/rootShouldForwardProp.js
var rootShouldForwardProp = __webpack_require__(37448);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/utils/useControlled.js
var useControlled = __webpack_require__(83704);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/FormControl/useFormControl.js
var useFormControl = __webpack_require__(14664);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/ButtonBase/ButtonBase.js + 4 modules
var ButtonBase = __webpack_require__(72488);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+utils@5.15.14_react@18.2.0/node_modules/@mui/utils/generateUtilityClasses/generateUtilityClasses.js
var generateUtilityClasses = __webpack_require__(83260);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+utils@5.15.14_react@18.2.0/node_modules/@mui/utils/generateUtilityClass/generateUtilityClass.js + 1 modules
var generateUtilityClass = __webpack_require__(58524);
;// CONCATENATED MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/internal/switchBaseClasses.js


function getSwitchBaseUtilityClass(slot) {
  return (0,generateUtilityClass/* default */.cp)('PrivateSwitchBase', slot);
}
const switchBaseClasses = (0,generateUtilityClasses/* default */.c)('PrivateSwitchBase', ['root', 'checked', 'disabled', 'input', 'edgeStart', 'edgeEnd']);
/* harmony default export */ const internal_switchBaseClasses = ((/* unused pure expression or super */ null && (switchBaseClasses)));
// EXTERNAL MODULE: ./node_modules/.pnpm/react@18.2.0/node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(2488);
;// CONCATENATED MODULE: ./node_modules/.pnpm/@mui+material@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react-dom@18.2.0_react@18.2.0/node_modules/@mui/material/internal/SwitchBase.js
'use client';



const _excluded = ["autoFocus", "checked", "checkedIcon", "className", "defaultChecked", "disabled", "disableFocusRipple", "edge", "icon", "id", "inputProps", "inputRef", "name", "onBlur", "onChange", "onFocus", "readOnly", "required", "tabIndex", "type", "value"];













const useUtilityClasses = ownerState => {
  const {
    classes,
    checked,
    disabled,
    edge
  } = ownerState;
  const slots = {
    root: ['root', checked && 'checked', disabled && 'disabled', edge && `edge${(0,capitalize/* default */.c)(edge)}`],
    input: ['input']
  };
  return (0,composeClasses/* default */.c)(slots, getSwitchBaseUtilityClass, classes);
};
const SwitchBaseRoot = (0,styled/* default */.cp)(ButtonBase/* default */.c)(({
  ownerState
}) => (0,esm_extends/* default */.c)({
  padding: 9,
  borderRadius: '50%'
}, ownerState.edge === 'start' && {
  marginLeft: ownerState.size === 'small' ? -3 : -12
}, ownerState.edge === 'end' && {
  marginRight: ownerState.size === 'small' ? -3 : -12
}));
const SwitchBaseInput = (0,styled/* default */.cp)('input', {
  shouldForwardProp: rootShouldForwardProp/* default */.c
})({
  cursor: 'inherit',
  position: 'absolute',
  opacity: 0,
  width: '100%',
  height: '100%',
  top: 0,
  left: 0,
  margin: 0,
  padding: 0,
  zIndex: 1
});

/**
 * @ignore - internal component.
 */
const SwitchBase = /*#__PURE__*/react.forwardRef(function SwitchBase(props, ref) {
  const {
      autoFocus,
      checked: checkedProp,
      checkedIcon,
      className,
      defaultChecked,
      disabled: disabledProp,
      disableFocusRipple = false,
      edge = false,
      icon,
      id,
      inputProps,
      inputRef,
      name,
      onBlur,
      onChange,
      onFocus,
      readOnly,
      required = false,
      tabIndex,
      type,
      value
    } = props,
    other = (0,objectWithoutPropertiesLoose/* default */.c)(props, _excluded);
  const [checked, setCheckedState] = (0,useControlled/* default */.c)({
    controlled: checkedProp,
    default: Boolean(defaultChecked),
    name: 'SwitchBase',
    state: 'checked'
  });
  const muiFormControl = (0,useFormControl/* default */.c)();
  const handleFocus = event => {
    if (onFocus) {
      onFocus(event);
    }
    if (muiFormControl && muiFormControl.onFocus) {
      muiFormControl.onFocus(event);
    }
  };
  const handleBlur = event => {
    if (onBlur) {
      onBlur(event);
    }
    if (muiFormControl && muiFormControl.onBlur) {
      muiFormControl.onBlur(event);
    }
  };
  const handleInputChange = event => {
    // Workaround for https://github.com/facebook/react/issues/9023
    if (event.nativeEvent.defaultPrevented) {
      return;
    }
    const newChecked = event.target.checked;
    setCheckedState(newChecked);
    if (onChange) {
      // TODO v6: remove the second argument.
      onChange(event, newChecked);
    }
  };
  let disabled = disabledProp;
  if (muiFormControl) {
    if (typeof disabled === 'undefined') {
      disabled = muiFormControl.disabled;
    }
  }
  const hasLabelFor = type === 'checkbox' || type === 'radio';
  const ownerState = (0,esm_extends/* default */.c)({}, props, {
    checked,
    disabled,
    disableFocusRipple,
    edge
  });
  const classes = useUtilityClasses(ownerState);
  return /*#__PURE__*/(0,jsx_runtime.jsxs)(SwitchBaseRoot, (0,esm_extends/* default */.c)({
    component: "span",
    className: (0,clsx/* default */.c)(classes.root, className),
    centerRipple: true,
    focusRipple: !disableFocusRipple,
    disabled: disabled,
    tabIndex: null,
    role: undefined,
    onFocus: handleFocus,
    onBlur: handleBlur,
    ownerState: ownerState,
    ref: ref
  }, other, {
    children: [/*#__PURE__*/(0,jsx_runtime.jsx)(SwitchBaseInput, (0,esm_extends/* default */.c)({
      autoFocus: autoFocus,
      checked: checkedProp,
      defaultChecked: defaultChecked,
      className: classes.input,
      disabled: disabled,
      id: hasLabelFor ? id : undefined,
      name: name,
      onChange: handleInputChange,
      readOnly: readOnly,
      ref: inputRef,
      required: required,
      ownerState: ownerState,
      tabIndex: tabIndex,
      type: type
    }, type === 'checkbox' && value === undefined ? {} : {
      value
    }, inputProps)), checked ? checkedIcon : icon]
  }));
});

// NB: If changed, please update Checkbox, Switch and Radio
// so that the API documentation is updated.
 false ? 0 : void 0;
/* harmony default export */ const internal_SwitchBase = (SwitchBase);

/***/ }),

/***/ 78636:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   c: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96651);
/* harmony import */ var _utils_createSvgIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(54212);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2488);
'use client';




/**
 * @ignore - internal component.
 */

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .c)( /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M8.465 8.465C9.37 7.56 10.62 7 12 7C14.76 7 17 9.24 17 12C17 13.38 16.44 14.63 15.535 15.535C14.63 16.44 13.38 17 12 17C9.24 17 7 14.76 7 12C7 10.62 7.56 9.37 8.465 8.465Z"
}), 'RadioButtonChecked'));

/***/ }),

/***/ 47992:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   c: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(96651);
/* harmony import */ var _utils_createSvgIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(54212);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2488);
'use client';




/**
 * @ignore - internal component.
 */

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .c)( /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8z"
}), 'RadioButtonUnchecked'));

/***/ }),

/***/ 74164:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   c: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mui_utils_createChainedFunction__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(80296);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_mui_utils_createChainedFunction__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .c);

/***/ }),

/***/ 88000:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  c: () => (/* binding */ createStack)
});

// UNUSED EXPORTS: style

// EXTERNAL MODULE: ./node_modules/.pnpm/@babel+runtime@7.24.4/node_modules/@babel/runtime/helpers/esm/objectWithoutPropertiesLoose.js
var objectWithoutPropertiesLoose = __webpack_require__(90076);
// EXTERNAL MODULE: ./node_modules/.pnpm/@babel+runtime@7.24.4/node_modules/@babel/runtime/helpers/esm/extends.js
var esm_extends = __webpack_require__(36968);
// EXTERNAL MODULE: ./node_modules/.pnpm/react@18.2.0/node_modules/react/index.js
var react = __webpack_require__(96651);
// EXTERNAL MODULE: ./node_modules/.pnpm/clsx@2.1.0/node_modules/clsx/dist/clsx.mjs
var clsx = __webpack_require__(66548);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+utils@5.15.14_react@18.2.0/node_modules/@mui/utils/deepmerge/deepmerge.js
var deepmerge = __webpack_require__(72372);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+utils@5.15.14_react@18.2.0/node_modules/@mui/utils/generateUtilityClass/generateUtilityClass.js + 1 modules
var generateUtilityClass = __webpack_require__(58524);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+utils@5.15.14_react@18.2.0/node_modules/@mui/utils/composeClasses/composeClasses.js
var composeClasses = __webpack_require__(58652);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+styled-engine@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react@18.2.0/node_modules/@mui/styled-engine/index.js + 1 modules
var styled_engine = __webpack_require__(9992);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+system@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react@18.2.0/node_modules/@mui/system/esm/createTheme/createTheme.js + 2 modules
var createTheme = __webpack_require__(83384);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+system@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react@18.2.0/node_modules/@mui/system/esm/styleFunctionSx/styleFunctionSx.js
var styleFunctionSx = __webpack_require__(52464);
;// CONCATENATED MODULE: ./node_modules/.pnpm/@mui+system@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react@18.2.0/node_modules/@mui/system/esm/createStyled.js


const _excluded = ["ownerState"],
  _excluded2 = ["variants"],
  _excluded3 = ["name", "slot", "skipVariantsResolver", "skipSx", "overridesResolver"];
/* eslint-disable no-underscore-dangle */






function isEmpty(obj) {
  return Object.keys(obj).length === 0;
}

// https://github.com/emotion-js/emotion/blob/26ded6109fcd8ca9875cc2ce4564fee678a3f3c5/packages/styled/src/utils.js#L40
function isStringTag(tag) {
  return typeof tag === 'string' &&
  // 96 is one less than the char code
  // for "a" so this is checking that
  // it's a lowercase character
  tag.charCodeAt(0) > 96;
}

// Update /system/styled/#api in case if this changes
function shouldForwardProp(prop) {
  return prop !== 'ownerState' && prop !== 'theme' && prop !== 'sx' && prop !== 'as';
}
const systemDefaultTheme = (0,createTheme/* default */.c)();
const lowercaseFirstLetter = string => {
  if (!string) {
    return string;
  }
  return string.charAt(0).toLowerCase() + string.slice(1);
};
function resolveTheme({
  defaultTheme,
  theme,
  themeId
}) {
  return isEmpty(theme) ? defaultTheme : theme[themeId] || theme;
}
function defaultOverridesResolver(slot) {
  if (!slot) {
    return null;
  }
  return (props, styles) => styles[slot];
}
function processStyleArg(callableStyle, _ref) {
  let {
      ownerState
    } = _ref,
    props = (0,objectWithoutPropertiesLoose/* default */.c)(_ref, _excluded);
  const resolvedStylesArg = typeof callableStyle === 'function' ? callableStyle((0,esm_extends/* default */.c)({
    ownerState
  }, props)) : callableStyle;
  if (Array.isArray(resolvedStylesArg)) {
    return resolvedStylesArg.flatMap(resolvedStyle => processStyleArg(resolvedStyle, (0,esm_extends/* default */.c)({
      ownerState
    }, props)));
  }
  if (!!resolvedStylesArg && typeof resolvedStylesArg === 'object' && Array.isArray(resolvedStylesArg.variants)) {
    const {
        variants = []
      } = resolvedStylesArg,
      otherStyles = (0,objectWithoutPropertiesLoose/* default */.c)(resolvedStylesArg, _excluded2);
    let result = otherStyles;
    variants.forEach(variant => {
      let isMatch = true;
      if (typeof variant.props === 'function') {
        isMatch = variant.props((0,esm_extends/* default */.c)({
          ownerState
        }, props, ownerState));
      } else {
        Object.keys(variant.props).forEach(key => {
          if ((ownerState == null ? void 0 : ownerState[key]) !== variant.props[key] && props[key] !== variant.props[key]) {
            isMatch = false;
          }
        });
      }
      if (isMatch) {
        if (!Array.isArray(result)) {
          result = [result];
        }
        result.push(typeof variant.style === 'function' ? variant.style((0,esm_extends/* default */.c)({
          ownerState
        }, props, ownerState)) : variant.style);
      }
    });
    return result;
  }
  return resolvedStylesArg;
}
function createStyled(input = {}) {
  const {
    themeId,
    defaultTheme = systemDefaultTheme,
    rootShouldForwardProp = shouldForwardProp,
    slotShouldForwardProp = shouldForwardProp
  } = input;
  const systemSx = props => {
    return (0,styleFunctionSx/* default */.c)((0,esm_extends/* default */.c)({}, props, {
      theme: resolveTheme((0,esm_extends/* default */.c)({}, props, {
        defaultTheme,
        themeId
      }))
    }));
  };
  systemSx.__mui_systemSx = true;
  return (tag, inputOptions = {}) => {
    // Filter out the `sx` style function from the previous styled component to prevent unnecessary styles generated by the composite components.
    (0,styled_engine.internal_processStyles)(tag, styles => styles.filter(style => !(style != null && style.__mui_systemSx)));
    const {
        name: componentName,
        slot: componentSlot,
        skipVariantsResolver: inputSkipVariantsResolver,
        skipSx: inputSkipSx,
        // TODO v6: remove `lowercaseFirstLetter()` in the next major release
        // For more details: https://github.com/mui/material-ui/pull/37908
        overridesResolver = defaultOverridesResolver(lowercaseFirstLetter(componentSlot))
      } = inputOptions,
      options = (0,objectWithoutPropertiesLoose/* default */.c)(inputOptions, _excluded3);

    // if skipVariantsResolver option is defined, take the value, otherwise, true for root and false for other slots.
    const skipVariantsResolver = inputSkipVariantsResolver !== undefined ? inputSkipVariantsResolver :
    // TODO v6: remove `Root` in the next major release
    // For more details: https://github.com/mui/material-ui/pull/37908
    componentSlot && componentSlot !== 'Root' && componentSlot !== 'root' || false;
    const skipSx = inputSkipSx || false;
    let label;
    if (false) {}
    let shouldForwardPropOption = shouldForwardProp;

    // TODO v6: remove `Root` in the next major release
    // For more details: https://github.com/mui/material-ui/pull/37908
    if (componentSlot === 'Root' || componentSlot === 'root') {
      shouldForwardPropOption = rootShouldForwardProp;
    } else if (componentSlot) {
      // any other slot specified
      shouldForwardPropOption = slotShouldForwardProp;
    } else if (isStringTag(tag)) {
      // for string (html) tag, preserve the behavior in emotion & styled-components.
      shouldForwardPropOption = undefined;
    }
    const defaultStyledResolver = (0,styled_engine["default"])(tag, (0,esm_extends/* default */.c)({
      shouldForwardProp: shouldForwardPropOption,
      label
    }, options));
    const transformStyleArg = stylesArg => {
      // On the server Emotion doesn't use React.forwardRef for creating components, so the created
      // component stays as a function. This condition makes sure that we do not interpolate functions
      // which are basically components used as a selectors.
      if (typeof stylesArg === 'function' && stylesArg.__emotion_real !== stylesArg || (0,deepmerge/* isPlainObject */.o)(stylesArg)) {
        return props => processStyleArg(stylesArg, (0,esm_extends/* default */.c)({}, props, {
          theme: resolveTheme({
            theme: props.theme,
            defaultTheme,
            themeId
          })
        }));
      }
      return stylesArg;
    };
    const muiStyledResolver = (styleArg, ...expressions) => {
      let transformedStyleArg = transformStyleArg(styleArg);
      const expressionsWithDefaultTheme = expressions ? expressions.map(transformStyleArg) : [];
      if (componentName && overridesResolver) {
        expressionsWithDefaultTheme.push(props => {
          const theme = resolveTheme((0,esm_extends/* default */.c)({}, props, {
            defaultTheme,
            themeId
          }));
          if (!theme.components || !theme.components[componentName] || !theme.components[componentName].styleOverrides) {
            return null;
          }
          const styleOverrides = theme.components[componentName].styleOverrides;
          const resolvedStyleOverrides = {};
          // TODO: v7 remove iteration and use `resolveStyleArg(styleOverrides[slot])` directly
          Object.entries(styleOverrides).forEach(([slotKey, slotStyle]) => {
            resolvedStyleOverrides[slotKey] = processStyleArg(slotStyle, (0,esm_extends/* default */.c)({}, props, {
              theme
            }));
          });
          return overridesResolver(props, resolvedStyleOverrides);
        });
      }
      if (componentName && !skipVariantsResolver) {
        expressionsWithDefaultTheme.push(props => {
          var _theme$components;
          const theme = resolveTheme((0,esm_extends/* default */.c)({}, props, {
            defaultTheme,
            themeId
          }));
          const themeVariants = theme == null || (_theme$components = theme.components) == null || (_theme$components = _theme$components[componentName]) == null ? void 0 : _theme$components.variants;
          return processStyleArg({
            variants: themeVariants
          }, (0,esm_extends/* default */.c)({}, props, {
            theme
          }));
        });
      }
      if (!skipSx) {
        expressionsWithDefaultTheme.push(systemSx);
      }
      const numOfCustomFnsApplied = expressionsWithDefaultTheme.length - expressions.length;
      if (Array.isArray(styleArg) && numOfCustomFnsApplied > 0) {
        const placeholders = new Array(numOfCustomFnsApplied).fill('');
        // If the type is array, than we need to add placeholders in the template for the overrides, variants and the sx styles.
        transformedStyleArg = [...styleArg, ...placeholders];
        transformedStyleArg.raw = [...styleArg.raw, ...placeholders];
      }
      const Component = defaultStyledResolver(transformedStyleArg, ...expressionsWithDefaultTheme);
      if (false) {}
      if (tag.muiName) {
        Component.muiName = tag.muiName;
      }
      return Component;
    };
    if (defaultStyledResolver.withConfig) {
      muiStyledResolver.withConfig = defaultStyledResolver.withConfig;
    }
    return muiStyledResolver;
  };
}
;// CONCATENATED MODULE: ./node_modules/.pnpm/@mui+system@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react@18.2.0/node_modules/@mui/system/esm/styled.js

const styled = createStyled();
/* harmony default export */ const esm_styled = (styled);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+system@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react@18.2.0/node_modules/@mui/system/esm/useThemeProps/useThemeProps.js + 1 modules
var useThemeProps = __webpack_require__(83068);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+system@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react@18.2.0/node_modules/@mui/system/esm/styleFunctionSx/extendSxProp.js
var extendSxProp = __webpack_require__(32448);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+system@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react@18.2.0/node_modules/@mui/system/esm/breakpoints.js
var breakpoints = __webpack_require__(31916);
// EXTERNAL MODULE: ./node_modules/.pnpm/@mui+system@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react@18.2.0/node_modules/@mui/system/esm/spacing.js + 1 modules
var spacing = __webpack_require__(48388);
// EXTERNAL MODULE: ./node_modules/.pnpm/react@18.2.0/node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(2488);
;// CONCATENATED MODULE: ./node_modules/.pnpm/@mui+system@5.15.14_@emotion+react@11.11.4_@emotion+styled@11.11.0_react@18.2.0/node_modules/@mui/system/esm/Stack/createStack.js


const createStack_excluded = ["component", "direction", "spacing", "divider", "children", "className", "useFlexGap"];













const defaultTheme = (0,createTheme/* default */.c)();
// widening Theme to any so that the consumer can own the theme structure.
const defaultCreateStyledComponent = esm_styled('div', {
  name: 'MuiStack',
  slot: 'Root',
  overridesResolver: (props, styles) => styles.root
});
function useThemePropsDefault(props) {
  return (0,useThemeProps/* default */.c)({
    props,
    name: 'MuiStack',
    defaultTheme
  });
}

/**
 * Return an array with the separator React element interspersed between
 * each React node of the input children.
 *
 * > joinChildren([1,2,3], 0)
 * [1,0,2,0,3]
 */
function joinChildren(children, separator) {
  const childrenArray = react.Children.toArray(children).filter(Boolean);
  return childrenArray.reduce((output, child, index) => {
    output.push(child);
    if (index < childrenArray.length - 1) {
      output.push( /*#__PURE__*/react.cloneElement(separator, {
        key: `separator-${index}`
      }));
    }
    return output;
  }, []);
}
const getSideFromDirection = direction => {
  return {
    row: 'Left',
    'row-reverse': 'Right',
    column: 'Top',
    'column-reverse': 'Bottom'
  }[direction];
};
const style = ({
  ownerState,
  theme
}) => {
  let styles = (0,esm_extends/* default */.c)({
    display: 'flex',
    flexDirection: 'column'
  }, (0,breakpoints/* handleBreakpoints */.ls)({
    theme
  }, (0,breakpoints/* resolveBreakpointValues */.Ws)({
    values: ownerState.direction,
    breakpoints: theme.breakpoints.values
  }), propValue => ({
    flexDirection: propValue
  })));
  if (ownerState.spacing) {
    const transformer = (0,spacing/* createUnarySpacing */.IV)(theme);
    const base = Object.keys(theme.breakpoints.values).reduce((acc, breakpoint) => {
      if (typeof ownerState.spacing === 'object' && ownerState.spacing[breakpoint] != null || typeof ownerState.direction === 'object' && ownerState.direction[breakpoint] != null) {
        acc[breakpoint] = true;
      }
      return acc;
    }, {});
    const directionValues = (0,breakpoints/* resolveBreakpointValues */.Ws)({
      values: ownerState.direction,
      base
    });
    const spacingValues = (0,breakpoints/* resolveBreakpointValues */.Ws)({
      values: ownerState.spacing,
      base
    });
    if (typeof directionValues === 'object') {
      Object.keys(directionValues).forEach((breakpoint, index, breakpoints) => {
        const directionValue = directionValues[breakpoint];
        if (!directionValue) {
          const previousDirectionValue = index > 0 ? directionValues[breakpoints[index - 1]] : 'column';
          directionValues[breakpoint] = previousDirectionValue;
        }
      });
    }
    const styleFromPropValue = (propValue, breakpoint) => {
      if (ownerState.useFlexGap) {
        return {
          gap: (0,spacing/* getValue */.uc)(transformer, propValue)
        };
      }
      return {
        // The useFlexGap={false} implement relies on each child to give up control of the margin.
        // We need to reset the margin to avoid double spacing.
        '& > :not(style):not(style)': {
          margin: 0
        },
        '& > :not(style) ~ :not(style)': {
          [`margin${getSideFromDirection(breakpoint ? directionValues[breakpoint] : ownerState.direction)}`]: (0,spacing/* getValue */.uc)(transformer, propValue)
        }
      };
    };
    styles = (0,deepmerge/* default */.c)(styles, (0,breakpoints/* handleBreakpoints */.ls)({
      theme
    }, spacingValues, styleFromPropValue));
  }
  styles = (0,breakpoints/* mergeBreakpointsInOrder */.cD)(theme.breakpoints, styles);
  return styles;
};
function createStack(options = {}) {
  const {
    // This will allow adding custom styled fn (for example for custom sx style function)
    createStyledComponent = defaultCreateStyledComponent,
    useThemeProps = useThemePropsDefault,
    componentName = 'MuiStack'
  } = options;
  const useUtilityClasses = () => {
    const slots = {
      root: ['root']
    };
    return (0,composeClasses/* default */.c)(slots, slot => (0,generateUtilityClass/* default */.cp)(componentName, slot), {});
  };
  const StackRoot = createStyledComponent(style);
  const Stack = /*#__PURE__*/react.forwardRef(function Grid(inProps, ref) {
    const themeProps = useThemeProps(inProps);
    const props = (0,extendSxProp/* default */.c)(themeProps); // `color` type conflicts with html color attribute.
    const {
        component = 'div',
        direction = 'column',
        spacing = 0,
        divider,
        children,
        className,
        useFlexGap = false
      } = props,
      other = (0,objectWithoutPropertiesLoose/* default */.c)(props, createStack_excluded);
    const ownerState = {
      direction,
      spacing,
      useFlexGap
    };
    const classes = useUtilityClasses();
    return /*#__PURE__*/(0,jsx_runtime.jsx)(StackRoot, (0,esm_extends/* default */.c)({
      as: component,
      ownerState: ownerState,
      ref: ref,
      className: (0,clsx/* default */.c)(classes.root, className)
    }, other, {
      children: divider ? joinChildren(children, divider) : children
    }));
  });
   false ? 0 : void 0;
  return Stack;
}

/***/ })

}]);